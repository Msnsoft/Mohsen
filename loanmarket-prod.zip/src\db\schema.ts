// Drizzle schema — typed mirror of db/init/*.sql (the authoritative DB).
// Used for typed reads/writes; RLS + money invariants live in the database.
import {
  pgTable, uuid, text, bigint, integer, smallint, numeric, boolean, timestamp, jsonb, primaryKey,
} from "drizzle-orm/pg-core";

export const users = pgTable("users", {
  id: uuid("id").primaryKey().defaultRandom(),
  mobile: text("mobile").notNull().unique(),
  email: text("email").unique(),
  displayName: text("display_name"),
  verificationLevel: smallint("verification_level").notNull().default(1),
  status: text("status").notNull().default("active"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const userRoles = pgTable("user_roles", {
  userId: uuid("user_id").notNull(),
  role: text("role").notNull(),
}, (t) => ({ pk: primaryKey({ columns: [t.userId, t.role] }) }));

export const loanTypes = pgTable("loan_types", {
  id: uuid("id").primaryKey().defaultRandom(),
  name: text("name").notNull(),
  bankName: text("bank_name"),
  logoUrl: text("logo_url"),
  fixedRate: numeric("fixed_rate"),
  rateEditable: boolean("rate_editable").notNull().default(true),
  defaultDurationMonths: integer("default_duration_months"),
  minPricePerMillion: bigint("min_price_per_million", { mode: "number" }),
  maxPricePerMillion: bigint("max_price_per_million", { mode: "number" }),
  active: boolean("active").notNull().default(true),
});

export const loanPosts = pgTable("loan_posts", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  type: text("type").notNull(),
  loanTypeId: uuid("loan_type_id").notNull(),
  loanValue: bigint("loan_value", { mode: "number" }).notNull(),
  loanPrice: bigint("loan_price", { mode: "number" }).notNull(),
  pricePerMillion: bigint("price_per_million", { mode: "number" }),
  rate: numeric("rate"),
  durationMonths: integer("duration_months"),
  province: text("province"),
  status: text("status").notNull().default("draft"),
  splittable: boolean("splittable").notNull().default(false),
  minChunk: bigint("min_chunk", { mode: "number" }),
  maxSplits: integer("max_splits"),
  filledAmount: bigint("filled_amount", { mode: "number" }).notNull().default(0),
  featured: boolean("featured").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const wallets = pgTable("wallets", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull().unique(),
  currency: text("currency").notNull().default("IRR"),
  status: text("status").notNull().default("active"),
});

export const subscriptionPlans = pgTable("subscription_plans", {
  id: uuid("id").primaryKey().defaultRandom(),
  key: text("key").notNull().unique(),
  name: text("name").notNull(),
  price: bigint("price", { mode: "number" }).notNull().default(0),
  periodDays: integer("period_days").notNull().default(30),
  active: boolean("active").notNull().default(true),
  sort: integer("sort").notNull().default(0),
});

export const planEntitlements = pgTable("plan_entitlements", {
  planId: uuid("plan_id").notNull(),
  entitlement: text("entitlement").notNull(),
  limitValue: integer("limit_value"),
}, (t) => ({ pk: primaryKey({ columns: [t.planId, t.entitlement] }) }));

export const subscriptions = pgTable("subscriptions", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  planId: uuid("plan_id").notNull(),
  status: text("status").notNull().default("active"),
  startedAt: timestamp("started_at", { withTimezone: true }).notNull().defaultNow(),
  expiresAt: timestamp("expires_at", { withTimezone: true }).notNull(),
});

export const config = pgTable("config", {
  key: text("key").primaryKey(),
  value: jsonb("value").notNull(),
});

export const notifications = pgTable("notifications", {
  id: uuid("id").primaryKey().defaultRandom(),
  userId: uuid("user_id").notNull(),
  title: text("title").notNull(),
  body: text("body"),
  read: boolean("read").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});
