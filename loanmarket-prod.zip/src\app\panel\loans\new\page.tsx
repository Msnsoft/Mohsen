import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { hasEntitlement } from "@/lib/entitlements";
import { db, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { NewLoanForm, type LoanTypeOption } from "./new-loan-form";
import type { CustomField } from "@/components/custom-field-input";

export const dynamic = "force-dynamic";

export default async function NewLoanPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  // smart pricing advice is a membership entitlement (M19 / M04 pricing assistant)
  const adviceEntitled = await hasEntitlement(user.id, "pricing_advice");
  let marketAvg: Record<string, number> | null = null;
  if (adviceEntitled) {
    const rows = await db.execute<{ loan_type_id: string; avg_ppm: string }>(sql`
      select loan_type_id, round(avg(price_per_million))::text as avg_ppm
      from loan_posts
      where status = 'active' and type = 'sell' and price_per_million is not null
      group by loan_type_id`);
    marketAvg = Object.fromEntries(
      (rows as { loan_type_id: string; avg_ppm: string }[]).map((r) => [r.loan_type_id, Number(r.avg_ppm)]),
    );
  }

  const rows = await db.execute<{
    id: string; name: string; bank_name: string | null; rate_editable: boolean;
    fixed_rate: string | null; default_duration_months: number | null;
    min_price_per_million: string | null; max_price_per_million: string | null;
  }>(sql`
    select id, name, bank_name, rate_editable, fixed_rate::text, default_duration_months,
           min_price_per_million::text, max_price_per_million::text
    from loan_types where active order by name`);

  const loanTypes: LoanTypeOption[] = (rows as LoanTypeOption[]).map((r) => ({ ...r }));

  // seller-facing custom fields per loan type (req. B)
  const fieldRows = await db.execute<CustomField & { loan_type_id: string }>(sql`
    select loan_type_id, key, label, field_type, audience, required, options
    from loan_type_fields
    where active and audience in ('seller','both')
    order by sort, label`);
  const sellerFields: Record<string, CustomField[]> = {};
  for (const f of fieldRows as (CustomField & { loan_type_id: string })[]) {
    (sellerFields[f.loan_type_id] ??= []).push(f);
  }

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">ثبت وام جدید</h1>
      {loanTypes.length === 0 ? (
        <Card><CardMuted>در حال حاضر نوع وام فعالی برای ثبت وجود ندارد.</CardMuted></Card>
      ) : (
        <Card>
          <NewLoanForm loanTypes={loanTypes} marketAvg={marketAvg} sellerFields={sellerFields} />
        </Card>
      )}
    </div>
  );
}
