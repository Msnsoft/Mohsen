import { Check, X, Clock, Minus } from "lucide-react";
import type { TimelineStage } from "@/services/deals";
import { formatDateTimeFa } from "@/lib/persian";
import { Countdown } from "@/components/countdown";

/**
 * Vertical workflow timeline (req. O) — the full ordered deal lifecycle with
 * per-stage status and timestamps. Shared by the user deal page and admin view.
 */
export function DealTimeline({ stages }: { stages: TimelineStage[] }) {
  return (
    <ol className="relative space-y-0">
      {stages.map((s, i) => (
        <li key={s.key} className="flex gap-3">
          {/* rail + node */}
          <div className="flex flex-col items-center">
            <Node status={s.status} />
            {i < stages.length - 1 && (
              <span
                className={`w-px flex-1 ${
                  s.status === "done" ? "bg-[var(--color-accent)]" : "bg-[var(--color-border)]"
                }`}
              />
            )}
          </div>
          {/* label */}
          <div className={`pb-5 ${i === stages.length - 1 ? "pb-0" : ""}`}>
            <p
              className={`text-sm font-medium ${
                s.status === "current"
                  ? "text-[var(--color-fg)]"
                  : s.status === "pending"
                    ? "text-[var(--color-muted)]"
                    : "text-[var(--color-fg)]"
              }`}
            >
              {s.label}
              {s.status === "current" && (
                <span className="mr-2 text-xs text-[var(--color-primary)]">• مرحله جاری</span>
              )}
            </p>
            <p className="mt-0.5 text-xs text-[var(--color-muted)]">
              {s.status === "skipped" ? (s.hint ?? "انجام نشد") : formatDateTimeFa(s.at)}
              {s.status !== "skipped" && s.hint ? ` · ${s.hint}` : ""}
            </p>
            {s.status === "current" && s.deadline && (
              <p className="mt-1"><Countdown to={s.deadline} /></p>
            )}
          </div>
        </li>
      ))}
    </ol>
  );
}

function Node({ status }: { status: TimelineStage["status"] }) {
  const base = "grid h-7 w-7 shrink-0 place-items-center rounded-full";
  switch (status) {
    case "done":
      return <span className={`${base} bg-[var(--color-accent)] text-[#06281f]`}><Check size={15} /></span>;
    case "current":
      return <span className={`${base} bg-[var(--color-primary)] text-white`}><Clock size={15} /></span>;
    case "cancelled":
      return <span className={`${base} bg-[color-mix(in_oklab,var(--color-danger)_20%,transparent)] text-[var(--color-danger)]`}><X size={15} /></span>;
    case "skipped":
      return <span className={`${base} border border-dashed border-[var(--color-border)] text-[var(--color-muted)]`}><Minus size={15} /></span>;
    default:
      return <span className={`${base} bg-[var(--color-surface-2)] text-[var(--color-muted)]`}><Minus size={14} /></span>;
  }
}
