"use client";
import { useActionState, useMemo, useState } from "react";
import { completeProfileAction, type OnboardingState } from "./actions";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

export interface OnboardField { key: string; label: string; required: boolean }

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

const META: Record<string, { inputMode?: "numeric" | "text"; dir?: "ltr" | "rtl"; maxLength?: number; placeholder?: string }> = {
  first_name: { placeholder: "مثلاً علی" },
  last_name: { placeholder: "مثلاً محمدی" },
  national_id: { inputMode: "numeric", dir: "ltr", maxLength: 10, placeholder: "۰۰۱۲۳۴۵۶۷۸" },
  card_number: { inputMode: "numeric", dir: "ltr", maxLength: 19, placeholder: "۶۰۳۷-xxxx-xxxx-xxxx" },
  sheba: { dir: "ltr", placeholder: "IR000000000000000000000000" },
  display_name: { placeholder: "نامی که در آگهی‌ها نمایش داده می‌شود" },
};

const STEP_GROUPS: { title: string; hint: string; keys: string[] }[] = [
  { title: "اطلاعات هویتی", hint: "نام و کد ملی شما با شمارهٔ موبایل استعلام می‌شود.", keys: ["first_name", "last_name", "national_id"] },
  { title: "اطلاعات بانکی", hint: "شماره کارت و شبا برای واریز وجه؛ مالکیت آن‌ها استعلام می‌شود.", keys: ["card_number", "sheba"] },
  { title: "نام نمایشی و تأیید", hint: "بررسی نهایی و ثبت اطلاعات.", keys: ["display_name"] },
];

export default function OnboardingForm({
  fields, mobile, defaultDisplayName,
}: { fields: OnboardField[]; mobile: string; defaultDisplayName: string }) {
  const [state, formAction, pending] = useActionState<OnboardingState, FormData>(
    completeProfileAction, { ok: false },
  );

  const byKey = useMemo(() => new Map(fields.map((f) => [f.key, f])), [fields]);
  const steps = useMemo(
    () =>
      STEP_GROUPS.map((g) => ({ ...g, fields: g.keys.map((k) => byKey.get(k)).filter(Boolean) as OnboardField[] }))
        .filter((g) => g.fields.length > 0),
    [byKey],
  );

  const [values, setValues] = useState<Record<string, string>>({ display_name: defaultDisplayName });
  const [step, setStep] = useState(0);
  const [stepError, setStepError] = useState<string | null>(null);

  const current = steps[step];
  const set = (k: string, v: string) => setValues((p) => ({ ...p, [k]: v }));

  function validateStep(): boolean {
    for (const f of current.fields) {
      if (f.required && !(values[f.key] ?? "").trim()) {
        setStepError(`«${f.label}» الزامی است.`);
        return false;
      }
    }
    setStepError(null);
    return true;
  }

  return (
    <Card className="space-y-5">
      <div>
        <CardTitle>تکمیل اطلاعات حساب</CardTitle>
        <CardMuted>برای فعال‌سازی حساب، اطلاعات زیر را تکمیل کنید.</CardMuted>
      </div>

      {/* progress */}
      <div className="flex items-center gap-2">
        {steps.map((s, i) => (
          <div key={s.title} className="flex-1">
            <div className={`h-1.5 rounded-full ${i <= step ? "bg-[var(--color-primary)]" : "bg-[var(--color-surface-2)]"}`} />
            <div className={`mt-1 text-xs ${i === step ? "text-[var(--color-fg)]" : "text-[var(--color-muted)]"}`}>{s.title}</div>
          </div>
        ))}
      </div>

      <form action={formAction} className="space-y-4">
        {/* keep ALL inputs mounted so the final submit carries every value */}
        {steps.map((s, i) => (
          <div key={s.title} className={i === step ? "space-y-4" : "hidden"}>
            <p className="text-sm text-[var(--color-muted)]">{s.hint}</p>

            {i === 0 && (
              <label className="block space-y-1">
                <span className="text-sm">شماره موبایل</span>
                <input value={mobile} dir="ltr" readOnly className={`${inputCls} opacity-70`} />
              </label>
            )}

            {s.fields.map((f) => {
              const m = META[f.key] ?? {};
              return (
                <label key={f.key} className="block space-y-1">
                  <span className="text-sm">
                    {f.label}{f.required && <span className="text-[var(--color-danger)]"> *</span>}
                  </span>
                  <input
                    name={f.key}
                    value={values[f.key] ?? ""}
                    onChange={(e) => set(f.key, e.target.value)}
                    inputMode={m.inputMode}
                    dir={m.dir}
                    maxLength={m.maxLength}
                    placeholder={m.placeholder}
                    className={inputCls}
                  />
                </label>
              );
            })}
          </div>
        ))}

        {/* hidden inputs for fields not surfaced in any step but still named */}
        {(stepError || state.error) && (
          <p className="text-sm text-[var(--color-danger)]">{stepError ?? state.error}</p>
        )}

        <div className="flex gap-3">
          {step > 0 && (
            <Button type="button" variant="ghost" onClick={() => { setStepError(null); setStep((s) => s - 1); }}>
              قبلی
            </Button>
          )}
          {step < steps.length - 1 ? (
            <Button type="button" className="ms-auto" onClick={() => { if (validateStep()) setStep((s) => s + 1); }}>
              بعدی
            </Button>
          ) : (
            <Button type="submit" className="ms-auto" disabled={pending}>
              {pending ? "در حال بررسی و ثبت…" : "ثبت نهایی و فعال‌سازی"}
            </Button>
          )}
        </div>
      </form>
    </Card>
  );
}
