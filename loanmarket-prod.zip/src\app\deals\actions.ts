"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";
import { saveUpload } from "@/lib/storage";

export async function startDeal(formData: FormData) {
  const listingId = String(formData.get("listing_id") ?? "");
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  // req. D: buyer accept-info (admin-defined buyer fields) arrives as info:<key>
  const info: Record<string, string> = {};
  for (const [k, v] of formData.entries()) {
    if (k.startsWith("info:")) {
      const val = String(v).trim();
      if (val) info[k.slice("info:".length)] = val;
    }
  }
  // req. E: a transfer may only be requested for oneself; "special" users
  // flagged by admin may record a beneficiary they act on behalf of.
  const onBehalfOf = String(formData.get("on_behalf_of") ?? "").trim();
  if (onBehalfOf && !user.isSpecial) {
    redirect(`/marketplace/${listingId}?error=special`);
  }
  if (onBehalfOf) info._on_behalf_of = onBehalfOf;

  let dealId: string | null = null;
  try {
    dealId = await withUser(user.id, async (tx) => {
      const rows = (await tx.execute<{ deal_start: string }>(
        sql`select deal_start(${listingId}::uuid, ${user.id}::uuid)`,
      )) as { deal_start: string }[];
      const id = rows[0]?.deal_start ?? null;
      if (id && Object.keys(info).length > 0) {
        await tx.execute(sql`select deal_set_transfer_info(${id}::uuid, ${user.id}::uuid, ${JSON.stringify(info)}::jsonb)`);
      }
      return id;
    });
  } catch (e) {
    const msg = e instanceof Error ? e.message : "";
    if (msg.includes("insufficient balance")) redirect("/wallet?need=1");
    redirect(`/marketplace/${listingId}?error=1`);
  }
  if (dealId) redirect(`/deals/${dealId}`);
  redirect("/deals");
}

async function act(dealId: string, fn: "deal_seller_transferred" | "deal_buyer_confirm" | "deal_buyer_cancel") {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  await withUser(user.id, (tx) =>
    fn === "deal_buyer_cancel"
      ? tx.execute(sql`select deal_buyer_cancel(${dealId}::uuid, ${user.id}::uuid)`)
      : fn === "deal_seller_transferred"
        ? tx.execute(sql`select deal_seller_transferred(${dealId}::uuid, ${user.id}::uuid)`)
        : tx.execute(sql`select deal_buyer_confirm(${dealId}::uuid, ${user.id}::uuid)`),
  );
  revalidatePath(`/deals/${dealId}`);
  revalidatePath("/deals");
}

export async function sellerTransferred(formData: FormData) { await act(String(formData.get("deal_id")), "deal_seller_transferred"); }
export async function buyerConfirm(formData: FormData) { await act(String(formData.get("deal_id")), "deal_buyer_confirm"); }
export async function refundDeal(formData: FormData) { await act(String(formData.get("deal_id")), "deal_buyer_cancel"); }

// req. S: rate the counterparty after a completed deal
export async function submitRatingAction(formData: FormData) {
  const dealId = String(formData.get("deal_id") ?? "");
  const score = Number(formData.get("score") ?? 0);
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!dealId || score < 1 || score > 5) redirect(`/deals/${dealId}?rate=err`);

  const answers: Record<string, string> = {};
  for (const [k, v] of formData.entries()) {
    if (k.startsWith("q:")) answers[k.slice(2)] = String(v);
  }
  try {
    await withUser(user.id, (tx) =>
      tx.execute(sql`select submit_rating(${dealId}::uuid, ${user.id}::uuid, ${score}, ${JSON.stringify(answers)}::jsonb)`),
    );
  } catch {
    redirect(`/deals/${dealId}?rate=err`);
  }
  revalidatePath(`/deals/${dealId}`);
  redirect(`/deals/${dealId}?rate=ok`);
}

// req. F: escrow-off manual settlement evidence (buyer receipt / seller proof)
const EVIDENCE_KINDS = ["payment_receipt", "transfer_proof"];
export async function uploadEvidence(formData: FormData) {
  const dealId = String(formData.get("deal_id") ?? "");
  const kind = String(formData.get("kind") ?? "");
  const file = formData.get("file");
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!dealId || !EVIDENCE_KINDS.includes(kind) || !(file instanceof File)) {
    redirect(`/deals/${dealId}?ev=err`);
  }
  try {
    const { url } = await saveUpload(file as File);
    await withUser(user.id, (tx) =>
      tx.execute(sql`
        insert into deal_evidence(deal_id, uploader_id, kind, file_url)
        values (${dealId}::uuid, ${user.id}::uuid, ${kind}, ${url})`),
    );
  } catch {
    redirect(`/deals/${dealId}?ev=err`);
  }
  revalidatePath(`/deals/${dealId}`);
  revalidatePath(`/admin/deals/${dealId}`);
  redirect(`/deals/${dealId}?ev=ok`);
}
