-- =====================================================================
-- Phase 2: scheduled-job SQL functions for the worker.
--  * escrow auto-release after the inspection deadline (M08 FR-M08-05)
--  * seller-timeout reminders (escrow.seller_timeout_hours)
--  * subscription expiry → downgrade to free (M19)
-- Each returns the number of rows it acted on. SECURITY DEFINER, app-callable.
-- Idempotent to (re)create.
-- =====================================================================
SET check_function_bodies = off;

CREATE OR REPLACE FUNCTION escrow_auto_release_due() RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _e record; _n int := 0;
BEGIN
  FOR _e IN
    SELECT es.deal_id, d.buyer_id
    FROM escrows es
    JOIN deals d ON d.id = es.deal_id
    WHERE es.state = 'in_inspection'
      AND es.auto_release_at IS NOT NULL
      AND es.auto_release_at <= now()
      AND d.state = 'waiting_buyer_confirmation'
  LOOP
    PERFORM deal_buyer_confirm(_e.deal_id, _e.buyer_id);
    _n := _n + 1;
  END LOOP;
  RETURN _n;
END $$;

CREATE OR REPLACE FUNCTION seller_timeout_reminders() RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d record; _hours int; _n int := 0;
BEGIN
  SELECT (value::text)::int INTO _hours FROM config WHERE key = 'escrow.seller_timeout_hours';
  _hours := COALESCE(_hours, 12);
  FOR _d IN
    SELECT d.id, d.seller_id FROM deals d
    WHERE d.state = 'waiting_seller_transfer'
      AND d.created_at <= now() - (_hours || ' hours')::interval
      AND NOT EXISTS (
        SELECT 1 FROM notifications n
        WHERE n.user_id = d.seller_id AND n.title = 'یادآوری انتقال وام'
          AND n.created_at >= now() - (_hours || ' hours')::interval)
  LOOP
    INSERT INTO notifications(user_id, title, body)
    VALUES (_d.seller_id, 'یادآوری انتقال وام',
            'مهلت انتقال وام برای یکی از معاملات شما نزدیک است. لطفاً وام را منتقل و وضعیت را به‌روزرسانی کنید.');
    _n := _n + 1;
  END LOOP;
  RETURN _n;
END $$;

CREATE OR REPLACE FUNCTION subscriptions_expire_due() RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _s record; _n int := 0;
BEGIN
  FOR _s IN SELECT id, user_id FROM subscriptions WHERE status = 'active' AND expires_at <= now()
  LOOP
    UPDATE subscriptions SET status = 'expired' WHERE id = _s.id;
    INSERT INTO notifications(user_id, title, body)
    VALUES (_s.user_id, 'پایان اشتراک', 'اشتراک شما به پایان رسید و حساب به پلن رایگان بازگشت.');
    _n := _n + 1;
  END LOOP;
  RETURN _n;
END $$;

CREATE OR REPLACE FUNCTION run_due_jobs()
RETURNS TABLE (auto_released int, reminders int, expired int)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  RETURN QUERY SELECT escrow_auto_release_due(), seller_timeout_reminders(), subscriptions_expire_due();
END $$;

GRANT EXECUTE ON FUNCTION
  escrow_auto_release_due(), seller_timeout_reminders(),
  subscriptions_expire_due(), run_due_jobs()
TO app;
