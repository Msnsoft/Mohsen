"use client";
import { useActionState } from "react";
import { Button } from "@/components/ui/button";
import { toFaDigits } from "@/lib/persian";
import { updateProfileAction, type ProfileState } from "../actions";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export function ProfileForm({ displayName, mobile }: { displayName: string; mobile: string }) {
  const [state, action, pending] = useActionState<ProfileState, FormData>(updateProfileAction, {});
  return (
    <form action={action} className="space-y-3">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">نام نمایشی</span>
          <input name="display_name" defaultValue={displayName} className={inputCls} required maxLength={60} />
        </label>
        <div className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">شمارهٔ موبایل (تأییدشده)</span>
          <p className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 text-[var(--color-muted)]" dir="ltr">
            {toFaDigits(mobile)}
          </p>
        </div>
      </div>
      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}
      {state.ok && <p className="text-sm text-[var(--color-accent)]">ذخیره شد.</p>}
      <Button type="submit" size="sm" disabled={pending}>{pending ? "در حال ذخیره…" : "ذخیرهٔ پروفایل"}</Button>
    </form>
  );
}
