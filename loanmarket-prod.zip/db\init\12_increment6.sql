-- =====================================================================
-- Increment 6 · deal-flow depth helpers (req. D / E / S).
-- Idempotent. No money function is touched; these are read/seam helpers.
-- =====================================================================
SET check_function_bodies = off;

-- ---- D/E: store buyer accept-info (and special-user beneficiary note) --
-- RLS blocks a normal user from UPDATE-ing deals directly, so the accept
-- action goes through this SECURITY DEFINER seam. Only the buyer of the
-- deal, while it is still in the early (pre-transfer) state, may write it.
CREATE OR REPLACE FUNCTION deal_set_transfer_info(_deal uuid, _actor uuid, _info jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_seller_transfer' THEN RAISE EXCEPTION 'too late to edit transfer info'; END IF;
  UPDATE deals SET transfer_info = COALESCE(_info, '{}'::jsonb) WHERE id = _deal;
END $$;

-- ---- S: public reputation (avg score + count) for a user ----------------
-- ratings RLS is party-only; reputation must be visible to anyone browsing,
-- so expose an aggregate through a definer function (no per-rating leakage).
CREATE OR REPLACE FUNCTION user_reputation(_user uuid)
RETURNS TABLE(avg_score numeric, rating_count bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT round(avg(score)::numeric, 1), count(*)
  FROM ratings WHERE ratee_id = _user;
$$;

GRANT EXECUTE ON FUNCTION
  deal_set_transfer_info(uuid, uuid, jsonb),
  user_reputation(uuid)
TO app;
