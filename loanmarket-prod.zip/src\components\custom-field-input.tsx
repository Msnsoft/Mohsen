/** A single admin-defined loan-type custom field (req. B). */
export type CustomField = {
  key: string;
  label: string;
  field_type: string; // text | number | select | bool
  audience: string; // buyer | seller | both
  required: boolean;
  options: string[];
};

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

/**
 * Renders one custom field as a form input. The submitted name is
 * `custom:<key>` (listings) or `info:<key>` (accept-info) via `prefix`.
 */
export function CustomFieldInput({ field, prefix = "custom" }: { field: CustomField; prefix?: string }) {
  const name = `${prefix}:${field.key}`;
  if (field.field_type === "bool") {
    return (
      <label className="flex items-center gap-2 text-sm">
        <input type="checkbox" name={name} value="true" />
        {field.label}
        {field.required && <span className="text-[var(--color-danger)]">*</span>}
      </label>
    );
  }
  return (
    <label className="space-y-1.5 text-sm">
      <span className="text-[var(--color-muted)]">
        {field.label}
        {field.required && <span className="text-[var(--color-danger)]"> *</span>}
      </span>
      {field.field_type === "select" ? (
        <select name={name} className={inputCls} required={field.required} defaultValue="">
          <option value="" disabled>انتخاب کنید…</option>
          {field.options.map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
      ) : (
        <input
          name={name}
          className={inputCls}
          required={field.required}
          inputMode={field.field_type === "number" ? "numeric" : undefined}
          dir={field.field_type === "number" ? "ltr" : undefined}
        />
      )}
    </label>
  );
}
