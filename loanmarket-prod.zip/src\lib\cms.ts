import "server-only";
import { db, sql } from "@/db";

export interface MenuItem { label: string; url: string }
export interface Faq { id: string; question: string; answer: string }
export interface Widget { key: string; enabled: boolean; payload: Record<string, unknown>; sort: number }

/** Public CMS reads run as the anonymous role; RLS exposes only published/visible rows. */
export async function getMenu(location: "header" | "footer" | "landing"): Promise<MenuItem[]> {
  try {
    const rows = await db.execute<{ label: string; url: string }>(sql`
      select label, url from cms_menu_items
      where location = ${location} and visible order by sort, label`);
    return rows as { label: string; url: string }[];
  } catch {
    return [];
  }
}

export async function getFaqs(limit?: number): Promise<Faq[]> {
  try {
    const rows = await db.execute<{ id: string; question: string; answer: string }>(sql`
      select id, question, answer from cms_faqs where published
      order by sort ${limit ? sql`limit ${limit}` : sql``}`);
    return rows as Faq[];
  } catch {
    return [];
  }
}

export async function getWidgets(): Promise<Widget[]> {
  try {
    const rows = await db.execute<{ key: string; enabled: boolean; payload: Record<string, unknown>; sort: number }>(
      sql`select key, enabled, payload, sort from cms_widgets order by sort`,
    );
    return rows as Widget[];
  } catch {
    return [];
  }
}

export async function getWidget(key: string): Promise<Widget | null> {
  const all = await getWidgets();
  return all.find((w) => w.key === key) ?? null;
}

export interface SiteStats {
  users: number;
  active_listings: number;
  completed_deals: number;
  volume: number;
  loan_types: number;
}

/** Live public aggregates for the landing page (via SECURITY DEFINER fn; no PII). */
export async function getSiteStats(): Promise<SiteStats> {
  try {
    const rows = await db.execute<Record<keyof SiteStats, string>>(sql`select * from public_site_stats()`);
    const r = rows[0] as Record<keyof SiteStats, string> | undefined;
    return {
      users: Number(r?.users ?? 0),
      active_listings: Number(r?.active_listings ?? 0),
      completed_deals: Number(r?.completed_deals ?? 0),
      volume: Number(r?.volume ?? 0),
      loan_types: Number(r?.loan_types ?? 0),
    };
  } catch {
    return { users: 0, active_listings: 0, completed_deals: 0, volume: 0, loan_types: 0 };
  }
}

export const STAT_METRIC_FA: Record<string, string> = {
  users: "کاربران",
  active_listings: "آگهی‌های فعال",
  completed_deals: "معاملات موفق",
  volume: "حجم کل معاملات",
  loan_types: "انواع وام",
};

export async function getPage(slug: string): Promise<{ title: string; body: string } | null> {
  try {
    const rows = await db.execute<{ title: string; body: string }>(sql`
      select title, body from cms_pages where slug = ${slug} and published limit 1`);
    return (rows as { title: string; body: string }[])[0] ?? null;
  } catch {
    return null;
  }
}
