import Link from "next/link";
import { notFound } from "next/navigation";
import { requireActiveUser } from "@/lib/auth";
import { getDeal, getDealTimeline, hasRatedDeal } from "@/services/deals";
import { sellerTransferred, buyerConfirm, refundDeal } from "@/app/deals/actions";
import { db, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { DealTimeline } from "@/components/deal-timeline";
import { EvidenceList, EvidenceUpload } from "@/components/deal-evidence";
import { RatingForm } from "@/components/rating-form";
import { formatToman, formatTomanCompact, toFaDigits } from "@/lib/persian";
import { DEAL_STATE_FA, dealStateTone } from "../state";

export const dynamic = "force-dynamic";

export default async function DealDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ ev?: string; rate?: string }>;
}) {
  const { id } = await params;
  const { ev, rate } = await searchParams;
  const user = await requireActiveUser();
  const [d, timeline] = await Promise.all([getDeal(user.id, id), getDealTimeline(user.id, id)]);
  if (!d) notFound();

  const isBuyer = d.role === "buyer";
  const isSeller = d.role === "seller";
  const escrowOff = timeline?.escrow_state === "bypassed";

  // req. S: offer a rating once the deal is completed and not yet rated
  let ratingQuestions: string[] | null = null;
  if (d.state === "completed" && !(await hasRatedDeal(user.id, id))) {
    const cfg = (await db.execute<{ value: string[] }>(
      sql`select value from config where key = 'rating.questions'`,
    )) as { value: string[] }[];
    ratingQuestions = Array.isArray(cfg[0]?.value) ? cfg[0].value : [];
  }

  return (
    <div className="space-y-6">
      <Link href="/deals" className="text-sm text-[var(--color-muted)]">→ بازگشت به معاملات</Link>

      <Card>
        <div className="mb-4 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold">{d.loan_type_name}</h1>
            <p className="text-[var(--color-muted)]">{d.bank_name} · {isBuyer ? "فروشنده" : "خریدار"}: {d.counterparty}</p>
            <p className="mt-1 text-xs text-[var(--color-muted)]" dir="ltr">#{toFaDigits(d.id.slice(0, 8))}</p>
          </div>
          <Badge tone={dealStateTone(d.state)}>{DEAL_STATE_FA[d.state] ?? d.state}</Badge>
        </div>

        <dl className="grid grid-cols-2 gap-y-3 sm:grid-cols-4">
          <Stat label="ارزش وام" value={formatTomanCompact(d.loan_value)} />
          <Stat label="مبلغ امانی" value={formatToman(d.loan_price)} accent />
          <Stat label={isBuyer ? "کارمزد شما" : "کارمزد فروشنده"} value={formatToman(isBuyer ? d.buyer_fee : d.seller_fee)} />
          <Stat label={isSeller ? "دریافتی شما" : "پرداختی کل"} value={formatToman(isSeller ? d.loan_price - d.seller_fee : d.loan_price + d.buyer_fee)} />
        </dl>
      </Card>

      {/* Workflow timeline (req. O) */}
      {timeline && (
        <Card>
          <CardTitle>روند معامله</CardTitle>
          <div className="mt-4">
            <DealTimeline stages={timeline.stages} />
          </div>
        </Card>
      )}

      {/* Rating after completion (req. S) */}
      {ratingQuestions && (
        <Card>
          <CardTitle>امتیاز به طرف مقابل</CardTitle>
          <CardMuted className="mt-1">معامله تکمیل شد. لطفاً به عملکرد طرف مقابل امتیاز دهید.</CardMuted>
          <div className="mt-4">
            <RatingForm dealId={d.id} questions={ratingQuestions} />
          </div>
        </Card>
      )}
      {rate === "ok" && <Card><CardMuted>✓ امتیاز شما ثبت شد. سپاس‌گزاریم.</CardMuted></Card>}

      {/* Escrow-off manual settlement evidence (req. F) */}
      {escrowOff && timeline && d.state !== "cancelled" && (
        <Card>
          <CardTitle>مدارک تسویهٔ دستی</CardTitle>
          <CardMuted className="mt-1">
            این معامله بدون امانت (Escrow) است. لطفاً مدرک مربوطه را بارگذاری کنید تا مدیر بتواند تسویه را بررسی کند.
          </CardMuted>
          {ev === "ok" && <p className="mt-2 text-xs text-[var(--color-accent)]">فایل با موفقیت بارگذاری شد ✓</p>}
          {ev === "err" && <p className="mt-2 text-xs text-[var(--color-danger)]">بارگذاری فایل ناموفق بود (نوع/حجم فایل را بررسی کنید).</p>}
          <div className="mt-4 grid gap-4 sm:grid-cols-2">
            {isBuyer && <EvidenceUpload dealId={d.id} kind="payment_receipt" label="رسید پرداخت وجه را بارگذاری کنید" />}
            {isSeller && <EvidenceUpload dealId={d.id} kind="transfer_proof" label="مدرک انتقال امتیاز را بارگذاری کنید" />}
          </div>
          {timeline.evidence.length > 0 && (
            <div className="mt-5 border-t border-[var(--color-border)] pt-4">
              <p className="mb-2 text-sm font-medium">مدارک بارگذاری‌شده</p>
              <EvidenceList evidence={timeline.evidence} />
            </div>
          )}
        </Card>
      )}

      {/* Action panel */}
      <Card>
        <CardTitle>اقدام مورد نیاز</CardTitle>
        <div className="mt-3">
          {d.state === "waiting_seller_transfer" && isSeller && (
            <div className="space-y-3">
              <CardMuted>خریدار وجه را به امانت سپرده است. پس از انتقال وام، دکمهٔ زیر را بزنید.</CardMuted>
              <form action={sellerTransferred}>
                <input type="hidden" name="deal_id" value={d.id} />
                <Button type="submit">انتقال وام را انجام دادم</Button>
              </form>
            </div>
          )}
          {d.state === "waiting_seller_transfer" && isBuyer && (
            <div className="space-y-3">
              <CardMuted>
                منتظر انتقال وام توسط فروشنده هستیم. تا پیش از انتقال می‌توانید لغو کنید؛ اما طبق قوانین لغو،
                مبلغ امانی بازمی‌گردد و {escrowOff ? "این معامله کارمزدی ندارد" : "کارمزد بازگردانده نمی‌شود"}.
              </CardMuted>
              <form action={refundDeal}>
                <input type="hidden" name="deal_id" value={d.id} />
                <Button type="submit" variant="outline">لغو معامله</Button>
              </form>
            </div>
          )}
          {d.state === "waiting_buyer_confirmation" && isBuyer && (
            <div className="space-y-3">
              <CardMuted>فروشنده اعلام کرده وام منتقل شده است. پس از بررسی، دریافت را تأیید کنید تا وجه به فروشنده پرداخت شود.</CardMuted>
              <form action={buyerConfirm}>
                <input type="hidden" name="deal_id" value={d.id} />
                <Button type="submit" variant="accent">دریافت وام را تأیید می‌کنم</Button>
              </form>
            </div>
          )}
          {d.state === "waiting_buyer_confirmation" && isSeller && (
            <CardMuted>منتظر تأیید دریافت توسط خریدار هستیم. در صورت عدم پاسخ، پس از پایان مهلت بازبینی به‌صورت خودکار تسویه می‌شود.</CardMuted>
          )}
          {d.state === "completed" && <CardMuted>✓ این معامله با موفقیت تکمیل شده است.</CardMuted>}
          {d.state === "cancelled" && <CardMuted>این معامله لغو و وجه بازگردانده شده است.</CardMuted>}
        </div>
      </Card>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-sm text-[var(--color-muted)]">{label}</dt>
      <dd className={`mt-0.5 font-semibold ${accent ? "text-[var(--color-accent)]" : ""}`}>{value}</dd>
    </div>
  );
}
