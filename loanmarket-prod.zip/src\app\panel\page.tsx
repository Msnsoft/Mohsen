import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatToman, toFaDigits } from "@/lib/persian";
import { POST_STATUS_FA, postStatusTone } from "@/lib/post-status";
import { DEAL_STATE_FA, dealStateTone } from "@/app/deals/state";
import { getMembership } from "@/lib/entitlements";

export const dynamic = "force-dynamic";

export default async function PanelOverview() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const membership = await getMembership(user.id);

  const data = await withUser(user.id, async (tx) => {
    const counts = await tx.execute<{
      my_posts: string; active_posts: string; pending_posts: string;
      open_deals: string; held: string;
    }>(sql`
      select
        (select count(*) from loan_posts where user_id = ${user.id})::text as my_posts,
        (select count(*) from loan_posts where user_id = ${user.id} and status = 'active')::text as active_posts,
        (select count(*) from loan_posts where user_id = ${user.id} and status = 'pending_review')::text as pending_posts,
        (select count(*) from deals where (buyer_id = ${user.id} or seller_id = ${user.id})
           and state in ('waiting_seller_transfer','waiting_buyer_confirmation'))::text as open_deals,
        wallet_balance(${user.id}, 'held')::text as held
    `);
    const recentPosts = await tx.execute<{
      id: string; type: string; status: string; loan_value: string; created_at: string; loan_type_name: string;
    }>(sql`
      select p.id, p.type, p.status, p.loan_value::text, p.created_at::text, t.name as loan_type_name
      from loan_posts p join loan_types t on t.id = p.loan_type_id
      where p.user_id = ${user.id} order by p.created_at desc limit 5`);
    const recentDeals = await tx.execute<{
      id: string; state: string; loan_price: string; created_at: string;
    }>(sql`
      select id, state, loan_price::text, created_at::text from deals
      where buyer_id = ${user.id} or seller_id = ${user.id}
      order by created_at desc limit 5`);
    const recentMessages = await tx.execute<{
      id: string; title: string; read: boolean; created_at: string;
    }>(sql`
      select id, title, read, created_at::text from notifications
      where user_id = ${user.id} order by created_at desc limit 5`);
    return { counts: counts[0], recentPosts, recentDeals, recentMessages };
  });

  const stats = [
    { label: "آگهی‌های من", value: toFaDigits(data.counts?.my_posts ?? "0"), href: "/panel/loans" },
    { label: "آگهی‌های فعال", value: toFaDigits(data.counts?.active_posts ?? "0"), href: "/panel/loans?status=active" },
    { label: "در انتظار بررسی", value: toFaDigits(data.counts?.pending_posts ?? "0"), href: "/panel/loans?status=pending_review" },
    { label: "معاملات جاری", value: toFaDigits(data.counts?.open_deals ?? "0"), href: "/deals" },
    { label: "موجودی کیف پول", value: formatToman(user.availableBalance), href: "/wallet" },
    { label: "پیام‌های خوانده‌نشده", value: toFaDigits(user.unreadMessages), href: "/panel/messages" },
  ];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">سلام، {user.displayName ?? user.mobile} 👋</h1>
        <Link href="/panel/loans/new" className="text-sm text-[var(--color-primary)]">+ ثبت وام جدید</Link>
      </div>

      <Link href="/membership" className="block">
        <Card className="flex flex-wrap items-center gap-3 text-sm transition-colors hover:border-[var(--color-primary)]">
          {membership ? (
            <>
              <Badge tone="accent">اشتراک «{membership.planName}»</Badge>
              <span className="text-[var(--color-muted)]">
                فعال تا <span dir="ltr">{toFaDigits(membership.expiresAt.slice(0, 10))}</span> · برای تمدید کلیک کنید
              </span>
            </>
          ) : (
            <>
              <Badge tone="muted">پلن رایگان</Badge>
              <span className="text-[var(--color-muted)]">با خرید اشتراک، مشاورهٔ قیمت و ماشین‌حساب پیشرفته را فعال کنید ←</span>
            </>
          )}
        </Card>
      </Link>

      <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
        {stats.map((s) => (
          <Link key={s.label} href={s.href}>
            <Card className="transition-colors hover:border-[var(--color-primary)]">
              <CardMuted>{s.label}</CardMuted>
              <p className="mt-1 text-xl font-extrabold">{s.value}</p>
            </Card>
          </Link>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <Card className="space-y-3">
          <div className="flex items-center justify-between">
            <CardTitle>آخرین آگهی‌های من</CardTitle>
            <Link href="/panel/loans" className="text-xs text-[var(--color-primary)]">همه ←</Link>
          </div>
          {data.recentPosts.length === 0 ? (
            <CardMuted>هنوز آگهی‌ای ثبت نکرده‌اید. <Link className="text-[var(--color-primary)]" href="/panel/loans/new">ثبت وام جدید</Link></CardMuted>
          ) : (
            <ul className="space-y-2">
              {data.recentPosts.map((p) => (
                <li key={p.id} className="flex items-center justify-between gap-2 rounded-lg bg-[var(--color-surface-2)] px-3 py-2 text-sm">
                  <span>{p.loan_type_name} · {formatToman(Number(p.loan_value))}</span>
                  <Badge tone={postStatusTone(p.status)}>{POST_STATUS_FA[p.status] ?? p.status}</Badge>
                </li>
              ))}
            </ul>
          )}
        </Card>

        <Card className="space-y-3">
          <div className="flex items-center justify-between">
            <CardTitle>آخرین معاملات</CardTitle>
            <Link href="/deals" className="text-xs text-[var(--color-primary)]">همه ←</Link>
          </div>
          {data.recentDeals.length === 0 ? (
            <CardMuted>هنوز معامله‌ای ندارید.</CardMuted>
          ) : (
            <ul className="space-y-2">
              {data.recentDeals.map((d) => (
                <li key={d.id}>
                  <Link href={`/deals/${d.id}`} className="flex items-center justify-between gap-2 rounded-lg bg-[var(--color-surface-2)] px-3 py-2 text-sm hover:bg-[var(--color-surface)]">
                    <span>{formatToman(Number(d.loan_price))}</span>
                    <Badge tone={dealStateTone(d.state)}>{DEAL_STATE_FA[d.state] ?? d.state}</Badge>
                  </Link>
                </li>
              ))}
            </ul>
          )}
        </Card>
      </div>

      <Card className="space-y-3">
        <div className="flex items-center justify-between">
          <CardTitle>آخرین پیام‌ها</CardTitle>
          <Link href="/panel/messages" className="text-xs text-[var(--color-primary)]">همه ←</Link>
        </div>
        {data.recentMessages.length === 0 ? (
          <CardMuted>پیامی ندارید.</CardMuted>
        ) : (
          <ul className="space-y-2">
            {data.recentMessages.map((m) => (
              <li key={m.id} className="flex items-center gap-2 rounded-lg bg-[var(--color-surface-2)] px-3 py-2 text-sm">
                {!m.read && <span className="h-2 w-2 shrink-0 rounded-full bg-[var(--color-primary)]" />}
                <span className={m.read ? "text-[var(--color-muted)]" : "font-medium"}>{m.title}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>
    </div>
  );
}
