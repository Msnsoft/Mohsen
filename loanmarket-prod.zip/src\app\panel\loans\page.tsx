import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, formatPercent, toFaDigits } from "@/lib/persian";
import { POST_STATUS_FA, postStatusTone, CANCELLABLE_STATUSES } from "@/lib/post-status";
import { cancelPostAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function MyLoansPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { status } = await searchParams;

  const posts = await withUser(user.id, (tx) =>
    tx.execute<{
      id: string; type: string; status: string; loan_value: string; loan_price: string;
      price_per_million: string | null; rate: string | null; duration_months: number | null;
      province: string | null; created_at: string; loan_type_name: string; bank_name: string | null;
    }>(sql`
      select p.id, p.type, p.status, p.loan_value::text, p.loan_price::text,
             p.price_per_million::text, p.rate::text, p.duration_months, p.province,
             p.created_at::text, t.name as loan_type_name, t.bank_name
      from loan_posts p join loan_types t on t.id = p.loan_type_id
      where p.user_id = ${user.id}
        and (${status ?? null}::text is null or p.status = ${status ?? null})
      order by p.created_at desc`),
  );

  const chips = ["", "active", "pending_review", "sold", "cancelled", "rejected"];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">وام‌های من</h1>
        <Link href="/panel/loans/new"><Button size="sm">+ ثبت وام جدید</Button></Link>
      </div>

      <div className="flex flex-wrap gap-2">
        {chips.map((c) => (
          <Link
            key={c || "all"}
            href={c ? `/panel/loans?status=${c}` : "/panel/loans"}
            className={`rounded-full border px-3 py-1 text-xs ${
              (status ?? "") === c
                ? "border-[var(--color-primary)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {c ? POST_STATUS_FA[c] : "همه"}
          </Link>
        ))}
      </div>

      {posts.length === 0 ? (
        <Card><CardMuted>آگهی‌ای با این وضعیت ندارید.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {posts.map((p) => (
            <Card key={p.id} className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <div className="flex items-center gap-2">
                  <span className="font-semibold">{p.loan_type_name}</span>
                  {p.bank_name && <span className="text-xs text-[var(--color-muted)]">{p.bank_name}</span>}
                  <Badge tone={p.type === "sell" ? "accent" : "warning"}>{p.type === "sell" ? "فروش" : "خرید"}</Badge>
                  <Badge tone={postStatusTone(p.status)}>{POST_STATUS_FA[p.status] ?? p.status}</Badge>
                </div>
                <p className="text-sm text-[var(--color-muted)]">
                  مبلغ وام {formatToman(Number(p.loan_value))} · قیمت {formatToman(Number(p.loan_price))}
                  {p.price_per_million && <> · هر میلیون {formatToman(Number(p.price_per_million))}</>}
                  {p.rate && <> · نرخ {formatPercent(p.rate)}</>}
                  {p.duration_months && <> · {toFaDigits(p.duration_months)} ماه</>}
                  {p.province && <> · {p.province}</>}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {p.status === "active" && (
                  <Link href={`/marketplace/${p.id}`}><Button variant="outline" size="sm">مشاهده</Button></Link>
                )}
                {CANCELLABLE_STATUSES.includes(p.status) && (
                  <form action={cancelPostAction}>
                    <input type="hidden" name="post_id" value={p.id} />
                    <Button variant="ghost" size="sm" type="submit" className="text-[var(--color-danger)]">لغو</Button>
                  </form>
                )}
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
