"use client";
import { useActionState, useState } from "react";
import { depositAction, type DepositState } from "./actions";
import { Button } from "@/components/ui/button";
import { toFaDigits } from "@/lib/persian";

const PRESETS_TOMAN = [1_000_000, 5_000_000, 20_000_000, 50_000_000];
const PRESETS_MILLION = [1, 5, 20, 50];

export function DepositForm({ prefersMillion = false }: { prefersMillion?: boolean }) {
  const [state, action, pending] = useActionState<DepositState, FormData>(depositAction, {});
  const [amount, setAmount] = useState("");
  const unit = prefersMillion ? "million" : "toman";
  const presets = prefersMillion ? PRESETS_MILLION : PRESETS_TOMAN;
  const unitLabel = prefersMillion ? "میلیون تومان" : "تومان";

  return (
    <form action={action} className="space-y-3">
      <input type="hidden" name="unit" value={unit} />
      <label className="block text-sm text-[var(--color-muted)]">مبلغ شارژ ({unitLabel})</label>
      <input
        name="amount" inputMode="numeric" placeholder={prefersMillion ? "۱" : "۱٬۰۰۰٬۰۰۰"} dir="ltr"
        value={amount}
        onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
        className="w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]"
        required
      />
      {/* clickable quick-charge presets (fill the amount, then submit) */}
      <div className="flex flex-wrap gap-2">
        {presets.map((v) => (
          <button
            key={v}
            type="button"
            onClick={() => setAmount(String(v))}
            className={`rounded-lg border px-3 py-1.5 text-xs transition-colors hover:border-[var(--color-primary)] ${
              amount === String(v) ? "border-[var(--color-primary)] text-[var(--color-primary)]" : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {toFaDigits(v.toLocaleString("en-US"))} {unitLabel}
          </button>
        ))}
      </div>
      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}
      {state.ok && <p className="text-sm text-[var(--color-accent)]">شارژ با موفقیت ثبت شد.</p>}
      <Button className="w-full" type="submit" disabled={pending}>
        {pending ? "در حال ثبت…" : "شارژ کیف پول"}
      </Button>
      <p className="text-xs text-[var(--color-muted)]">
        در نسخهٔ نمونه واریز مستقیماً ثبت می‌شود (بدون درگاه). در محصول واقعی از طریق درگاه/PSP انجام می‌شود.
      </p>
    </form>
  );
}
