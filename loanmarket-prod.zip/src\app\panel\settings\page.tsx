import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { THEMES } from "@/lib/themes";
import { setThemeAction, setPrefersMillionAction } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { ProfileForm } from "./profile-form";

export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">تنظیمات</h1>

      <Card className="space-y-4">
        <CardTitle>پروفایل</CardTitle>
        <ProfileForm displayName={user.displayName ?? ""} mobile={user.mobile} />
      </Card>

      <Card className="space-y-3">
        <CardTitle>واحد ورود مبالغ</CardTitle>
        <CardMuted>اگر فعال باشد، مبالغ را به «میلیون تومان» وارد می‌کنید (مثلاً ۱۵۰ یعنی ۱۵۰٬۰۰۰٬۰۰۰ تومان). این انتخاب روی حساب شما ذخیره می‌شود.</CardMuted>
        <form action={setPrefersMillionAction} className="flex items-center gap-3">
          <label className="flex items-center gap-2 text-sm">
            <input type="checkbox" name="prefers_million" defaultChecked={user.prefersMillion} />
            ورود مبالغ به میلیون تومان
          </label>
          <Button type="submit" size="sm" variant="outline">ذخیره</Button>
        </form>
      </Card>

      <Card className="space-y-4">
        <CardTitle>تم رنگی</CardTitle>
        <CardMuted>یکی از ۶ مجموعه‌رنگ را انتخاب کنید؛ انتخاب شما روی حساب‌تان ذخیره می‌شود و در همهٔ دستگاه‌ها اعمال خواهد شد.</CardMuted>
        <form action={setThemeAction} className="grid grid-cols-2 gap-3 sm:grid-cols-3">
          {THEMES.map((t) => (
            <button
              key={t.key}
              type="submit"
              name="theme"
              value={t.key}
              className={`flex items-center gap-3 rounded-xl border p-3 text-sm transition-colors hover:border-[var(--color-primary)] ${
                user.theme === t.key ? "border-[var(--color-primary)] bg-[var(--color-surface-2)]" : "border-[var(--color-border)]"
              }`}
            >
              <span className="flex h-9 w-9 shrink-0 overflow-hidden rounded-lg border border-[var(--color-border)]">
                <span className="h-full w-1/2" style={{ background: t.bg }} />
                <span className="flex h-full w-1/2 flex-col">
                  <span className="h-1/2" style={{ background: t.primary }} />
                  <span className="h-1/2" style={{ background: t.accent }} />
                </span>
              </span>
              <span className="font-medium">
                {t.label}
                {user.theme === t.key && <span className="mr-1 text-xs text-[var(--color-primary)]">✓ فعال</span>}
              </span>
            </button>
          ))}
        </form>
      </Card>
    </div>
  );
}
