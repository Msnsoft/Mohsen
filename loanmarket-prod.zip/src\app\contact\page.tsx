import { Mail, Phone, MapPin } from "lucide-react";
import { db, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { ContactForm } from "./contact-form";

export const dynamic = "force-dynamic";

async function contactInfo() {
  try {
    const rows = await db.execute<{ key: string; value: string }>(
      sql`select key, value::text as value from config where key in ('contact.phone','contact.email','contact.address')`,
    );
    const m = Object.fromEntries((rows as { key: string; value: string }[]).map((r) => [r.key, r.value?.replace(/^"|"$/g, "") ?? ""]));
    return {
      phone: m["contact.phone"] || "۰۲۱-۱۲۳۴۵۶۷۸",
      email: m["contact.email"] || "support@example.com",
      address: m["contact.address"] || "تهران، ایران",
    };
  } catch {
    return { phone: "۰۲۱-۱۲۳۴۵۶۷۸", email: "support@example.com", address: "تهران، ایران" };
  }
}

export default async function ContactPage() {
  const info = await contactInfo();
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">تماس با ما</h1>
      <div className="grid gap-6 md:grid-cols-2">
        <Card className="space-y-4">
          <CardTitle>راه‌های ارتباطی</CardTitle>
          <CardMuted>برای پشتیبانی سریع از فرم کنار استفاده کنید؛ پیام شما به‌صورت تیکت پیگیری می‌شود.</CardMuted>
          <ul className="space-y-3 text-sm">
            <li className="flex items-center gap-3"><Phone size={18} className="text-[var(--color-primary)]" /><span dir="ltr">{info.phone}</span></li>
            <li className="flex items-center gap-3"><Mail size={18} className="text-[var(--color-primary)]" /><span dir="ltr">{info.email}</span></li>
            <li className="flex items-center gap-3"><MapPin size={18} className="text-[var(--color-primary)]" />{info.address}</li>
          </ul>
        </Card>
        <Card className="space-y-4">
          <CardTitle>فرم تماس</CardTitle>
          <ContactForm />
        </Card>
      </div>
    </div>
  );
}
