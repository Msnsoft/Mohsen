"use client";
import { useActionState, useState } from "react";
import { sendOtpAction, verifyOtpAction, type SendState, type VerifyState } from "./actions";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 text-center text-lg tracking-widest outline-none focus:border-[var(--color-primary)]";

export default function LoginPage() {
  const [send, sendAction, sending] = useActionState<SendState, FormData>(sendOtpAction, { ok: false });
  const [verify, verifyAction, verifying] = useActionState<VerifyState, FormData>(verifyOtpAction, { ok: false });
  const [mobile, setMobile] = useState("");

  return (
    <div className="mx-auto max-w-md py-10">
      <Card className="space-y-5">
        <div>
          <CardTitle>ورود / ثبت‌نام</CardTitle>
          <CardMuted>با شمارهٔ موبایل خود وارد شوید؛ کد یک‌بارمصرف ارسال می‌شود.</CardMuted>
        </div>

        {!send.ok ? (
          <form action={sendAction} className="space-y-3">
            <input
              name="mobile" inputMode="numeric" placeholder="۰۹۱۲۳۴۵۶۷۸۹" dir="ltr"
              value={mobile} onChange={(e) => setMobile(e.target.value)} className={inputCls} required
            />
            {send.error && <p className="text-sm text-[var(--color-danger)]">{send.error}</p>}
            <Button className="w-full" type="submit" disabled={sending}>
              {sending ? "در حال ارسال…" : "ارسال کد"}
            </Button>
          </form>
        ) : (
          <form action={verifyAction} className="space-y-3">
            <input type="hidden" name="mobile" value={send.mobile} />
            <p className="text-sm text-[var(--color-muted)]">
              کد ارسال‌شده به {send.mobile} را وارد کنید.
            </p>
            {send.devCode && (
              <p className="rounded-lg bg-[var(--color-surface-2)] p-2 text-center text-sm">
                کد توسعه (DEV): <b dir="ltr">{send.devCode}</b>
              </p>
            )}
            <input name="code" inputMode="numeric" maxLength={6} placeholder="------" dir="ltr" className={inputCls} required />
            {verify.error && <p className="text-sm text-[var(--color-danger)]">{verify.error}</p>}
            <Button className="w-full" type="submit" disabled={verifying}>
              {verifying ? "در حال بررسی…" : "ورود"}
            </Button>
          </form>
        )}
      </Card>
    </div>
  );
}
