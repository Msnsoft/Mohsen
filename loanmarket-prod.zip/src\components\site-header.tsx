import Link from "next/link";
import { Wallet, Home, Store, Crown, Calculator, Handshake, LayoutDashboard, Bell, Settings } from "lucide-react";
import { formatToman, toFaDigits } from "@/lib/persian";
import { logout } from "@/app/actions";
import { Button } from "@/components/ui/button";
import { ThemeSwitcher } from "@/components/theme-switcher";

interface HeaderUser {
  displayName: string;
  isAdmin: boolean;
  balance: number;
  unreadMessages: number;
}

export function SiteHeader({
  user, theme, siteName = "بازار امتیاز وام", logoUrl = "",
}: { user: HeaderUser | null; theme: string; siteName?: string; logoUrl?: string }) {
  return (
    <header className="sticky top-0 z-30 border-b border-[var(--color-border)] bg-[color-mix(in_oklab,var(--color-bg)_85%,transparent)] backdrop-blur">
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-4 py-3">
        <Link href="/" className="flex items-center gap-2 text-lg font-bold">
          {logoUrl ? (
            // eslint-disable-next-line @next/next/no-img-element
            <img src={logoUrl} alt={siteName} className="h-9 w-auto" />
          ) : (
            <span className="grid h-9 w-9 place-items-center rounded-xl bg-[var(--color-primary)] text-white">و</span>
          )}
          {siteName}
        </Link>

        <nav className="hidden items-center gap-1 md:flex">
          <NavLink href="/" icon={<Home size={16} />}>خانه</NavLink>
          <NavLink href="/marketplace" icon={<Store size={16} />}>بازار</NavLink>
          <NavLink href="/calculator" icon={<Calculator size={16} />}>محاسبه‌گر</NavLink>
          <NavLink href="/membership" icon={<Crown size={16} />}>اشتراک</NavLink>
          {user && <NavLink href="/deals" icon={<Handshake size={16} />}>معاملات</NavLink>}
          {user && <NavLink href="/panel" icon={<LayoutDashboard size={16} />}>پنل کاربری</NavLink>}
          {user && <NavLink href="/wallet" icon={<Wallet size={16} />}>کیف پول</NavLink>}
          {user?.isAdmin && <NavLink href="/admin" icon={<Settings size={16} />}>مدیریت</NavLink>}
        </nav>

        <div className="flex items-center gap-2">
          <ThemeSwitcher current={theme} />
          {user ? (
            <>
              <Link
                href="/panel/messages"
                className="relative grid h-9 w-9 place-items-center rounded-lg border border-[var(--color-border)] text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]"
                title="پیام‌ها"
              >
                <Bell size={16} />
                {user.unreadMessages > 0 && (
                  <span className="absolute -left-1 -top-1 grid h-4 min-w-4 place-items-center rounded-full bg-[var(--color-danger)] px-1 text-[10px] font-bold text-white">
                    {toFaDigits(user.unreadMessages)}
                  </span>
                )}
              </Link>
              <Link href="/wallet" className="hidden rounded-lg border border-[var(--color-border)] px-3 py-1.5 text-sm sm:block">
                {formatToman(user.balance)}
              </Link>
              <Link href="/panel" className="hidden text-sm text-[var(--color-muted)] sm:block">{user.displayName}</Link>
              <form action={logout}>
                <Button variant="outline" size="sm" type="submit">خروج</Button>
              </form>
            </>
          ) : (
            <Link href="/login"><Button size="sm">ورود / ثبت‌نام</Button></Link>
          )}
        </div>
      </div>
    </header>
  );
}

function NavLink({ href, icon, children }: { href: string; icon: React.ReactNode; children: React.ReactNode }) {
  return (
    <Link href={href} className="flex items-center gap-1.5 rounded-lg px-3 py-2 text-sm text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]">
      {icon}{children}
    </Link>
  );
}
