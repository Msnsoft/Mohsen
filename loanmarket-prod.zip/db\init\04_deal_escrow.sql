-- =====================================================================
-- Increment 2: Deal + Escrow + Commission engine.
-- In-house escrow engine; internal-ledger custody by default (D4).
-- Money flow (principal = loan_price, the premium the buyer pays the seller):
--   start:   buyer.available -(loan_price+buyer_fee);  escrow_liability +loan_price;  buyer.held +buyer_fee
--   release: escrow_liability -loan_price;  seller.available +(loan_price-seller_fee);
--            platform_revenue +seller_fee;  buyer.held -buyer_fee;  platform_revenue +buyer_fee
--   refund:  escrow_liability -loan_price;  buyer.available +loan_price;  buyer.held -buyer_fee; buyer.available +buyer_fee
-- =====================================================================
SET check_function_bodies = off;

CREATE TABLE IF NOT EXISTS deals (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  listing_id    uuid NOT NULL REFERENCES loan_posts(id),
  buyer_id      uuid NOT NULL REFERENCES users(id),
  seller_id     uuid NOT NULL REFERENCES users(id),
  loan_type_id  uuid NOT NULL REFERENCES loan_types(id),
  loan_value    bigint NOT NULL,
  loan_price    bigint NOT NULL,         -- escrowed amount (premium)
  buyer_fee     bigint NOT NULL DEFAULT 0,
  seller_fee    bigint NOT NULL DEFAULT 0,
  state         text NOT NULL DEFAULT 'draft',
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  completed_at  timestamptz
);
CREATE INDEX IF NOT EXISTS deals_buyer_idx ON deals(buyer_id, created_at DESC);
CREATE INDEX IF NOT EXISTS deals_seller_idx ON deals(seller_id, created_at DESC);

CREATE TABLE IF NOT EXISTS escrows (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id         uuid NOT NULL UNIQUE REFERENCES deals(id) ON DELETE CASCADE,
  buyer_id        uuid NOT NULL,
  seller_id       uuid NOT NULL,
  amount          bigint NOT NULL,
  state           text NOT NULL DEFAULT 'funded',
  inspection_hours int NOT NULL DEFAULT 72,
  inspection_started_at timestamptz,
  auto_release_at timestamptz,
  funded_at       timestamptz,
  released_at     timestamptz,
  refunded_at     timestamptz,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS escrow_events (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  escrow_id  uuid NOT NULL REFERENCES escrows(id) ON DELETE CASCADE,
  from_state text, to_state text, actor_id uuid, reason text,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS commission_charges (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id     uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  payer_id    uuid NOT NULL,
  side        text NOT NULL,
  amount      bigint NOT NULL,
  state       text NOT NULL DEFAULT 'quoted',   -- quoted|held|captured|reversed
  created_at  timestamptz NOT NULL DEFAULT now()
);

CREATE TRIGGER trg_deals_updated BEFORE UPDATE ON deals FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE escrows ENABLE ROW LEVEL SECURITY;
ALTER TABLE escrow_events ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_charges ENABLE ROW LEVEL SECURITY;

CREATE POLICY p_deals_party ON deals FOR SELECT
  USING (buyer_id = current_user_id() OR seller_id = current_user_id() OR is_admin());
CREATE POLICY p_escrows_party ON escrows FOR SELECT
  USING (buyer_id = current_user_id() OR seller_id = current_user_id() OR is_admin());
CREATE POLICY p_escrow_events_party ON escrow_events FOR SELECT
  USING (is_admin() OR escrow_id IN (SELECT id FROM escrows WHERE buyer_id = current_user_id() OR seller_id = current_user_id()));
CREATE POLICY p_charges_party ON commission_charges FOR SELECT
  USING (payer_id = current_user_id() OR is_admin()
         OR deal_id IN (SELECT id FROM deals WHERE buyer_id = current_user_id() OR seller_id = current_user_id()));

-- =====================================================================
-- Commission computation (percent OR progressive marginal tiers).
-- rate_per_million is IRR fee per 1,000,000 TOMAN (=10,000,000 IRR) of value.
-- =====================================================================
CREATE OR REPLACE FUNCTION commission_compute(_loan_type uuid, _side text, _amount bigint)
RETURNS bigint LANGUAGE plpgsql STABLE SECURITY DEFINER SET search_path = public AS $$
DECLARE _rule commission_rules%ROWTYPE; _b commission_bands%ROWTYPE; _fee numeric := 0; _covered bigint; _prorate bool;
BEGIN
  SELECT * INTO _rule FROM commission_rules WHERE loan_type_id = _loan_type AND side = _side AND active ORDER BY created_at DESC LIMIT 1;
  IF NOT FOUND THEN
    SELECT * INTO _rule FROM commission_rules WHERE loan_type_id IS NULL AND side = _side AND active ORDER BY created_at DESC LIMIT 1;
  END IF;
  IF NOT FOUND THEN RETURN 0; END IF;

  IF _rule.method = 'percent' THEN
    _fee := floor(_amount * COALESCE(_rule.percent_rate, 0) / 100);
  ELSE
    SELECT (value::text)::bool INTO _prorate FROM config WHERE key = 'commission.prorate_partial_band';
    _prorate := COALESCE(_prorate, true);
    FOR _b IN SELECT * FROM commission_bands WHERE rule_id = _rule.id ORDER BY sort LOOP
      IF _amount <= _b.from_amount THEN CONTINUE; END IF;
      IF _b.to_amount IS NULL THEN
        _covered := _amount - _b.from_amount;
        _fee := _fee + floor(_covered::numeric / 10000000 * COALESCE(_b.rate_per_million, 0));
      ELSIF _amount >= _b.to_amount THEN
        IF _b.amount_per_band IS NOT NULL THEN _fee := _fee + _b.amount_per_band;
        ELSE _fee := _fee + floor((_b.to_amount - _b.from_amount)::numeric / 10000000 * COALESCE(_b.rate_per_million, 0)); END IF;
      ELSE
        _covered := _amount - _b.from_amount;
        IF _b.amount_per_band IS NOT NULL THEN
          IF _prorate THEN _fee := _fee + floor(_b.amount_per_band::numeric * _covered / (_b.to_amount - _b.from_amount));
          ELSE _fee := _fee + _b.amount_per_band; END IF;
        ELSE
          _fee := _fee + floor(_covered::numeric / 10000000 * COALESCE(_b.rate_per_million, 0));
        END IF;
      END IF;
    END LOOP;
  END IF;
  _fee := (_fee + COALESCE(_rule.base_fee, 0)) * (1 + COALESCE(_rule.tax_rate, 0));
  RETURN floor(_fee);
END $$;

-- =====================================================================
-- deal_start: buyer funds escrow + fee from wallet (internal-ledger custody)
-- =====================================================================
CREATE OR REPLACE FUNCTION deal_start(_listing uuid, _buyer uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _l loan_posts%ROWTYPE; _buyer_fee bigint; _seller_fee bigint; _total bigint;
        _avail bigint; _deal uuid; _escrow uuid;
        _b_avail uuid; _b_held uuid; _esc uuid; _ins int;
BEGIN
  SELECT * INTO _l FROM loan_posts WHERE id = _listing FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'listing not found'; END IF;
  IF _l.status <> 'active' THEN RAISE EXCEPTION 'listing not available'; END IF;
  IF _l.type <> 'sell' THEN RAISE EXCEPTION 'only sell listings supported here'; END IF;
  IF _l.user_id = _buyer THEN RAISE EXCEPTION 'cannot buy own listing'; END IF;

  _buyer_fee  := commission_compute(_l.loan_type_id, 'buyer',  _l.loan_price);
  _seller_fee := commission_compute(_l.loan_type_id, 'seller', _l.loan_price);
  _total := _l.loan_price + _buyer_fee;

  _avail := wallet_balance(_buyer, 'available');
  IF _avail < _total THEN RAISE EXCEPTION 'insufficient balance: need %, have %', _total, _avail; END IF;

  SELECT (value::text)::int INTO _ins FROM config WHERE key = 'escrow.inspection_hours';
  _ins := COALESCE(_ins, 72);

  INSERT INTO deals(listing_id, buyer_id, seller_id, loan_type_id, loan_value, loan_price, buyer_fee, seller_fee, state)
  VALUES (_listing, _buyer, _l.user_id, _l.loan_type_id, _l.loan_value, _l.loan_price, _buyer_fee, _seller_fee, 'waiting_seller_transfer')
  RETURNING id INTO _deal;

  INSERT INTO escrows(deal_id, buyer_id, seller_id, amount, state, inspection_hours, funded_at)
  VALUES (_deal, _buyer, _l.user_id, _l.loan_price, 'funded', _ins, now()) RETURNING id INTO _escrow;

  -- ledger: fund principal + hold buyer fee
  _b_avail := user_account(_buyer, 'available');
  _b_held  := user_account(_buyer, 'held');
  _esc     := system_account('escrow_liability');
  PERFORM post_transaction('escrow_fund', 'deal_fund_' || _deal, _deal::text, _buyer,
    jsonb_build_array(
      jsonb_build_object('account_id', _b_avail, 'amount', -_total),
      jsonb_build_object('account_id', _esc,     'amount',  _l.loan_price),
      jsonb_build_object('account_id', _b_held,  'amount',  _buyer_fee)
    ));

  INSERT INTO commission_charges(deal_id, payer_id, side, amount, state) VALUES
    (_deal, _buyer,     'buyer',  _buyer_fee,  'held'),
    (_deal, _l.user_id, 'seller', _seller_fee, 'quoted');

  UPDATE loan_posts SET status = 'sold', updated_at = now() WHERE id = _listing;
  INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_escrow, 'funded', _buyer, 'deal started, escrow funded from wallet');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_l.user_id, 'درخواست خرید جدید', 'خریدار وجه را به امانت سپرد. لطفاً وام را منتقل کنید.');
  RETURN _deal;
END $$;

-- seller marks the loan transferred → inspection window starts
CREATE OR REPLACE FUNCTION deal_seller_transferred(_deal uuid, _actor uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.seller_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_seller_transfer' THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;
  UPDATE escrows SET state = 'in_inspection', inspection_started_at = now(),
    auto_release_at = now() + (_e.inspection_hours || ' hours')::interval WHERE id = _e.id;
  UPDATE deals SET state = 'waiting_buyer_confirmation' WHERE id = _deal;
  INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'funded', 'in_inspection', _actor, 'seller transferred');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.buyer_id, 'وام منتقل شد', 'فروشنده اعلام کرد وام منتقل شده است. لطفاً پس از بررسی، دریافت را تأیید کنید.');
END $$;

-- buyer confirms receipt → release to seller + capture commissions
CREATE OR REPLACE FUNCTION deal_buyer_confirm(_deal uuid, _actor uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE; _esc uuid; _s_avail uuid; _b_held uuid; _rev uuid;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_buyer_confirmation' THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;
  _esc     := system_account('escrow_liability');
  _rev     := system_account('platform_revenue');
  _s_avail := user_account(_d.seller_id, 'available');
  _b_held  := user_account(_d.buyer_id, 'held');

  PERFORM post_transaction('escrow_release', 'deal_release_' || _deal, _deal::text, _actor,
    jsonb_build_array(
      jsonb_build_object('account_id', _esc,     'amount', -_d.loan_price),
      jsonb_build_object('account_id', _s_avail, 'amount',  _d.loan_price - _d.seller_fee),
      jsonb_build_object('account_id', _rev,     'amount',  _d.seller_fee),
      jsonb_build_object('account_id', _b_held,  'amount', -_d.buyer_fee),
      jsonb_build_object('account_id', _rev,     'amount',  _d.buyer_fee)
    ));

  UPDATE escrows SET state = 'released', released_at = now() WHERE id = _e.id;
  UPDATE deals SET state = 'completed', completed_at = now() WHERE id = _deal;
  UPDATE commission_charges SET state = 'captured' WHERE deal_id = _deal;
  INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'in_inspection', 'released', _actor, 'buyer confirmed receipt');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.seller_id, 'تسویه انجام شد', 'خریدار دریافت را تأیید کرد و وجه به کیف پول شما واریز شد.'),
    (_d.buyer_id,  'معامله تکمیل شد', 'معامله با موفقیت تکمیل شد.');
END $$;

-- cancel/refund before release (buyer pre-transfer, or admin)
CREATE OR REPLACE FUNCTION deal_refund(_deal uuid, _actor uuid, _reason text DEFAULT 'cancelled') RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE; _esc uuid; _b_avail uuid; _b_held uuid;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state NOT IN ('waiting_seller_transfer', 'waiting_buyer_confirmation') THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;
  -- buyer may only self-cancel before the seller has transferred
  IF _actor = _d.buyer_id AND NOT is_admin() AND _d.state <> 'waiting_seller_transfer' THEN
    RAISE EXCEPTION 'cannot cancel after seller transfer; open a dispute';
  END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;
  _esc     := system_account('escrow_liability');
  _b_avail := user_account(_d.buyer_id, 'available');
  _b_held  := user_account(_d.buyer_id, 'held');

  PERFORM post_transaction('escrow_refund', 'deal_refund_' || _deal, _deal::text, _actor,
    jsonb_build_array(
      jsonb_build_object('account_id', _esc,     'amount', -_d.loan_price),
      jsonb_build_object('account_id', _b_avail, 'amount',  _d.loan_price + _d.buyer_fee),
      jsonb_build_object('account_id', _b_held,  'amount', -_d.buyer_fee)
    ));

  UPDATE escrows SET state = 'refunded', refunded_at = now() WHERE id = _e.id;
  UPDATE deals SET state = 'cancelled' WHERE id = _deal;
  UPDATE commission_charges SET state = 'reversed' WHERE deal_id = _deal;
  UPDATE loan_posts SET status = 'active', updated_at = now() WHERE id = _d.listing_id;
  INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_e.id, 'refunded', _actor, _reason);
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.seller_id, 'معامله لغو شد', 'یک معامله مرتبط با آگهی شما لغو و وجه به خریدار بازگردانده شد.'),
    (_d.buyer_id,  'بازگشت وجه', 'وجه امانی و کارمزد به کیف پول شما بازگشت.');
END $$;

GRANT EXECUTE ON FUNCTION
  commission_compute(uuid, text, bigint),
  deal_start(uuid, uuid), deal_seller_transferred(uuid, uuid),
  deal_buyer_confirm(uuid, uuid), deal_refund(uuid, uuid, text)
TO app;
