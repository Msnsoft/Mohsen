import { getFaqs } from "@/lib/cms";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";

export const dynamic = "force-dynamic";

export default async function FaqPage() {
  const faqs = await getFaqs();
  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">سوالات متداول</h1>
      {faqs.length === 0 ? (
        <Card><CardMuted>پرسشی ثبت نشده است.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {faqs.map((f) => (
            <Card key={f.id} className="space-y-1">
              <CardTitle>{f.question}</CardTitle>
              <CardMuted>{f.answer}</CardMuted>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
