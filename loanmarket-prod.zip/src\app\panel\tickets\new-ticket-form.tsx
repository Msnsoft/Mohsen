"use client";
import { useActionState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { createTicketAction, type TicketFormState } from "./actions";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export function NewTicketForm() {
  const [state, action, pending] = useActionState<TicketFormState, FormData>(createTicketAction, {});

  if (state.ok && state.id) {
    return (
      <p className="text-sm text-[var(--color-accent)]">
        تیکت شما ثبت شد ✓ <Link href={`/panel/tickets/${state.id}`} className="text-[var(--color-primary)]">مشاهدهٔ تیکت ←</Link>
      </p>
    );
  }

  return (
    <form action={action} className="space-y-3">
      <div className="grid gap-3 sm:grid-cols-[1fr_10rem]">
        <input name="subject" placeholder="موضوع" className={inputCls} required maxLength={150} />
        <select name="priority" className={inputCls} defaultValue="normal">
          <option value="low">اولویت کم</option>
          <option value="normal">اولویت عادی</option>
          <option value="high">اولویت زیاد</option>
          <option value="urgent">فوری</option>
        </select>
      </div>
      <textarea name="body" placeholder="شرح مشکل یا درخواست…" rows={4} className={inputCls} required />
      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}
      <Button type="submit" size="sm" disabled={pending}>{pending ? "در حال ثبت…" : "ثبت تیکت"}</Button>
    </form>
  );
}
