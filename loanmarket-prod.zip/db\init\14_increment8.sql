-- =====================================================================
-- Increment 8 · compliance + hardening (M13 audit, M14 dispatch, rate limit).
-- Idempotent. Money still moves only via post_transaction.
-- =====================================================================
SET check_function_bodies = off;

-- ---------------------------------------------------------------------
-- M13 — immutable audit/compliance log
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS audit_log (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  actor_id   uuid REFERENCES users(id),
  action     text NOT NULL,
  entity     text,
  entity_id  text,
  detail     jsonb NOT NULL DEFAULT '{}',
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS audit_log_created_idx ON audit_log (created_at DESC);
CREATE INDEX IF NOT EXISTS audit_log_entity_idx  ON audit_log (entity, entity_id);

ALTER TABLE audit_log ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_audit_read ON audit_log;
CREATE POLICY p_audit_read ON audit_log FOR SELECT USING (is_admin());
-- no INSERT/UPDATE/DELETE policy → writable only through the definer fn / trigger;
-- nobody (not even admins) can edit or delete rows over the API → immutable.

-- App-layer log seam (called from admin actions for non-ledger events).
CREATE OR REPLACE FUNCTION audit(_actor uuid, _action text, _entity text, _entity_id text, _detail jsonb DEFAULT '{}')
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  INSERT INTO audit_log(actor_id, action, entity, entity_id, detail)
  VALUES (_actor, _action, _entity, _entity_id, COALESCE(_detail, '{}'::jsonb));
END $$;

-- Every money movement is audited at the DB level (cannot be bypassed by app code).
CREATE OR REPLACE FUNCTION audit_ledger_txn() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  INSERT INTO audit_log(actor_id, action, entity, entity_id, detail)
  VALUES (NEW.created_by, 'ledger.' || NEW.type, 'ledger_transaction', NEW.id::text,
          jsonb_build_object('reference', NEW.reference, 'idempotency_key', NEW.idempotency_key));
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_audit_ledger ON ledger_transactions;
CREATE TRIGGER trg_audit_ledger AFTER INSERT ON ledger_transactions
  FOR EACH ROW EXECUTE FUNCTION audit_ledger_txn();

-- ---------------------------------------------------------------------
-- M14 — notification dispatch (email/SMS) bookkeeping
-- ---------------------------------------------------------------------
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS dispatched_at timestamptz;
ALTER TABLE notifications ADD COLUMN IF NOT EXISTS dispatch_error text;
CREATE INDEX IF NOT EXISTS notifications_dispatch_idx ON notifications (dispatched_at) WHERE dispatched_at IS NULL;

-- Rows the worker should push to SMS/email (when enabled), oldest first.
CREATE OR REPLACE FUNCTION notifications_pending_dispatch(_limit int DEFAULT 50)
RETURNS TABLE(id uuid, user_id uuid, mobile text, title text, body text)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT n.id, n.user_id, u.mobile, n.title, n.body
  FROM notifications n JOIN users u ON u.id = n.user_id
  WHERE n.dispatched_at IS NULL
    AND COALESCE((SELECT (value #>> '{}')::boolean FROM config WHERE key = 'notifications.sms_enabled'), false)
  ORDER BY n.created_at ASC
  LIMIT _limit;
$$;

CREATE OR REPLACE FUNCTION notifications_mark_dispatched(_id uuid, _error text DEFAULT NULL)
RETURNS void LANGUAGE sql SECURITY DEFINER SET search_path = public AS $$
  UPDATE notifications SET dispatched_at = now(), dispatch_error = _error WHERE id = _id;
$$;

-- ---------------------------------------------------------------------
-- Phase 9 — DB-backed fixed-window rate limiter (OTP / login abuse)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS rate_limits (
  bucket      text NOT NULL,        -- e.g. 'otp:09120000000'
  window_start timestamptz NOT NULL,
  count       int NOT NULL DEFAULT 0,
  PRIMARY KEY (bucket, window_start)
);

-- Returns TRUE if the action is allowed (under the limit), FALSE if throttled.
CREATE OR REPLACE FUNCTION rate_limit_hit(_bucket text, _max int, _window_seconds int)
RETURNS boolean LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _wstart timestamptz; _n int;
BEGIN
  _wstart := to_timestamp(floor(extract(epoch FROM now()) / _window_seconds) * _window_seconds);
  INSERT INTO rate_limits(bucket, window_start, count) VALUES (_bucket, _wstart, 1)
    ON CONFLICT (bucket, window_start) DO UPDATE SET count = rate_limits.count + 1
    RETURNING count INTO _n;
  DELETE FROM rate_limits WHERE window_start < now() - interval '1 day';  -- opportunistic GC
  RETURN _n <= _max;
END $$;

INSERT INTO config(key, value) VALUES ('notifications.sms_enabled', 'false'::jsonb)
  ON CONFLICT (key) DO NOTHING;

GRANT EXECUTE ON FUNCTION
  audit(uuid, text, text, text, jsonb),
  notifications_pending_dispatch(int),
  notifications_mark_dispatched(uuid, text),
  rate_limit_hit(text, int, int)
TO app;
