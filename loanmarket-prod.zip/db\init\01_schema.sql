-- =====================================================================
-- Loan Marketplace — core schema (authoritative; run on container boot)
-- Self-hosted PostgreSQL. Money = bigint IRR. RLS keyed on a session GUC
-- (app.user_id) set by the app via SET LOCAL — no Supabase auth.uid().
-- =====================================================================

-- Allow helper functions to reference tables created later in this script.
SET check_function_bodies = off;

-- ---- Non-superuser application role (so RLS actually applies) ---------
DO $$
BEGIN
  IF NOT EXISTS (SELECT FROM pg_roles WHERE rolname = 'app') THEN
    CREATE ROLE app LOGIN PASSWORD 'app_password';
  END IF;
END $$;

-- ---- Helper: current user from session GUC ---------------------------
CREATE OR REPLACE FUNCTION current_user_id() RETURNS uuid
LANGUAGE sql STABLE AS $$
  SELECT NULLIF(current_setting('app.user_id', true), '')::uuid
$$;

CREATE OR REPLACE FUNCTION is_admin() RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles ur
    WHERE ur.user_id = current_user_id() AND ur.role <> 'user'
  )
$$;

CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger
LANGUAGE plpgsql AS $$ BEGIN NEW.updated_at = now(); RETURN NEW; END $$;

-- =====================================================================
-- Identity
-- =====================================================================
CREATE TABLE users (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mobile           text UNIQUE NOT NULL,
  email            text UNIQUE,
  display_name     text,
  verification_level smallint NOT NULL DEFAULT 1,  -- L1 registered .. L2+ per PRD §8
  status           text NOT NULL DEFAULT 'active',  -- active|suspended|banned
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE user_roles (
  user_id  uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role     text NOT NULL,  -- super_admin|finance_admin|escrow_admin|verification_admin|support_admin|moderator|analyst|user
  PRIMARY KEY (user_id, role)
);

CREATE TABLE otp_codes (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  mobile     text NOT NULL,
  code_hash  text NOT NULL,
  expires_at timestamptz NOT NULL,
  consumed   boolean NOT NULL DEFAULT false,
  attempts   smallint NOT NULL DEFAULT 0,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX otp_codes_mobile_idx ON otp_codes (mobile, created_at DESC);

-- =====================================================================
-- Wallet & double-entry ledger  (M07)
-- =====================================================================
CREATE TABLE wallets (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid UNIQUE NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  currency   text NOT NULL DEFAULT 'IRR',
  status     text NOT NULL DEFAULT 'active',
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Ledger accounts: user accounts (available/held) have wallet_id;
-- platform/system accounts have system_key and wallet_id NULL.
CREATE TABLE ledger_accounts (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  wallet_id  uuid REFERENCES wallets(id) ON DELETE CASCADE,
  system_key text,                       -- e.g. platform_revenue, escrow_liability, cash_clearing
  kind       text NOT NULL,              -- available | held | system
  currency   text NOT NULL DEFAULT 'IRR',
  created_at timestamptz NOT NULL DEFAULT now(),
  CONSTRAINT acct_target_ck CHECK (
    (wallet_id IS NOT NULL AND system_key IS NULL) OR
    (wallet_id IS NULL AND system_key IS NOT NULL)
  ),
  CONSTRAINT acct_wallet_kind_uniq UNIQUE (wallet_id, kind)
);
CREATE UNIQUE INDEX ledger_accounts_system_key_idx ON ledger_accounts (system_key) WHERE system_key IS NOT NULL;

CREATE TABLE ledger_transactions (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  type            text NOT NULL,        -- deposit|withdrawal|fee_capture|refund|escrow_release|adjustment|...
  idempotency_key text UNIQUE,
  reference       text,                 -- deal_id / escrow_id / ...
  reversal_of     uuid REFERENCES ledger_transactions(id),
  created_by      uuid,
  created_at      timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE ledger_entries (
  id             uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  transaction_id uuid NOT NULL REFERENCES ledger_transactions(id) ON DELETE CASCADE,
  account_id     uuid NOT NULL REFERENCES ledger_accounts(id),
  amount         bigint NOT NULL,       -- signed minor units (IRR); sum per transaction = 0
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX ledger_entries_account_idx ON ledger_entries (account_id, created_at);
CREATE INDEX ledger_entries_txn_idx ON ledger_entries (transaction_id);

-- =====================================================================
-- Catalog & marketplace  (M04)
-- =====================================================================
CREATE TABLE loan_types (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name                 text NOT NULL,
  bank_name            text,
  logo_url             text,
  fixed_rate           numeric,          -- NULL = rate editable by user
  rate_editable        boolean NOT NULL DEFAULT true,
  default_duration_months int,
  min_price_per_million bigint,
  max_price_per_million bigint,
  active               boolean NOT NULL DEFAULT true,
  created_at           timestamptz NOT NULL DEFAULT now(),
  updated_at           timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE loan_posts (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id          uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  type             text NOT NULL CHECK (type IN ('sell','buy')),
  loan_type_id     uuid NOT NULL REFERENCES loan_types(id),
  loan_value       bigint NOT NULL,      -- principal (IRR)
  loan_price       bigint NOT NULL,      -- premium paid to seller (IRR)
  price_per_million bigint,
  rate             numeric,
  duration_months  int,
  province         text,
  status           text NOT NULL DEFAULT 'draft',  -- draft|pending_review|active|reserved|sold|rejected|cancelled
  -- split matching (M04)
  splittable       boolean NOT NULL DEFAULT false,
  min_chunk        bigint,
  max_splits       int,
  min_acceptable   bigint,
  max_acceptable   bigint,
  filled_amount    bigint NOT NULL DEFAULT 0,
  featured         boolean NOT NULL DEFAULT false,
  created_at       timestamptz NOT NULL DEFAULT now(),
  updated_at       timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX loan_posts_browse_idx ON loan_posts (status, type, loan_type_id, province);

-- =====================================================================
-- Commission rules  (M09)  — percent or progressive, per loan type × side
-- =====================================================================
CREATE TABLE commission_rules (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_type_id  uuid REFERENCES loan_types(id),  -- NULL = global default
  side          text NOT NULL CHECK (side IN ('buyer','seller')),
  method        text NOT NULL CHECK (method IN ('percent','progressive')),
  percent_rate  numeric,
  base_fee      bigint NOT NULL DEFAULT 0,
  tax_rate      numeric NOT NULL DEFAULT 0,
  source        text NOT NULL DEFAULT 'wallet',  -- wallet|escrow|combined
  active        boolean NOT NULL DEFAULT true,
  created_at    timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE commission_bands (
  id              uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id         uuid NOT NULL REFERENCES commission_rules(id) ON DELETE CASCADE,
  from_amount     bigint NOT NULL,
  to_amount       bigint,                -- NULL = open top band
  amount_per_band bigint,               -- flat (bounded band)
  rate_per_million bigint,              -- per-million (required for open band)
  sort            int NOT NULL DEFAULT 0
);

-- =====================================================================
-- Membership / subscriptions  (M19)
-- =====================================================================
CREATE TABLE subscription_plans (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key          text UNIQUE NOT NULL,    -- free|basic|pro
  name         text NOT NULL,
  price        bigint NOT NULL DEFAULT 0,
  period_days  int NOT NULL DEFAULT 30,
  active       boolean NOT NULL DEFAULT true,
  sort         int NOT NULL DEFAULT 0,
  created_at   timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE plan_entitlements (
  plan_id        uuid NOT NULL REFERENCES subscription_plans(id) ON DELETE CASCADE,
  entitlement    text NOT NULL,         -- calculator|pricing_advice|sms_alerts|auto_match|history_charts
  limit_value    int,                   -- NULL = unlimited/boolean
  PRIMARY KEY (plan_id, entitlement)
);

CREATE TABLE subscriptions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  plan_id     uuid NOT NULL REFERENCES subscription_plans(id),
  status      text NOT NULL DEFAULT 'active',  -- active|grace|expired|cancelled
  started_at  timestamptz NOT NULL DEFAULT now(),
  expires_at  timestamptz NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX subscriptions_user_idx ON subscriptions (user_id, status);

-- =====================================================================
-- Config (M16)  &  Notifications (M14, minimal)
-- =====================================================================
CREATE TABLE config (
  key        text PRIMARY KEY,
  value      jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE notifications (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  title      text NOT NULL,
  body       text,
  read       boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX notifications_user_idx ON notifications (user_id, read, created_at DESC);

-- ---- updated_at triggers --------------------------------------------
CREATE TRIGGER trg_users_updated     BEFORE UPDATE ON users      FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_loan_types_updated BEFORE UPDATE ON loan_types FOR EACH ROW EXECUTE FUNCTION set_updated_at();
CREATE TRIGGER trg_loan_posts_updated BEFORE UPDATE ON loan_posts FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- =====================================================================
-- Row-Level Security
-- =====================================================================
ALTER TABLE users            ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_roles       ENABLE ROW LEVEL SECURITY;
ALTER TABLE wallets          ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_accounts  ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE ledger_entries   ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_types       ENABLE ROW LEVEL SECURITY;
ALTER TABLE loan_posts       ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE commission_bands ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscription_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE plan_entitlements  ENABLE ROW LEVEL SECURITY;
ALTER TABLE subscriptions    ENABLE ROW LEVEL SECURITY;
ALTER TABLE config           ENABLE ROW LEVEL SECURITY;
ALTER TABLE notifications    ENABLE ROW LEVEL SECURITY;

-- public read catalog/config
CREATE POLICY p_loan_types_read   ON loan_types       FOR SELECT USING (true);
CREATE POLICY p_commission_read   ON commission_rules FOR SELECT USING (true);
CREATE POLICY p_commission_bands_read ON commission_bands FOR SELECT USING (true);
CREATE POLICY p_plans_read        ON subscription_plans FOR SELECT USING (active OR is_admin());
CREATE POLICY p_plan_ent_read     ON plan_entitlements FOR SELECT USING (true);
CREATE POLICY p_config_read       ON config           FOR SELECT USING (true);

-- listings: anyone can read active; owner reads own; owner writes own
CREATE POLICY p_posts_read_active ON loan_posts FOR SELECT
  USING (status = 'active' OR user_id = current_user_id() OR is_admin());
CREATE POLICY p_posts_owner_write ON loan_posts FOR INSERT
  WITH CHECK (user_id = current_user_id());
CREATE POLICY p_posts_owner_update ON loan_posts FOR UPDATE
  USING (user_id = current_user_id() OR is_admin());

-- users: self or admin
CREATE POLICY p_users_self ON users FOR SELECT
  USING (id = current_user_id() OR is_admin());
CREATE POLICY p_user_roles_self ON user_roles FOR SELECT
  USING (user_id = current_user_id() OR is_admin());

-- wallet & ledger: owner or admin (writes happen via SECURITY DEFINER fns)
CREATE POLICY p_wallets_self ON wallets FOR SELECT
  USING (user_id = current_user_id() OR is_admin());
CREATE POLICY p_ledger_acct_self ON ledger_accounts FOR SELECT
  USING (is_admin() OR wallet_id IN (SELECT id FROM wallets WHERE user_id = current_user_id()));
CREATE POLICY p_ledger_entries_self ON ledger_entries FOR SELECT
  USING (is_admin() OR account_id IN (
    SELECT la.id FROM ledger_accounts la
    JOIN wallets w ON w.id = la.wallet_id
    WHERE w.user_id = current_user_id()));
CREATE POLICY p_ledger_txn_admin ON ledger_transactions FOR SELECT
  USING (is_admin());

-- subscriptions: self or admin
CREATE POLICY p_subs_self ON subscriptions FOR SELECT
  USING (user_id = current_user_id() OR is_admin());
CREATE POLICY p_notif_self ON notifications FOR SELECT
  USING (user_id = current_user_id());
CREATE POLICY p_notif_self_upd ON notifications FOR UPDATE
  USING (user_id = current_user_id());

-- =====================================================================
-- Grants to the application role
-- =====================================================================
GRANT USAGE ON SCHEMA public TO app;
GRANT SELECT, INSERT, UPDATE, DELETE ON ALL TABLES IN SCHEMA public TO app;
GRANT USAGE, SELECT ON ALL SEQUENCES IN SCHEMA public TO app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT SELECT, INSERT, UPDATE, DELETE ON TABLES TO app;
ALTER DEFAULT PRIVILEGES IN SCHEMA public GRANT USAGE, SELECT ON SEQUENCES TO app;
