// Marketplace post types (req. R). Both sides are symmetric "requests".
export const POST_TYPE_FA: Record<string, string> = {
  sell: "درخواست فروش وام",
  buy: "درخواست خرید وام",
};

/** Short tab label variant. */
export const POST_TYPE_SHORT_FA: Record<string, string> = {
  sell: "فروش وام",
  buy: "خرید وام",
};
