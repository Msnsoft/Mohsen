import Link from "next/link";
import { asc, eq } from "drizzle-orm";
import { db } from "@/db";
import { subscriptionPlans, planEntitlements } from "@/db/schema";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, toFaDigits } from "@/lib/persian";
import { getCurrentUser } from "@/lib/auth";
import { getMembership, ENTITLEMENT_FA } from "@/lib/entitlements";
import { PurchaseButton } from "./purchase-button";

export const dynamic = "force-dynamic";

export default async function MembershipPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; error?: string }>;
}) {
  const { ok, error } = await searchParams;
  const user = await getCurrentUser();
  const membership = await getMembership(user?.id ?? null);

  const plans = await db.select().from(subscriptionPlans).where(eq(subscriptionPlans.active, true)).orderBy(asc(subscriptionPlans.sort));
  const ents = await db.select().from(planEntitlements);
  const byPlan = new Map<string, string[]>();
  for (const e of ents) byPlan.set(e.planId, [...(byPlan.get(e.planId) ?? []), e.entitlement]);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">اشتراک عضویت</h1>
        <CardMuted>قابلیت‌های ویژه را با اشتراک فعال کنید. پرداخت از کیف پول شما انجام می‌شود.</CardMuted>
      </div>

      {ok && (
        <Card className="border-[var(--color-accent)] text-sm text-[var(--color-accent)]">
          اشتراک شما با موفقیت فعال شد ✓
        </Card>
      )}
      {error === "queue" ? (
        <Card className="border-[var(--color-danger)] text-sm text-[var(--color-danger)]">
          شما حداکثر یک دورهٔ پیش‌رو را خریداری کرده‌اید؛ امکان خرید بیش از یک ماه جلوتر وجود ندارد.
        </Card>
      ) : error ? (
        <Card className="border-[var(--color-danger)] text-sm text-[var(--color-danger)]">
          خرید اشتراک ناموفق بود. لطفاً دوباره تلاش کنید.
        </Card>
      ) : null}
      {membership && (
        <Card className="flex flex-wrap items-center gap-3 text-sm">
          <Badge tone="accent">اشتراک فعال</Badge>
          <span>پلن «{membership.planName}» تا تاریخ <span dir="ltr">{toFaDigits(membership.expiresAt.slice(0, 10))}</span> فعال است.</span>
        </Card>
      )}

      <div className="grid gap-4 md:grid-cols-3">
        {plans.map((p) => {
          const isCurrent = membership?.planKey === p.key || (!membership && p.price === 0);
          return (
            <Card key={p.id} className={`flex flex-col ${p.key === "pro" ? "border-[var(--color-primary)]" : ""}`}>
              <div className="flex items-center justify-between">
                <CardTitle>{p.name}</CardTitle>
                {p.key === "pro" && <Badge tone="accent">پیشنهاد ویژه</Badge>}
                {isCurrent && <Badge tone="default">پلن فعلی</Badge>}
              </div>
              <p className="mt-2 text-2xl font-extrabold">
                {p.price === 0 ? "رایگان" : formatToman(p.price)}
                {p.price > 0 && <span className="text-sm font-normal text-[var(--color-muted)]"> / {toFaDigits(p.periodDays)} روز</span>}
              </p>
              <ul className="mt-4 flex-1 space-y-2 text-sm">
                {(byPlan.get(p.id) ?? []).map((e) => (
                  <li key={e} className="flex items-center gap-2">
                    <span className="text-[var(--color-accent)]">✓</span> {ENTITLEMENT_FA[e] ?? e}
                  </li>
                ))}
                {(byPlan.get(p.id) ?? []).length === 0 && <li className="text-[var(--color-muted)]">امکانات پایهٔ مرور بازار</li>}
              </ul>
              <div className="mt-4">
                {p.price === 0 ? (
                  <Button className="w-full" variant="outline" disabled>رایگان</Button>
                ) : user ? (
                  <PurchaseButton
                    planKey={p.key}
                    planName={p.name}
                    price={p.price}
                    periodDays={p.periodDays}
                    renew={membership?.planKey === p.key}
                    primary={p.key === "pro"}
                  />
                ) : (
                  <Link href="/login">
                    <Button className="w-full" variant={p.key === "pro" ? "primary" : "outline"}>
                      ورود و خرید اشتراک
                    </Button>
                  </Link>
                )}
              </div>
            </Card>
          );
        })}
      </div>
    </div>
  );
}
