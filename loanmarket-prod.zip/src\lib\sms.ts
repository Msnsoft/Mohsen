import "server-only";

/**
 * SMS provider seam (M14 / Phase 9). Dev = console; prod posts to a generic
 * HTTP SMS gateway (Kavenegar / FarazSMS / Melipayamak adapter point) via env:
 *   SMS_PROVIDER=http  SMS_API_URL=…  SMS_API_KEY=…  SMS_FROM=…
 * Replace the single `fetch` below with a provider-specific payload if needed.
 */
export async function sendSms(mobile: string, text: string): Promise<void> {
  const provider = process.env.SMS_PROVIDER ?? "console";
  const url = process.env.SMS_API_URL;
  if (provider === "console" || !url) {
    // eslint-disable-next-line no-console
    console.log(`[SMS→${mobile}] ${text}`);
    return;
  }
  await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.SMS_API_KEY ? { Authorization: `Bearer ${process.env.SMS_API_KEY}` } : {}),
    },
    body: JSON.stringify({ to: mobile, from: process.env.SMS_FROM ?? "", message: text }),
  });
}
