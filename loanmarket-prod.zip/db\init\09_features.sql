-- =====================================================================
-- Increment 6 feature batch:
--  (1) default membership plan for new users (+ expiry → free via job)
--  (2) base role 'customer' (was 'user'); is_admin treats both as non-admin
--  (5) escrow.mode: internal | external | disabled (handshake)
--  (6) loan-type custom fields + loan_posts.custom
-- Idempotent.
-- =====================================================================
SET check_function_bodies = off;

-- ---------------------------------------------------------------------
-- (2) Base role 'customer'
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION is_admin() RETURNS boolean
LANGUAGE sql STABLE AS $$
  SELECT EXISTS (
    SELECT 1 FROM user_roles ur
    WHERE ur.user_id = current_user_id() AND ur.role NOT IN ('user','customer')
  )
$$;

-- ---------------------------------------------------------------------
-- (1) Default membership: grant the configured plan to a user
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION grant_default_membership(_user uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _key text; _days int; _plan subscription_plans%ROWTYPE;
BEGIN
  SELECT (value #>> '{}') INTO _key  FROM config WHERE key = 'membership.default_plan_key';
  SELECT (value::text)::int INTO _days FROM config WHERE key = 'membership.default_duration_days';
  IF _key IS NULL OR _key = '' OR _key = 'free' THEN RETURN; END IF;

  SELECT * INTO _plan FROM subscription_plans WHERE key = _key AND active;
  IF NOT FOUND THEN RETURN; END IF;

  -- only if the user has no active subscription yet
  IF EXISTS (SELECT 1 FROM subscriptions WHERE user_id = _user AND status = 'active' AND expires_at > now()) THEN
    RETURN;
  END IF;

  INSERT INTO subscriptions(user_id, plan_id, status, started_at, expires_at)
  VALUES (_user, _plan.id, 'active', now(), now() + (COALESCE(_days, _plan.period_days) || ' days')::interval);
END $$;
GRANT EXECUTE ON FUNCTION grant_default_membership(uuid) TO app;

-- New users get role 'customer' + the default membership.
CREATE OR REPLACE FUNCTION get_or_create_user(_mobile text, _super_email text DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid;
BEGIN
  SELECT id INTO _uid FROM users WHERE mobile = _mobile;
  IF _uid IS NULL THEN
    INSERT INTO users(mobile) VALUES (_mobile) RETURNING id INTO _uid;
    INSERT INTO user_roles(user_id, role) VALUES (_uid, 'customer') ON CONFLICT DO NOTHING;
    PERFORM ensure_wallet(_uid);
    PERFORM grant_default_membership(_uid);
  END IF;
  RETURN _uid;
END $$;
GRANT EXECUTE ON FUNCTION get_or_create_user(text, text) TO app;

-- ---------------------------------------------------------------------
-- (6) Loan-type custom fields + per-listing values
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS loan_type_fields (
  id           uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  loan_type_id uuid NOT NULL REFERENCES loan_types(id) ON DELETE CASCADE,
  key          text NOT NULL,
  label        text NOT NULL,
  field_type   text NOT NULL DEFAULT 'text',  -- text|number|select|bool
  audience     text NOT NULL DEFAULT 'both',   -- buyer|seller|both
  required     boolean NOT NULL DEFAULT false,
  options      jsonb NOT NULL DEFAULT '[]',     -- for select
  sort         int NOT NULL DEFAULT 0,
  active       boolean NOT NULL DEFAULT true,
  UNIQUE (loan_type_id, key)
);
CREATE INDEX IF NOT EXISTS loan_type_fields_idx ON loan_type_fields (loan_type_id, sort);

ALTER TABLE loan_posts ADD COLUMN IF NOT EXISTS custom jsonb NOT NULL DEFAULT '{}';

ALTER TABLE loan_type_fields ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_ltf_read ON loan_type_fields;
CREATE POLICY p_ltf_read ON loan_type_fields FOR SELECT USING (true);
DROP POLICY IF EXISTS p_ltf_admin ON loan_type_fields;
CREATE POLICY p_ltf_admin ON loan_type_fields FOR ALL USING (is_admin()) WITH CHECK (is_admin());

-- ---------------------------------------------------------------------
-- (5) Escrow mode-aware deal lifecycle
--   internal/external → ledger custody (external also pinged via adapter
--   from the Node action layer); disabled → handshake, no money, escrow
--   row recorded with state 'bypassed'.
-- ---------------------------------------------------------------------
CREATE OR REPLACE FUNCTION deal_start(_listing uuid, _buyer uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _l loan_posts%ROWTYPE; _buyer_fee bigint; _seller_fee bigint; _total bigint;
        _avail bigint; _deal uuid; _escrow uuid; _mode text;
        _b_avail uuid; _b_held uuid; _esc uuid; _ins int;
BEGIN
  SELECT * INTO _l FROM loan_posts WHERE id = _listing FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'listing not found'; END IF;
  IF _l.status <> 'active' THEN RAISE EXCEPTION 'listing not available'; END IF;
  IF _l.type <> 'sell' THEN RAISE EXCEPTION 'only sell listings supported here'; END IF;
  IF _l.user_id = _buyer THEN RAISE EXCEPTION 'cannot buy own listing'; END IF;

  SELECT (value #>> '{}') INTO _mode FROM config WHERE key = 'escrow.mode';
  _mode := COALESCE(NULLIF(_mode, ''), 'internal');

  _buyer_fee  := commission_compute(_l.loan_type_id, 'buyer',  _l.loan_price);
  _seller_fee := commission_compute(_l.loan_type_id, 'seller', _l.loan_price);

  IF _mode = 'disabled' THEN
    -- Handshake only: no custody, no fees, no balance requirement.
    INSERT INTO deals(listing_id, buyer_id, seller_id, loan_type_id, loan_value, loan_price, buyer_fee, seller_fee, state)
    VALUES (_listing, _buyer, _l.user_id, _l.loan_type_id, _l.loan_value, _l.loan_price, 0, 0, 'waiting_seller_transfer')
    RETURNING id INTO _deal;
    INSERT INTO escrows(deal_id, buyer_id, seller_id, amount, state, inspection_hours, funded_at)
    VALUES (_deal, _buyer, _l.user_id, _l.loan_price, 'bypassed', 0, now()) RETURNING id INTO _escrow;
    UPDATE loan_posts SET status = 'sold', updated_at = now() WHERE id = _listing;
    INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_escrow, 'bypassed', _buyer, 'escrow disabled: handshake deal');
    INSERT INTO notifications(user_id, title, body) VALUES
      (_l.user_id, 'درخواست خرید جدید', 'خریدار درخواست خرید ثبت کرد (حالت بدون امانت). لطفاً پس از توافق، وام را منتقل کنید.');
    RETURN _deal;
  END IF;

  -- internal / external: ledger custody
  _total := _l.loan_price + _buyer_fee;
  _avail := wallet_balance(_buyer, 'available');
  IF _avail < _total THEN RAISE EXCEPTION 'insufficient balance: need %, have %', _total, _avail; END IF;

  SELECT (value::text)::int INTO _ins FROM config WHERE key = 'escrow.inspection_hours';
  _ins := COALESCE(_ins, 72);

  INSERT INTO deals(listing_id, buyer_id, seller_id, loan_type_id, loan_value, loan_price, buyer_fee, seller_fee, state)
  VALUES (_listing, _buyer, _l.user_id, _l.loan_type_id, _l.loan_value, _l.loan_price, _buyer_fee, _seller_fee, 'waiting_seller_transfer')
  RETURNING id INTO _deal;

  INSERT INTO escrows(deal_id, buyer_id, seller_id, amount, state, inspection_hours, funded_at)
  VALUES (_deal, _buyer, _l.user_id, _l.loan_price, 'funded', _ins, now()) RETURNING id INTO _escrow;

  _b_avail := user_account(_buyer, 'available');
  _b_held  := user_account(_buyer, 'held');
  _esc     := system_account('escrow_liability');
  PERFORM post_transaction('escrow_fund', 'deal_fund_' || _deal, _deal::text, _buyer,
    jsonb_build_array(
      jsonb_build_object('account_id', _b_avail, 'amount', -_total),
      jsonb_build_object('account_id', _esc,     'amount',  _l.loan_price),
      jsonb_build_object('account_id', _b_held,  'amount',  _buyer_fee)
    ));

  INSERT INTO commission_charges(deal_id, payer_id, side, amount, state) VALUES
    (_deal, _buyer,     'buyer',  _buyer_fee,  'held'),
    (_deal, _l.user_id, 'seller', _seller_fee, 'quoted');

  UPDATE loan_posts SET status = 'sold', updated_at = now() WHERE id = _listing;
  INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_escrow, 'funded', _buyer, 'deal started, escrow funded from wallet');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_l.user_id, 'درخواست خرید جدید', 'خریدار وجه را به امانت سپرد. لطفاً وام را منتقل کنید.');
  RETURN _deal;
END $$;

-- seller transferred: start inspection (internal/external) or just advance (disabled)
CREATE OR REPLACE FUNCTION deal_seller_transferred(_deal uuid, _actor uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.seller_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_seller_transfer' THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;
  IF _e.state = 'bypassed' THEN
    UPDATE deals SET state = 'waiting_buyer_confirmation' WHERE id = _deal;
    INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'bypassed', 'bypassed', _actor, 'seller transferred (handshake)');
  ELSE
    UPDATE escrows SET state = 'in_inspection', inspection_started_at = now(),
      auto_release_at = now() + (_e.inspection_hours || ' hours')::interval WHERE id = _e.id;
    UPDATE deals SET state = 'waiting_buyer_confirmation' WHERE id = _deal;
    INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'funded', 'in_inspection', _actor, 'seller transferred');
  END IF;
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.buyer_id, 'وام منتقل شد', 'فروشنده اعلام کرد وام منتقل شده است. لطفاً پس از بررسی، دریافت را تأیید کنید.');
END $$;

-- buyer confirm: release (internal/external) or just complete (disabled)
CREATE OR REPLACE FUNCTION deal_buyer_confirm(_deal uuid, _actor uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE; _esc uuid; _s_avail uuid; _b_held uuid; _rev uuid;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_buyer_confirmation' THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;

  IF _e.state = 'bypassed' THEN
    UPDATE escrows SET state = 'released', released_at = now() WHERE id = _e.id;
    UPDATE deals SET state = 'completed', completed_at = now() WHERE id = _deal;
    INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'bypassed', 'released', _actor, 'buyer confirmed (handshake)');
    INSERT INTO notifications(user_id, title, body) VALUES
      (_d.seller_id, 'معامله تأیید شد', 'خریدار دریافت وام را تأیید کرد.'),
      (_d.buyer_id,  'معامله تکمیل شد', 'معامله با موفقیت تکمیل شد.');
    RETURN;
  END IF;

  _esc     := system_account('escrow_liability');
  _rev     := system_account('platform_revenue');
  _s_avail := user_account(_d.seller_id, 'available');
  _b_held  := user_account(_d.buyer_id, 'held');
  PERFORM post_transaction('escrow_release', 'deal_release_' || _deal, _deal::text, _actor,
    jsonb_build_array(
      jsonb_build_object('account_id', _esc,     'amount', -_d.loan_price),
      jsonb_build_object('account_id', _s_avail, 'amount',  _d.loan_price - _d.seller_fee),
      jsonb_build_object('account_id', _rev,     'amount',  _d.seller_fee),
      jsonb_build_object('account_id', _b_held,  'amount', -_d.buyer_fee),
      jsonb_build_object('account_id', _rev,     'amount',  _d.buyer_fee)
    ));
  UPDATE escrows SET state = 'released', released_at = now() WHERE id = _e.id;
  UPDATE deals SET state = 'completed', completed_at = now() WHERE id = _deal;
  UPDATE commission_charges SET state = 'captured' WHERE deal_id = _deal;
  INSERT INTO escrow_events(escrow_id, from_state, to_state, actor_id, reason) VALUES (_e.id, 'in_inspection', 'released', _actor, 'buyer confirmed receipt');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.seller_id, 'تسویه انجام شد', 'خریدار دریافت را تأیید کرد و وجه به کیف پول شما واریز شد.'),
    (_d.buyer_id,  'معامله تکمیل شد', 'معامله با موفقیت تکمیل شد.');
END $$;

-- refund/cancel: release ledger holds (internal/external) or just cancel (disabled)
CREATE OR REPLACE FUNCTION deal_refund(_deal uuid, _actor uuid, _reason text DEFAULT 'cancelled') RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE; _esc uuid; _b_avail uuid; _b_held uuid;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id AND NOT is_admin() THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state NOT IN ('waiting_seller_transfer', 'waiting_buyer_confirmation') THEN RAISE EXCEPTION 'invalid state %', _d.state; END IF;
  IF _actor = _d.buyer_id AND NOT is_admin() AND _d.state <> 'waiting_seller_transfer' THEN
    RAISE EXCEPTION 'cannot cancel after seller transfer; open a dispute';
  END IF;

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;

  IF _e.state = 'bypassed' THEN
    UPDATE escrows SET state = 'refunded', refunded_at = now() WHERE id = _e.id;
    UPDATE deals SET state = 'cancelled' WHERE id = _deal;
    UPDATE loan_posts SET status = 'active', updated_at = now() WHERE id = _d.listing_id;
    INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_e.id, 'refunded', _actor, _reason);
    INSERT INTO notifications(user_id, title, body) VALUES
      (_d.seller_id, 'معامله لغو شد', 'یک معامله مرتبط با آگهی شما لغو شد.'),
      (_d.buyer_id,  'معامله لغو شد', 'معامله لغو شد.');
    RETURN;
  END IF;

  _esc     := system_account('escrow_liability');
  _b_avail := user_account(_d.buyer_id, 'available');
  _b_held  := user_account(_d.buyer_id, 'held');
  PERFORM post_transaction('escrow_refund', 'deal_refund_' || _deal, _deal::text, _actor,
    jsonb_build_array(
      jsonb_build_object('account_id', _esc,     'amount', -_d.loan_price),
      jsonb_build_object('account_id', _b_avail, 'amount',  _d.loan_price + _d.buyer_fee),
      jsonb_build_object('account_id', _b_held,  'amount', -_d.buyer_fee)
    ));
  UPDATE escrows SET state = 'refunded', refunded_at = now() WHERE id = _e.id;
  UPDATE deals SET state = 'cancelled' WHERE id = _deal;
  UPDATE commission_charges SET state = 'reversed' WHERE deal_id = _deal;
  UPDATE loan_posts SET status = 'active', updated_at = now() WHERE id = _d.listing_id;
  INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_e.id, 'refunded', _actor, _reason);
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.seller_id, 'معامله لغو شد', 'یک معامله مرتبط با آگهی شما لغو و وجه به خریدار بازگردانده شد.'),
    (_d.buyer_id,  'بازگشت وجه', 'وجه امانی و کارمزد به کیف پول شما بازگشت.');
END $$;

-- ---------------------------------------------------------------------
-- Config defaults for the new keys
-- ---------------------------------------------------------------------
INSERT INTO config(key, value) VALUES
  ('escrow.mode', '"internal"'),
  ('escrow.api_url', '""'),
  ('membership.default_plan_key', '"free"'),
  ('membership.default_duration_days', '30')
ON CONFLICT (key) DO NOTHING;
