import "server-only";
import { db, sql } from "@/db";

// Admin-defined label rules (req. M). A rule lights a badge when a listing's
// numeric field crosses a threshold.
export interface LabelRule {
  key: string; label: string; tone: string;
  field: string; op: string; threshold: number;
}

export type LabelTone = "default" | "accent" | "warning" | "danger" | "muted";

export async function getLabelRules(): Promise<LabelRule[]> {
  try {
    const rows = await db.execute<{
      key: string; label: string; tone: string; field: string; op: string; threshold: string;
    }>(sql`select key, label, tone, field, op, threshold::text from label_rules
           where active order by sort, label`);
    return (rows as { key: string; label: string; tone: string; field: string; op: string; threshold: string }[])
      .map((r) => ({ ...r, threshold: Number(r.threshold) }));
  } catch {
    return [];
  }
}

type ListingLike = {
  rate?: number | string | null;
  fixedRate?: number | string | null;
  pricePerMillion?: number | string | null;
  durationMonths?: number | null;
  loanValue?: number | null;
};

function fieldValue(l: ListingLike, field: string): number | null {
  switch (field) {
    case "rate": return Number(l.rate ?? l.fixedRate ?? NaN);
    case "price_per_million": return l.pricePerMillion != null ? Number(l.pricePerMillion) : null;
    case "duration_months": return l.durationMonths ?? null;
    case "loan_value": return l.loanValue ?? null;
    default: return null;
  }
}

function passes(v: number, op: string, t: number): boolean {
  switch (op) {
    case ">=": return v >= t;
    case "<=": return v <= t;
    case ">": return v > t;
    case "<": return v < t;
    default: return false;
  }
}

/** Labels that apply to one listing, given the active rules. */
export function computeLabels(l: ListingLike, rules: LabelRule[]): { label: string; tone: LabelTone }[] {
  const out: { label: string; tone: LabelTone }[] = [];
  for (const r of rules) {
    const v = fieldValue(l, r.field);
    if (v == null || Number.isNaN(v)) continue;
    if (passes(v, r.op, r.threshold)) out.push({ label: r.label, tone: r.tone as LabelTone });
  }
  return out;
}
