import "server-only";
import { randomUUID } from "node:crypto";
import { mkdir, writeFile, readFile } from "node:fs/promises";
import path from "node:path";

/**
 * File-storage seam (req. F / Phase 9). Two drivers behind one interface:
 *   STORAGE_DRIVER=local  → disk under `platform/uploads` (dev/default)
 *   STORAGE_DRIVER=s3     → S3-compatible object store (MinIO in prod), env:
 *       S3_ENDPOINT, S3_REGION, S3_BUCKET, S3_ACCESS_KEY, S3_SECRET_KEY
 * Both are served through the access-controlled `/api/uploads/[name]` route,
 * so the storage backend is never exposed publicly.
 */
const DRIVER = process.env.STORAGE_DRIVER ?? "local";
const UPLOAD_DIR = path.join(process.cwd(), "uploads");

const ALLOWED = new Map<string, string>([
  ["image/jpeg", "jpg"],
  ["image/png", "png"],
  ["image/webp", "webp"],
  ["application/pdf", "pdf"],
]);
const CONTENT_TYPE: Record<string, string> = {
  jpg: "image/jpeg", png: "image/png", webp: "image/webp", pdf: "application/pdf",
};
const MAX_BYTES = 5 * 1024 * 1024; // 5 MB

export type SavedUpload = { name: string; url: string };

// --- S3 client (lazy; only loaded when driver=s3 so local builds need no SDK) -
// The specifier is a variable so the bundler/type-checker don't resolve it at
// build time — the package only needs to exist at runtime in the s3 image.
/* eslint-disable @typescript-eslint/no-explicit-any */
const S3_PKG = "@aws-sdk/client-s3";
let _sdk: any;
let _s3: any;
async function sdk() {
  if (!_sdk) _sdk = await import(/* webpackIgnore: true */ S3_PKG);
  return _sdk;
}
async function s3() {
  if (_s3) return _s3;
  const { S3Client } = await sdk();
  _s3 = new S3Client({
    endpoint: process.env.S3_ENDPOINT,
    region: process.env.S3_REGION ?? "us-east-1",
    forcePathStyle: true, // MinIO
    credentials: {
      accessKeyId: process.env.S3_ACCESS_KEY ?? "",
      secretAccessKey: process.env.S3_SECRET_KEY ?? "",
    },
  });
  return _s3;
}
const BUCKET = () => process.env.S3_BUCKET ?? "uploads";
/* eslint-enable @typescript-eslint/no-explicit-any */

/** Persist an uploaded file; returns its opaque name + access URL. */
export async function saveUpload(file: File): Promise<SavedUpload> {
  const ext = ALLOWED.get(file.type);
  if (!ext) throw new Error("نوع فایل مجاز نیست (تصویر یا PDF)");
  if (file.size === 0) throw new Error("فایل خالی است");
  if (file.size > MAX_BYTES) throw new Error("حجم فایل بیش از حد مجاز است (حداکثر ۵ مگابایت)");

  const name = `${randomUUID()}.${ext}`;
  const buf = Buffer.from(await file.arrayBuffer());

  if (DRIVER === "s3") {
    const { PutObjectCommand } = await sdk();
    const client = await s3();
    await client.send(new PutObjectCommand({ Bucket: BUCKET(), Key: name, Body: buf, ContentType: file.type }));
  } else {
    await mkdir(UPLOAD_DIR, { recursive: true });
    await writeFile(path.join(UPLOAD_DIR, name), buf);
  }
  return { name, url: `/api/uploads/${name}` };
}

/** Read a stored file back. `name` must be a bare filename (no path parts). */
export async function readUpload(name: string): Promise<{ body: Buffer; contentType: string } | null> {
  if (!/^[a-f0-9-]+\.(jpg|png|webp|pdf)$/i.test(name)) return null; // guard against traversal
  const ext = name.split(".").pop()!.toLowerCase();
  const contentType = CONTENT_TYPE[ext] ?? "application/octet-stream";

  if (DRIVER === "s3") {
    try {
      const { GetObjectCommand } = await sdk();
      const client = await s3();
      const res = await client.send(new GetObjectCommand({ Bucket: BUCKET(), Key: name }));
      const bytes = await res.Body.transformToByteArray();
      return { body: Buffer.from(bytes), contentType };
    } catch {
      return null;
    }
  }
  try {
    return { body: await readFile(path.join(UPLOAD_DIR, name)), contentType };
  } catch {
    return null;
  }
}
