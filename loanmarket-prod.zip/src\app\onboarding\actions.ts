"use server";
import { redirect } from "next/navigation";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";
import { verifyMobileNationalId, verifyCardSheba } from "@/lib/verification";

export interface OnboardingState { ok: boolean; error?: string }

function digits(s: string): string {
  return (s ?? "")
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/\D/g, "");
}

export async function completeProfileAction(
  _prev: OnboardingState,
  formData: FormData,
): Promise<OnboardingState> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status === "active") redirect("/panel");

  const firstName = String(formData.get("first_name") ?? "").trim();
  const lastName = String(formData.get("last_name") ?? "").trim();
  const nationalId = digits(String(formData.get("national_id") ?? ""));
  const card = digits(String(formData.get("card_number") ?? ""));
  const sheba = String(formData.get("sheba") ?? "").replace(/\s/g, "").toUpperCase().replace(/^IR/, "");
  const displayName = String(formData.get("display_name") ?? "").trim();

  // Layer 1: national-id ⇄ mobile. Layer 2: card ⇄ sheba (same owner).
  const idCheck = await verifyMobileNationalId(user.mobile, nationalId);
  if (!idCheck.ok) return { ok: false, error: idCheck.reason ?? "استعلام هویت ناموفق بود" };
  const bankCheck = await verifyCardSheba(card, sheba, nationalId);
  if (!bankCheck.ok) return { ok: false, error: bankCheck.reason ?? "استعلام بانکی ناموفق بود" };

  try {
    await withUser(user.id, (tx) =>
      tx.execute(sql`select complete_profile(
        ${user.id}, ${firstName}, ${lastName}, ${nationalId},
        ${card}, ${sheba}, ${displayName}, ${idCheck.ok}, ${bankCheck.ok})`),
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : String(e);
    if (msg.includes("missing required fields")) {
      return { ok: false, error: "لطفاً همهٔ فیلدهای الزامی را تکمیل کنید." };
    }
    return { ok: false, error: "ثبت اطلاعات ناموفق بود. دوباره تلاش کنید." };
  }
  redirect("/panel");
}
