"use client";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { purchasePlanAction } from "./actions";
import { formatToman, toFaDigits } from "@/lib/persian";

// Explicit purchase confirmation (req. H): the user must confirm plan, price
// and period before the wallet is charged.
export function PurchaseButton({
  planKey, planName, price, periodDays, renew, primary,
}: { planKey: string; planName: string; price: number; periodDays: number; renew: boolean; primary: boolean }) {
  const [confirming, setConfirming] = useState(false);

  if (!confirming) {
    return (
      <Button className="w-full" variant={primary ? "primary" : "outline"} type="button" onClick={() => setConfirming(true)}>
        {renew ? "تمدید اشتراک" : "خرید اشتراک"}
      </Button>
    );
  }

  return (
    <form action={purchasePlanAction} className="space-y-2 rounded-xl border border-[var(--color-primary)] p-3 text-sm">
      <input type="hidden" name="plan_key" value={planKey} />
      <p>
        خرید اشتراک «<b>{planName}</b>» به مبلغ <b>{formatToman(price)}</b> برای مدت{" "}
        <b>{toFaDigits(periodDays)} روز</b> از کیف پول شما کسر می‌شود. تأیید می‌کنید؟
      </p>
      <div className="flex gap-2">
        <Button className="flex-1" size="sm" variant="primary" type="submit">تأیید و پرداخت</Button>
        <Button className="flex-1" size="sm" variant="ghost" type="button" onClick={() => setConfirming(false)}>انصراف</Button>
      </div>
    </form>
  );
}
