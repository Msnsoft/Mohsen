// Persian/RTL display helpers. Money is stored as IRR (bigint); the UI shows
// toman by default (scale 10), per config display.currency_format.

const FA_DIGITS = ["۰", "۱", "۲", "۳", "۴", "۵", "۶", "۷", "۸", "۹"];

export function toFaDigits(input: string | number): string {
  return String(input).replace(/[0-9]/g, (d) => FA_DIGITS[Number(d)]);
}

export function groupThousands(n: number): string {
  return n.toLocaleString("en-US");
}

/** Format an IRR amount as toman with Persian digits, e.g. 1_500_000_000 → "۱۵۰٬۰۰۰٬۰۰۰ تومان". */
export function formatToman(irr: number, opts: { suffix?: boolean; scale?: number } = {}): string {
  const scale = opts.scale ?? 10;
  const toman = Math.round(irr / scale);
  const grouped = groupThousands(toman).replace(/,/g, "٬");
  const out = toFaDigits(grouped);
  return opts.suffix === false ? out : `${out} تومان`;
}

/** Compact display, e.g. 1_500_000_000 IRR → "۱۵۰ میلیون تومان". */
export function formatTomanCompact(irr: number): string {
  const toman = irr / 10;
  if (toman >= 1_000_000_000) return `${toFaDigits((toman / 1_000_000_000).toLocaleString("en-US", { maximumFractionDigits: 1 }))} میلیارد تومان`;
  if (toman >= 1_000_000) return `${toFaDigits((toman / 1_000_000).toLocaleString("en-US", { maximumFractionDigits: 1 }))} میلیون تومان`;
  return formatToman(irr);
}

/** Jalali date + time, e.g. "۱۴۰۵/۰۳/۲۲ ۱۸:۲۶". Returns "—" for empty input. */
export function formatDateTimeFa(iso: string | null | undefined): string {
  if (!iso) return "—";
  const d = new Date(iso);
  if (Number.isNaN(d.getTime())) return "—";
  const date = d.toLocaleDateString("fa-IR", { year: "numeric", month: "2-digit", day: "2-digit" });
  const time = d.toLocaleTimeString("fa-IR", { hour: "2-digit", minute: "2-digit" });
  return toFaDigits(`${date} ${time}`);
}

export function formatPercent(n: number | string | null | undefined): string {
  if (n === null || n === undefined) return "—";
  return `${toFaDigits(n)}٪`;
}
