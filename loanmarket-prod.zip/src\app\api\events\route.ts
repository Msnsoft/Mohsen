import postgres from "postgres";
import { getCurrentUser } from "@/lib/auth";

// SSE stream of live events for the logged-in user (req. S9 realtime).
// Backed by Postgres LISTEN/NOTIFY: the `notifications` AFTER INSERT trigger
// pg_notify's 'app_events' with {user_id,title}; we forward only this user's.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const url = process.env.DATABASE_URL ?? "postgres://app:app_password@localhost:5432/loanmarket";

export async function GET(req: Request) {
  const user = await getCurrentUser();
  if (!user) return new Response("Unauthorized", { status: 401 });

  const sql = postgres(url, { max: 1 });
  const enc = new TextEncoder();
  let heartbeat: ReturnType<typeof setInterval> | undefined;
  let unlisten: (() => Promise<void>) | undefined;

  const stream = new ReadableStream({
    async start(controller) {
      const send = (s: string) => {
        try { controller.enqueue(enc.encode(s)); } catch { /* closed */ }
      };
      send(`retry: 5000\n: connected\n\n`);

      const sub = await sql.listen("app_events", (payload) => {
        try {
          const data = JSON.parse(payload) as { user_id?: string };
          if (data.user_id === user.id) send(`event: notification\ndata: ${payload}\n\n`);
        } catch { /* ignore malformed */ }
      });
      unlisten = sub.unlisten;
      heartbeat = setInterval(() => send(`: ping\n\n`), 25_000);

      req.signal.addEventListener("abort", async () => {
        if (heartbeat) clearInterval(heartbeat);
        try { await unlisten?.(); } catch { /* */ }
        await sql.end({ timeout: 1 }).catch(() => {});
        try { controller.close(); } catch { /* */ }
      });
    },
    async cancel() {
      if (heartbeat) clearInterval(heartbeat);
      try { await unlisten?.(); } catch { /* */ }
      await sql.end({ timeout: 1 }).catch(() => {});
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}
