import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { formatToman, toFaDigits } from "@/lib/persian";
import { requireSectionPage } from "../guard";

export const dynamic = "force-dynamic";

const TXN_TYPE_FA: Record<string, string> = {
  deposit: "واریز",
  withdrawal: "برداشت",
  escrow_fund: "تأمین امانی",
  escrow_release: "آزادسازی امانی",
  escrow_refund: "استرداد امانی",
  fee_capture: "کارمزد",
  adjustment: "اصلاح",
};

export default async function AdminWalletsPage() {
  const admin = await requireSectionPage("wallets");

  const data = await withUser(admin.id, async (tx) => {
    const systems = await tx.execute<{ system_key: string; balance: string }>(sql`
      select la.system_key, coalesce(sum(le.amount), 0)::text as balance
      from ledger_accounts la
      left join ledger_entries le on le.account_id = la.id
      where la.system_key is not null
      group by la.system_key order by la.system_key`);
    const totals = await tx.execute<{ kind: string; balance: string }>(sql`
      select la.kind, coalesce(sum(le.amount), 0)::text as balance
      from ledger_accounts la
      left join ledger_entries le on le.account_id = la.id
      where la.wallet_id is not null
      group by la.kind`);
    const txns = await tx.execute<{
      id: string; type: string; reference: string | null; created_at: string; volume: string;
    }>(sql`
      select t.id, t.type, t.reference, t.created_at::text,
             coalesce(sum(greatest(le.amount, 0)), 0)::text as volume
      from ledger_transactions t
      join ledger_entries le on le.transaction_id = t.id
      group by t.id order by t.created_at desc limit 50`);
    return { systems, totals, txns };
  });

  const sysFa: Record<string, string> = {
    escrow_liability: "بدهی امانی (وجوه نزد پلتفرم)",
    platform_revenue: "درآمد پلتفرم",
    cash_clearing: "تسویهٔ نقدی",
  };
  const kindFa: Record<string, string> = { available: "موجودی آزاد کاربران", held: "موجودی مسدود کاربران" };

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">کیف پول و دفترکل</h1>

      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {data.totals.map((t) => (
          <Card key={t.kind}>
            <CardMuted>{kindFa[t.kind] ?? t.kind}</CardMuted>
            <p className="mt-1 text-xl font-extrabold">{formatToman(Number(t.balance))}</p>
          </Card>
        ))}
        {data.systems.map((s) => (
          <Card key={s.system_key}>
            <CardMuted>{sysFa[s.system_key] ?? s.system_key}</CardMuted>
            <p className="mt-1 text-xl font-extrabold">{formatToman(Number(s.balance))}</p>
          </Card>
        ))}
      </div>

      <Card className="space-y-3">
        <CardTitle>آخرین تراکنش‌های دفترکل</CardTitle>
        {data.txns.length === 0 ? (
          <CardMuted>تراکنشی ثبت نشده است.</CardMuted>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-right text-xs text-[var(--color-muted)]">
                <tr>
                  <th className="px-2 py-2">نوع</th>
                  <th className="px-2 py-2">حجم</th>
                  <th className="px-2 py-2">مرجع</th>
                  <th className="px-2 py-2">زمان</th>
                </tr>
              </thead>
              <tbody>
                {data.txns.map((t) => (
                  <tr key={t.id} className="border-t border-[var(--color-border)]">
                    <td className="px-2 py-2">{TXN_TYPE_FA[t.type] ?? t.type}</td>
                    <td className="px-2 py-2">{formatToman(Number(t.volume))}</td>
                    <td className="px-2 py-2 text-xs text-[var(--color-muted)]" dir="ltr">{t.reference ?? "—"}</td>
                    <td className="px-2 py-2 text-xs text-[var(--color-muted)]" dir="ltr">{toFaDigits(t.created_at.slice(0, 16))}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>
    </div>
  );
}
