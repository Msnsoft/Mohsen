# Loan Marketplace — Platform (Next.js)

Increment 1: runnable foundation + core vertical slice, on the locked stack
(Next.js App Router · PostgreSQL + Drizzle · session-GUC RLS · double-entry money
functions · Auth.js-style OTP · MinIO · Docker · Persian RTL). See `../docs/`.

## What works in this increment
- **Persian RTL UI** (Vazirmatn), dark fintech theme.
- **OTP login** (dev mode prints the code to the server console) → own session cookie (JWT via `jose`).
- **Marketplace**: landing + listing grid + listing detail with **real APR/EAR/fair-value/risk** (carried-over finance engine), all DB-driven.
- **Wallet**: real **double-entry** deposit (balanced ledger, enforced in Postgres) + ledger history; balances derived from entries.
- **Membership** plans page (DB-driven) and **calculator** (live).
- **Admin** dashboard (role-gated) with real counts.
- **RLS** on every table keyed on the `app.user_id` session GUC (no Supabase).

## Not yet (next increments)
Deal + escrow workflow, commission capture (progressive engine), subscription purchase,
split matching, disputes, tickets, notifications/SMS, CMS, full admin builders, SSE realtime, worker (pg-boss).

## Prerequisites
- Node.js 20+ and npm
- Docker Desktop (for Postgres + MinIO)

## Run (recommended: DB in Docker, app local for fast iteration)
```bash
# 1) start Postgres (auto-runs db/init/*.sql on first boot) + MinIO + Adminer
docker compose up -d postgres minio createbuckets adminer

# 2) configure env
cp .env.example .env            # Windows: copy .env.example .env

# 3) install deps & run
npm install
npm run dev                     # http://localhost:3000
```

### Or run everything in Docker
```bash
docker compose --profile full up --build
```

## Log in (dev)
1. Go to `/login`, enter a mobile number.
2. The OTP code is **printed in the server console** (and shown on screen in dev mode).
3. Seeded accounts (login by mobile):
   - **Super admin**: `09120000000` (email `mohsen.hajalizadeh@gmail.com`)
   - Demo seller: `09121111111`
   Any other number creates a normal user on first login.

## Useful
- Adminer (DB UI): http://localhost:8080 (system PostgreSQL, server `postgres`, user `postgres`, pass `postgres`, db `loanmarket`)
- MinIO console: http://localhost:9001 (minioadmin / minioadmin)
- Reset DB (re-run init SQL): `docker compose down -v && docker compose up -d postgres`

## Layout
```
db/init/         authoritative SQL: schema + RLS + money functions + seed
src/db/          Drizzle schema + client (withUser session-GUC helper)
src/lib/         session, otp, auth, persian, finance/
src/services/    business reads (marketplace)
src/app/         routes (App Router): /, /marketplace, /marketplace/[id], /login, /wallet, /membership, /calculator, /admin
src/components/  UI (header, listing-card, ui/*)
```

## Notes
- Money stored as **bigint IRR**; UI shows toman (÷10). Never float.
- The app connects as the non-superuser `app` role so **RLS applies**; money writes go through `SECURITY DEFINER` Postgres functions.
- Vazirmatn is loaded from CDN in dev — self-host it for the Iranian production target.
