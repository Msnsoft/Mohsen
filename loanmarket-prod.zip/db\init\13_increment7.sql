-- =====================================================================
-- Increment 7 · automation: penalties/cancel-lock (P), seller-transfer
-- timeout job, SSE notify trigger, stage-visibility config (Q).
-- Idempotent. Money still moves only via post_transaction.
-- =====================================================================
SET check_function_bodies = off;

-- ---- P: penalized buyer self-cancel (fee non-refundable) ---------------
-- deal_refund() = no-fault full refund (admin / seller-timeout). This is the
-- buyer-initiated cancel after acceptance: the buyer forfeits the fee
-- (req. P "once accepted, cannot be cancelled without penalty"). The escrow
-- principal is still returned; only buyer_fee is captured to platform_revenue.
CREATE OR REPLACE FUNCTION deal_buyer_cancel(_deal uuid, _actor uuid) RETURNS void
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _e escrows%ROWTYPE; _esc uuid; _b_avail uuid; _b_held uuid; _rev uuid; _forfeit boolean;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _actor <> _d.buyer_id THEN RAISE EXCEPTION 'forbidden'; END IF;
  IF _d.state <> 'waiting_seller_transfer' THEN RAISE EXCEPTION 'cannot cancel at this stage'; END IF;

  SELECT (value #>> '{}')::boolean INTO _forfeit FROM config WHERE key = 'deal.cancel_forfeits_fee';
  _forfeit := COALESCE(_forfeit, true);

  SELECT * INTO _e FROM escrows WHERE deal_id = _deal FOR UPDATE;

  -- handshake (no custody, no fee): behaves like a plain cancel
  IF _e.state = 'bypassed' OR _d.buyer_fee = 0 OR NOT _forfeit THEN
    PERFORM deal_refund(_deal, _actor, 'cancelled by buyer');
    RETURN;
  END IF;

  _esc     := system_account('escrow_liability');
  _b_avail := user_account(_d.buyer_id, 'available');
  _b_held  := user_account(_d.buyer_id, 'held');
  _rev     := system_account('platform_revenue');
  -- principal back to buyer; held fee captured to platform (penalty)
  PERFORM post_transaction('escrow_refund', 'deal_cancel_' || _deal, _deal::text, _actor,
    jsonb_build_array(
      jsonb_build_object('account_id', _esc,     'amount', -_d.loan_price),
      jsonb_build_object('account_id', _b_avail, 'amount',  _d.loan_price),
      jsonb_build_object('account_id', _b_held,  'amount', -_d.buyer_fee),
      jsonb_build_object('account_id', _rev,     'amount',  _d.buyer_fee)
    ));
  UPDATE escrows SET state = 'refunded', refunded_at = now() WHERE id = _e.id;
  UPDATE deals SET state = 'cancelled' WHERE id = _deal;
  UPDATE commission_charges SET state = 'captured' WHERE deal_id = _deal AND side = 'buyer';
  UPDATE commission_charges SET state = 'reversed' WHERE deal_id = _deal AND side = 'seller';
  UPDATE loan_posts SET status = 'active', updated_at = now() WHERE id = _d.listing_id;
  INSERT INTO escrow_events(escrow_id, to_state, actor_id, reason) VALUES (_e.id, 'refunded', _actor, 'buyer cancelled (fee forfeited)');
  INSERT INTO notifications(user_id, title, body) VALUES
    (_d.seller_id, 'معامله لغو شد', 'خریدار معامله را لغو کرد و آگهی دوباره فعال شد.'),
    (_d.buyer_id,  'لغو معامله', 'وجه امانی به کیف پول شما بازگشت؛ کارمزد طبق قوانین لغو، بازگردانده نشد.');
END $$;

-- ---- P: seller-transfer timeout → no-fault refund to buyer -------------
-- If the seller misses the transfer deadline, the buyer is made whole
-- (full refund) and the seller is notified of the missed deadline.
CREATE OR REPLACE FUNCTION seller_transfer_timeout_due() RETURNS int
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d record; _hours int; _n int := 0;
BEGIN
  SELECT (value #>> '{seller_transfer}')::int INTO _hours FROM config WHERE key = 'deal.step_deadline_hours';
  _hours := COALESCE(_hours, 72);
  FOR _d IN
    SELECT id, buyer_id, seller_id FROM deals
    WHERE state = 'waiting_seller_transfer'
      AND created_at <= now() - (_hours || ' hours')::interval
  LOOP
    PERFORM deal_refund(_d.id, _d.buyer_id, 'seller transfer timeout');
    INSERT INTO notifications(user_id, title, body)
    VALUES (_d.seller_id, 'مهلت انتقال منقضی شد',
            'به دلیل عدم انتقال وام در مهلت مقرر، معامله لغو و وجه به خریدار بازگردانده شد.');
    _n := _n + 1;
  END LOOP;
  RETURN _n;
END $$;

-- recreate the aggregate runner to include the seller-transfer timeout
DROP FUNCTION IF EXISTS run_due_jobs();
CREATE OR REPLACE FUNCTION run_due_jobs()
RETURNS TABLE (auto_released int, seller_timeouts int, reminders int, expired int)
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
BEGIN
  RETURN QUERY SELECT escrow_auto_release_due(), seller_transfer_timeout_due(),
                      seller_timeout_reminders(), subscriptions_expire_due();
END $$;

-- ---- SSE: NOTIFY on every new notification -----------------------------
CREATE OR REPLACE FUNCTION notify_new_notification() RETURNS trigger
LANGUAGE plpgsql AS $$
BEGIN
  PERFORM pg_notify('app_events',
    json_build_object('user_id', NEW.user_id, 'title', NEW.title)::text);
  RETURN NEW;
END $$;
DROP TRIGGER IF EXISTS trg_notify_notification ON notifications;
CREATE TRIGGER trg_notify_notification AFTER INSERT ON notifications
  FOR EACH ROW EXECUTE FUNCTION notify_new_notification();

-- ---- config: cancel penalty + admin stage visibility (Q) ---------------
INSERT INTO config(key, value) VALUES
  ('deal.cancel_forfeits_fee', 'true'::jsonb),
  ('deal.hidden_stages',       '[]'::jsonb)
ON CONFLICT (key) DO NOTHING;

GRANT EXECUTE ON FUNCTION
  deal_buyer_cancel(uuid, uuid),
  seller_transfer_timeout_due(),
  run_due_jobs()
TO app;
