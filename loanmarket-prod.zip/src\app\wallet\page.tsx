import { requireActiveUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DepositForm } from "./deposit-form";
import { WithdrawForm } from "./withdraw-form";
import { formatToman, toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

const TYPE_FA: Record<string, string> = {
  deposit: "واریز", withdrawal: "برداشت", fee_capture: "کارمزد",
  refund: "بازگشت وجه", escrow_release: "تسویه امانی", adjustment: "اصلاح",
  subscription_fee: "خرید اشتراک",
};

const WD_STATUS_FA: Record<string, { label: string; tone: "warning" | "accent" | "danger" }> = {
  pending: { label: "در انتظار تأیید", tone: "warning" },
  approved: { label: "تأییدشده", tone: "accent" },
  rejected: { label: "ردشده", tone: "danger" },
};

/** Human-readable statement description incl. reference / test marker (req. Y/Z). */
function describe(type: string, reference: string | null): string {
  const ref = reference ?? "";
  if (type === "subscription_fee") {
    const key = ref.replace(/^plan_/, "");
    return `خرید اشتراک${key ? ` — پلن ${key}` : ""}`;
  }
  if (type === "deposit") {
    const code = ref.replace(/^dep_/, "").slice(0, 8);
    return `شارژ کیف پول${code ? ` — کد پیگیری ${code}` : ""} (تستی)`;
  }
  if (type === "withdrawal") return "درخواست/تسویهٔ برداشت";
  if (type === "refund") return "بازگشت وجه به کیف پول";
  return TYPE_FA[type] ?? type;
}

export default async function WalletPage() {
  const user = await requireActiveUser();

  const rows = await withUser(user.id, (tx) =>
    tx.execute<{ type: string; amount: string; created_at: string; reference: string | null }>(sql`
      select lt.type, le.amount::text as amount, lt.created_at, lt.reference
      from ledger_entries le
      join ledger_accounts la on la.id = le.account_id
      join wallets w on w.id = la.wallet_id
      join ledger_transactions lt on lt.id = le.transaction_id
      where w.user_id = ${user.id} and la.kind = 'available'
      order by lt.created_at desc
      limit 50
    `),
  );

  const held = await withUser(user.id, (tx) =>
    tx.execute<{ bal: string }>(sql`select wallet_balance(${user.id}, 'held')::text as bal`),
  );

  const profile = await withUser(user.id, (tx) =>
    tx.execute<{ sheba: string | null }>(sql`select sheba from users where id = ${user.id}`),
  );
  const sheba = (profile[0] as { sheba: string | null } | undefined)?.sheba ?? null;

  const withdrawals = await withUser(user.id, (tx) =>
    tx.execute<{ amount: string; status: string; created_at: string }>(sql`
      select amount::text as amount, status, created_at
      from withdrawal_requests where user_id = ${user.id}
      order by created_at desc limit 10`),
  ) as { amount: string; status: string; created_at: string }[];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">کیف پول</h1>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <Card className="lg:col-span-2">
          <CardMuted>موجودی قابل برداشت</CardMuted>
          <p className="mt-1 text-3xl font-extrabold text-[var(--color-accent)]">{formatToman(user.availableBalance)}</p>
          <p className="mt-1 text-sm text-[var(--color-muted)]">مسدودی: {formatToman(Number(held[0]?.bal ?? 0))}</p>
        </Card>
        <Card>
          <CardTitle>واریز (شارژ)</CardTitle>
          <div className="mt-3"><DepositForm prefersMillion={user.prefersMillion} /></div>
        </Card>
        <Card>
          <CardTitle>برداشت</CardTitle>
          <div className="mt-3"><WithdrawForm sheba={sheba} prefersMillion={user.prefersMillion} /></div>
        </Card>
      </div>

      {withdrawals.length > 0 && (
        <Card>
          <CardTitle>درخواست‌های برداشت</CardTitle>
          <table className="mt-3 w-full text-sm">
            <thead className="text-[var(--color-muted)]">
              <tr className="border-b border-[var(--color-border)]">
                <th className="py-2 text-start">مبلغ</th>
                <th className="py-2 text-start">وضعیت</th>
                <th className="py-2 text-start">تاریخ</th>
              </tr>
            </thead>
            <tbody>
              {withdrawals.map((w, i) => (
                <tr key={i} className="border-b border-[var(--color-border)]/50">
                  <td className="py-2"><span dir="ltr">{formatToman(Number(w.amount))}</span></td>
                  <td className="py-2"><Badge tone={WD_STATUS_FA[w.status]?.tone ?? "warning"}>{WD_STATUS_FA[w.status]?.label ?? w.status}</Badge></td>
                  <td className="py-2 text-[var(--color-muted)]">{toFaDigits(new Date(w.created_at).toLocaleDateString("fa-IR"))}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>
      )}

      <Card>
        <CardTitle>گردش حساب</CardTitle>
        {rows.length === 0 ? (
          <CardMuted>هنوز تراکنشی ثبت نشده است.</CardMuted>
        ) : (
          <table className="mt-3 w-full text-sm">
            <thead className="text-[var(--color-muted)]">
              <tr className="border-b border-[var(--color-border)]">
                <th className="py-2 text-start">شرح</th>
                <th className="py-2 text-start">مبلغ</th>
                <th className="py-2 text-start">تاریخ</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r, i) => {
                const amt = Number(r.amount);
                return (
                  <tr key={i} className="border-b border-[var(--color-border)]/50">
                    <td className="py-2">{describe(r.type, r.reference)}</td>
                    <td className={`py-2 text-start ${amt >= 0 ? "text-[var(--color-accent)]" : "text-[var(--color-danger)]"}`}>
                      <span dir="ltr">{amt >= 0 ? "+" : "−"} {formatToman(Math.abs(amt))}</span>
                    </td>
                    <td className="py-2 text-[var(--color-muted)]">
                      {toFaDigits(new Date(r.created_at).toLocaleDateString("fa-IR"))}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
