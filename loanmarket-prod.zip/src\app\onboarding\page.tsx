import { redirect } from "next/navigation";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";
import OnboardingForm, { type OnboardField } from "./OnboardingForm";

export const dynamic = "force-dynamic";

export default async function OnboardingPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status === "active") redirect("/panel");

  const rows = await withUser(user.id, (tx) =>
    tx.execute<{ key: string; label: string; required: boolean }>(sql`
      select key, label, required from onboarding_fields
      where active order by sort, label`),
  );
  const fields = (rows as OnboardField[]) ?? [];

  return (
    <div className="mx-auto max-w-xl py-8">
      <OnboardingForm fields={fields} mobile={user.mobile} defaultDisplayName={user.displayName ?? ""} />
    </div>
  );
}
