// Ticket statuses per M12 (Zendesk model).
export const TICKET_STATUS_FA: Record<string, string> = {
  new: "جدید",
  open: "باز",
  pending: "در انتظار پاسخ شما",
  on_hold: "معلق",
  solved: "حل‌شده",
  closed: "بسته",
};

export const TICKET_PRIORITY_FA: Record<string, string> = {
  low: "کم",
  normal: "عادی",
  high: "زیاد",
  urgent: "فوری",
};

type Tone = "default" | "accent" | "warning" | "danger" | "muted";
export function ticketStatusTone(status: string): Tone {
  switch (status) {
    case "new": return "warning";
    case "open": return "default";
    case "pending": return "warning";
    case "on_hold": return "muted";
    case "solved": return "accent";
    case "closed": return "muted";
    default: return "default";
  }
}

/** Statuses where the conversation is still live. */
export const TICKET_OPEN_STATUSES = ["new", "open", "pending", "on_hold"];
