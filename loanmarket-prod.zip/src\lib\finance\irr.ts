// Internal rate of return via bisection/Newton hybrid. Carried from the prototype.
export function npv(rate: number, cashflows: number[]): number {
  return cashflows.reduce((acc, cf, t) => acc + cf / Math.pow(1 + rate, t), 0);
}

/** Monthly IRR for a cashflow array (index = month). Returns null if not solvable. */
export function irr(cashflows: number[], guess = 0.01): number | null {
  let rate = guess;
  for (let i = 0; i < 100; i++) {
    const f = npv(rate, cashflows);
    const df = cashflows.reduce((acc, cf, t) => acc - (t * cf) / Math.pow(1 + rate, t + 1), 0);
    if (Math.abs(df) < 1e-10) break;
    const next = rate - f / df;
    if (!Number.isFinite(next)) break;
    if (Math.abs(next - rate) < 1e-8) return next;
    rate = next;
  }
  // fallback bisection
  let lo = -0.9, hi = 1;
  let flo = npv(lo, cashflows);
  for (let i = 0; i < 200; i++) {
    const mid = (lo + hi) / 2;
    const fmid = npv(mid, cashflows);
    if (Math.abs(fmid) < 1e-7) return mid;
    if (flo * fmid < 0) hi = mid; else { lo = mid; flo = fmid; }
  }
  return null;
}

export function annualizeMonthly(monthly: number): number {
  return Math.pow(1 + monthly, 12) - 1;
}
