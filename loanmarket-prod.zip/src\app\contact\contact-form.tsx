"use client";
import { useActionState } from "react";
import { contactAction, type ContactState } from "./actions";
import { Button } from "@/components/ui/button";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export function ContactForm() {
  const [state, action, pending] = useActionState<ContactState, FormData>(contactAction, {});

  if (state.ok) {
    return (
      <p className="rounded-xl border border-[var(--color-accent)] p-4 text-sm text-[var(--color-accent)]">
        پیام شما ثبت شد و به‌صورت یک تیکت پشتیبانی پیگیری می‌شود. می‌توانید پاسخ را در بخش «پشتیبانی» پنل ببینید.
      </p>
    );
  }

  return (
    <form action={action} className="space-y-3">
      <label className="block space-y-1 text-sm">
        <span className="text-[var(--color-muted)]">موضوع</span>
        <input name="subject" className={inputCls} required />
      </label>
      <label className="block space-y-1 text-sm">
        <span className="text-[var(--color-muted)]">پیام شما</span>
        <textarea name="body" rows={5} className={inputCls} required />
      </label>
      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}
      <Button type="submit" disabled={pending}>{pending ? "در حال ارسال…" : "ارسال پیام"}</Button>
      <p className="text-xs text-[var(--color-muted)]">پیام شما از طریق فرم تماس ثبت و در سامانهٔ پشتیبانی پیگیری می‌شود.</p>
    </form>
  );
}
