import { notFound, redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { TICKET_STATUS_FA, TICKET_PRIORITY_FA, ticketStatusTone, TICKET_OPEN_STATUSES } from "@/lib/ticket-status";
import { userReplyTicketAction, userCloseTicketAction } from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export default async function TicketThreadPage({ params }: { params: Promise<{ id: string }> }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const { id } = await params;

  const data = await withUser(user.id, async (tx) => {
    const tickets = await tx.execute<{
      id: string; subject: string; status: string; priority: string; created_at: string; user_id: string;
    }>(sql`select id, subject, status, priority, created_at::text, user_id from tickets where id = ${id}`);
    const ticket = tickets[0];
    if (!ticket) return null;
    const messages = await tx.execute<{
      id: string; body: string; author_id: string; author_name: string | null; created_at: string;
    }>(sql`
      select m.id, m.body, m.author_id, u.display_name as author_name, m.created_at::text
      from ticket_messages m join users u on u.id = m.author_id
      where m.ticket_id = ${id} and not m.is_internal
      order by m.created_at`);
    return { ticket, messages };
  });
  if (!data) notFound();
  const { ticket, messages } = data;
  const live = TICKET_OPEN_STATUSES.includes(ticket.status) || ticket.status === "solved";

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-xl font-bold">{ticket.subject}</h1>
        <div className="flex items-center gap-2">
          <Badge tone="muted">اولویت: {TICKET_PRIORITY_FA[ticket.priority] ?? ticket.priority}</Badge>
          <Badge tone={ticketStatusTone(ticket.status)}>{TICKET_STATUS_FA[ticket.status] ?? ticket.status}</Badge>
        </div>
      </div>

      <div className="space-y-3">
        {messages.map((m) => {
          const mine = m.author_id === user.id;
          return (
            <Card key={m.id} className={mine ? "" : "border-[var(--color-primary)]"}>
              <div className="mb-1 flex items-center justify-between text-xs text-[var(--color-muted)]">
                <span>{mine ? "شما" : m.author_name ?? "پشتیبانی"}</span>
                <span dir="ltr">{m.created_at.slice(0, 16)}</span>
              </div>
              <p className="whitespace-pre-wrap text-sm">{m.body}</p>
            </Card>
          );
        })}
      </div>

      {live ? (
        <Card className="space-y-3">
          <form action={userReplyTicketAction} className="space-y-3">
            <input type="hidden" name="ticket_id" value={ticket.id} />
            <textarea name="body" rows={3} placeholder="پاسخ شما…" className={inputCls} required />
            <div className="flex gap-2">
              <Button type="submit" size="sm">ارسال پاسخ</Button>
            </div>
          </form>
          <form action={userCloseTicketAction}>
            <input type="hidden" name="ticket_id" value={ticket.id} />
            <Button type="submit" size="sm" variant="ghost" className="text-[var(--color-muted)]">
              مشکل حل شد — بستن تیکت
            </Button>
          </form>
        </Card>
      ) : (
        <Card className="text-sm text-[var(--color-muted)]">این تیکت بسته شده است. در صورت نیاز تیکت جدیدی ثبت کنید.</Card>
      )}
    </div>
  );
}
