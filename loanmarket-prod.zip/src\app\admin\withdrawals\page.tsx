import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireSectionPage } from "../guard";
import { decideWithdrawalAction } from "../actions";
import { formatToman, toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

const STATUS_FA: Record<string, { label: string; tone: "warning" | "accent" | "danger" }> = {
  pending: { label: "در انتظار", tone: "warning" },
  approved: { label: "تأییدشده", tone: "accent" },
  rejected: { label: "ردشده", tone: "danger" },
};

export default async function AdminWithdrawalsPage() {
  const admin = await requireSectionPage("withdrawals");
  const rows = await withUser(admin.id, (tx) =>
    tx.execute<{ id: string; amount: string; sheba: string | null; status: string; created_at: string; mobile: string; display_name: string | null }>(
      sql`select w.id, w.amount::text as amount, w.sheba, w.status, w.created_at,
                 u.mobile, u.display_name
          from withdrawal_requests w join users u on u.id = w.user_id
          order by (w.status = 'pending') desc, w.created_at desc limit 100`),
  ) as { id: string; amount: string; sheba: string | null; status: string; created_at: string; mobile: string; display_name: string | null }[];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">درخواست‌های برداشت</h1>
      <CardMuted>تأیید یا رد درخواست‌های برداشت کاربران. تأیید، تسویه را نهایی می‌کند؛ رد، مبلغ را به کیف پول بازمی‌گرداند.</CardMuted>

      <Card>
        {rows.length === 0 ? (
          <CardMuted>درخواستی وجود ندارد.</CardMuted>
        ) : (
          <table className="w-full text-sm">
            <thead className="text-[var(--color-muted)]">
              <tr className="border-b border-[var(--color-border)]">
                <th className="py-2 text-start">کاربر</th><th className="py-2 text-start">مبلغ</th>
                <th className="py-2 text-start">شبا</th><th className="py-2 text-start">وضعیت</th>
                <th className="py-2 text-start">تاریخ</th><th className="py-2 text-start">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id} className="border-b border-[var(--color-border)]/50">
                  <td className="py-2">{r.display_name ?? <span dir="ltr">{r.mobile}</span>}</td>
                  <td className="py-2"><span dir="ltr">{formatToman(Number(r.amount))}</span></td>
                  <td className="py-2 text-xs text-[var(--color-muted)]" dir="ltr">{r.sheba ? `IR${r.sheba}` : "—"}</td>
                  <td className="py-2"><Badge tone={STATUS_FA[r.status]?.tone ?? "warning"}>{STATUS_FA[r.status]?.label ?? r.status}</Badge></td>
                  <td className="py-2 text-[var(--color-muted)]">{toFaDigits(new Date(r.created_at).toLocaleDateString("fa-IR"))}</td>
                  <td className="py-2">
                    {r.status === "pending" ? (
                      <div className="flex gap-2">
                        <form action={decideWithdrawalAction}>
                          <input type="hidden" name="request_id" value={r.id} />
                          <input type="hidden" name="decision" value="approve" />
                          <Button size="sm" variant="primary" type="submit">تأیید</Button>
                        </form>
                        <form action={decideWithdrawalAction}>
                          <input type="hidden" name="request_id" value={r.id} />
                          <input type="hidden" name="decision" value="reject" />
                          <Button size="sm" variant="ghost" type="submit">رد</Button>
                        </form>
                      </div>
                    ) : <span className="text-xs text-[var(--color-muted)]">—</span>}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>
    </div>
  );
}
