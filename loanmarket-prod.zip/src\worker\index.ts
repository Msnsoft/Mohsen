/**
 * Background worker (req. S9 / P). Runs the due-job sweep on an interval:
 *   - escrow auto-release after the inspection deadline
 *   - seller-transfer timeout → no-fault refund to buyer
 *   - seller-transfer reminders
 *   - subscription expiry
 *
 * Run standalone:  npm run worker   (loads platform/.env)
 * The same `run_due_jobs()` is also exposed to admins as a "run now" button.
 *
 * Iteration 8 swaps this setInterval loop for pg-boss scheduling without
 * changing the SQL job functions.
 */
import { readFileSync } from "node:fs";
import path from "node:path";
import postgres from "postgres";

// minimal .env loader (standalone scripts don't get Next's env injection)
function loadEnv() {
  try {
    const txt = readFileSync(path.join(process.cwd(), ".env"), "utf8");
    for (const line of txt.split(/\r?\n/)) {
      const m = /^\s*([\w.]+)\s*=\s*(.*)\s*$/.exec(line);
      if (m && !process.env[m[1]]) process.env[m[1]] = m[2].replace(/^["']|["']$/g, "");
    }
  } catch {
    /* no .env — rely on process env */
  }
}
loadEnv();

const url = process.env.DATABASE_URL ?? "postgres://app:app_password@localhost:5432/loanmarket";
const intervalMs = Number(process.env.WORKER_INTERVAL_MS ?? 60_000);
const sql = postgres(url, { max: 2 });

// M14: push pending notifications to SMS (gated by config notifications.sms_enabled).
async function sendSms(mobile: string, text: string) {
  const url = process.env.SMS_API_URL;
  if ((process.env.SMS_PROVIDER ?? "console") === "console" || !url) {
    console.log(`[SMS→${mobile}] ${text}`);
    return;
  }
  await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      ...(process.env.SMS_API_KEY ? { Authorization: `Bearer ${process.env.SMS_API_KEY}` } : {}),
    },
    body: JSON.stringify({ to: mobile, from: process.env.SMS_FROM ?? "", message: text }),
  });
}

async function dispatchNotifications() {
  const pending = await sql`select * from notifications_pending_dispatch(50)`;
  for (const n of pending) {
    try {
      await sendSms(n.mobile as string, `${n.title}\n${n.body ?? ""}`.trim());
      await sql`select notifications_mark_dispatched(${n.id as string}, null)`;
    } catch (e) {
      await sql`select notifications_mark_dispatched(${n.id as string}, ${e instanceof Error ? e.message : "send failed"})`;
    }
  }
  if (pending.length) console.log(`[worker] dispatched ${pending.length} notification(s)`);
}

let running = false;
async function tick() {
  if (running) return; // never overlap sweeps
  running = true;
  try {
    const [r] = await sql`select * from run_due_jobs()`;
    if (r && (r.auto_released || r.seller_timeouts || r.reminders || r.expired)) {
      console.log(
        `[worker ${new Date().toISOString()}] auto_released=${r.auto_released} ` +
          `seller_timeouts=${r.seller_timeouts} reminders=${r.reminders} expired=${r.expired}`,
      );
    }
    await dispatchNotifications();
  } catch (e) {
    console.error("[worker] tick failed:", e instanceof Error ? e.message : e);
  } finally {
    running = false;
  }
}

async function main() {
  console.log(`[worker] started; sweeping every ${intervalMs}ms`);
  await tick();
  const timer = setInterval(tick, intervalMs);

  for (const sig of ["SIGINT", "SIGTERM"] as const) {
    process.on(sig, async () => {
      console.log(`[worker] ${sig} — shutting down`);
      clearInterval(timer);
      await sql.end({ timeout: 5 });
      process.exit(0);
    });
  }
}

main().catch((e) => {
  console.error("[worker] fatal:", e);
  process.exit(1);
});
