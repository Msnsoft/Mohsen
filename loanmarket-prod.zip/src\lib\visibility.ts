import "server-only";
import { db, sql } from "@/db";

/**
 * Listing field visibility per user level (req. L). Admin defines, in config
 * `listings.visibility_levels`, which fields each level may see, e.g.
 *   {"guest":["loan_type","bank","rate"], "member":["all"]}
 * Guests = not logged in; members = any logged-in user.
 */
export type ViewerLevel = "guest" | "member";
export type ListingFieldKey = "value" | "price" | "rate" | "duration" | "province";
export type Allowed = Set<ListingFieldKey> | "all";

const GATED: ListingFieldKey[] = ["value", "price", "rate", "duration", "province"];

export async function getListingVisibility(level: ViewerLevel): Promise<Allowed> {
  try {
    const rows = (await db.execute<{ value: Record<string, string[]> }>(
      sql`select value from config where key = 'listings.visibility_levels'`,
    )) as { value: Record<string, string[]> }[];
    const cfg = rows[0]?.value ?? {};
    const allowed = cfg[level] ?? (level === "member" ? ["all"] : ["loan_type", "bank", "rate"]);
    if (allowed.includes("all")) return "all";
    return new Set(allowed.filter((f): f is ListingFieldKey => (GATED as string[]).includes(f)));
  } catch {
    return "all"; // fail open: never hide everything on a config error
  }
}

export function canSee(allowed: Allowed, field: ListingFieldKey): boolean {
  return allowed === "all" || allowed.has(field);
}
