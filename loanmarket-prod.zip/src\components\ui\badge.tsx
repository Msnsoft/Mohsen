import * as React from "react";
import { cn } from "@/lib/utils";

type Tone = "default" | "accent" | "warning" | "danger" | "muted";
const tones: Record<Tone, string> = {
  default: "bg-[var(--color-surface-2)] text-[var(--color-fg)]",
  accent: "bg-[color-mix(in_oklab,var(--color-accent)_20%,transparent)] text-[var(--color-accent)]",
  warning: "bg-[color-mix(in_oklab,var(--color-warning)_20%,transparent)] text-[var(--color-warning)]",
  danger: "bg-[color-mix(in_oklab,var(--color-danger)_20%,transparent)] text-[var(--color-danger)]",
  muted: "bg-transparent text-[var(--color-muted)] border border-[var(--color-border)]",
};

export function Badge({ tone = "default", className, ...props }: { tone?: Tone } & React.HTMLAttributes<HTMLSpanElement>) {
  return <span className={cn("inline-flex items-center rounded-full px-2.5 py-0.5 text-xs font-medium", tones[tone], className)} {...props} />;
}
