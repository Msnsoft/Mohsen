import type { Metadata } from "next";
import Link from "next/link";
import { cookies } from "next/headers";
import "./globals.css";
import { SiteHeader } from "@/components/site-header";
import { LiveUpdates } from "@/components/live-updates";
import { getCurrentUser } from "@/lib/auth";
import { db, sql } from "@/db";
import { getMenu } from "@/lib/cms";
import { DEFAULT_THEME, THEME_COOKIE, isThemeKey, type ThemeKey } from "@/lib/themes";

async function defaultThemeFromConfig(): Promise<ThemeKey> {
  try {
    const rows = await db.execute<{ value: string }>(
      sql`select value::text as value from config where key = 'ui.default_theme'`,
    );
    const v = rows[0]?.value?.replaceAll('"', "");
    return isThemeKey(v) ? v : DEFAULT_THEME;
  } catch {
    return DEFAULT_THEME;
  }
}

/** Branding from CMS config (req. X logo + site name). */
async function brandFromConfig(): Promise<{ siteName: string; logoUrl: string }> {
  try {
    const rows = await db.execute<{ key: string; value: string }>(
      sql`select key, value::text as value from config where key in ('cms.site_name','cms.logo_url')`,
    );
    const map = Object.fromEntries(
      (rows as { key: string; value: string }[]).map((r) => [r.key, r.value?.replace(/^"|"$/g, "") ?? ""]),
    );
    return { siteName: map["cms.site_name"] || "بازار امتیاز وام", logoUrl: map["cms.logo_url"] || "" };
  } catch {
    return { siteName: "بازار امتیاز وام", logoUrl: "" };
  }
}

export const metadata: Metadata = {
  title: "بازار امتیاز وام",
  description: "خرید و فروش امن امتیاز وام‌های قابل انتقال",
};

export default async function RootLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  const cookieTheme = (await cookies()).get(THEME_COOKIE)?.value;
  const footerMenu = await getMenu("footer");
  const brand = await brandFromConfig();
  // logged-in account preference wins; guests fall back to their cookie, then the admin default
  const theme = isThemeKey(user?.theme)
    ? user!.theme
    : isThemeKey(cookieTheme)
      ? cookieTheme
      : await defaultThemeFromConfig();

  return (
    <html lang="fa" dir="rtl" data-theme={theme}>
      <head>
        {/* Vazirmatn (self-host in production per ADR; CDN for dev) */}
        <link
          rel="stylesheet"
          href="https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css"
        />
      </head>
      <body>
        <SiteHeader
          user={
            user
              ? {
                  displayName: user.displayName ?? user.mobile,
                  isAdmin: user.isAdmin,
                  balance: user.availableBalance,
                  unreadMessages: user.unreadMessages,
                }
              : null
          }
          theme={theme}
          siteName={brand.siteName}
          logoUrl={brand.logoUrl}
        />
        {user && <LiveUpdates />}
        <main className="mx-auto w-full max-w-6xl px-4 py-6">{children}</main>
        <footer className="mx-auto w-full max-w-6xl space-y-3 px-4 py-10 text-center text-sm text-[var(--color-muted)]">
          <nav className="flex flex-wrap justify-center gap-x-5 gap-y-2">
            {footerMenu.map((m) => (
              <Link key={m.url} href={m.url} className="hover:text-[var(--color-fg)]">{m.label}</Link>
            ))}
            <Link href="/contact" className="hover:text-[var(--color-fg)]">تماس با ما</Link>
            <Link href="/faq" className="hover:text-[var(--color-fg)]">سؤالات متداول</Link>
          </nav>
          <p>{brand.siteName} — نسخه نمونه</p>
        </footer>
      </body>
    </html>
  );
}
