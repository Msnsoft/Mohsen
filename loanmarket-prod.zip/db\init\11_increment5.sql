-- =====================================================================
-- Increment 5 · Slices S2–S9 — schema + functions.
-- Idempotent: safe to re-run. Money still moves only via post_transaction.
-- =====================================================================
SET check_function_bodies = off;

-- ---- E: special users (may transact on behalf of others) -----------
ALTER TABLE users ADD COLUMN IF NOT EXISTS is_special boolean NOT NULL DEFAULT false;

-- ---- AA: ticket source (contact-form vs panel) ---------------------
ALTER TABLE tickets ADD COLUMN IF NOT EXISTS source text NOT NULL DEFAULT 'panel';

-- ---- M: admin-defined label rules ----------------------------------
-- Each rule lights a badge on a listing when a numeric field crosses a
-- threshold. field ∈ {rate, price_per_million, duration_months, loan_value}.
CREATE TABLE IF NOT EXISTS label_rules (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  key       text UNIQUE NOT NULL,
  label     text NOT NULL,
  tone      text NOT NULL DEFAULT 'warning',   -- default|accent|warning|danger|muted
  field     text NOT NULL,
  op        text NOT NULL DEFAULT '>=',         -- >= | <= | > | <
  threshold numeric NOT NULL,
  active    boolean NOT NULL DEFAULT true,
  sort      integer NOT NULL DEFAULT 0
);
ALTER TABLE label_rules ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_label_read  ON label_rules;
DROP POLICY IF EXISTS p_label_admin ON label_rules;
CREATE POLICY p_label_read  ON label_rules FOR SELECT USING (true);
CREATE POLICY p_label_admin ON label_rules USING (is_admin()) WITH CHECK (is_admin());
INSERT INTO label_rules(key, label, tone, field, op, threshold, sort) VALUES
  ('high_rate',      'سود مؤثر بالا',  'danger',  'rate',              '>=', 23, 1),
  ('heavy_install',  'بار قسط سنگین',  'warning', 'price_per_million', '>=', 250000, 2),
  ('low_rate',       'سود کم',         'accent',  'rate',              '<=', 4, 3)
ON CONFLICT (key) DO NOTHING;

-- ---- I: withdrawal requests (M10) ----------------------------------
CREATE TABLE IF NOT EXISTS withdrawal_requests (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id    uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  amount     bigint NOT NULL CHECK (amount > 0),
  sheba      text,
  status     text NOT NULL DEFAULT 'pending',   -- pending|approved|rejected
  note       text,
  created_at timestamptz NOT NULL DEFAULT now(),
  decided_at timestamptz,
  decided_by uuid REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS withdrawal_user_idx ON withdrawal_requests(user_id, created_at DESC);
ALTER TABLE withdrawal_requests ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_wd_self  ON withdrawal_requests;
DROP POLICY IF EXISTS p_wd_admin ON withdrawal_requests;
CREATE POLICY p_wd_self  ON withdrawal_requests FOR SELECT USING (user_id = current_user_id() OR is_admin());
CREATE POLICY p_wd_admin ON withdrawal_requests USING (is_admin()) WITH CHECK (is_admin());

-- request: reserve funds out of available into cash_clearing, pending payout
CREATE OR REPLACE FUNCTION request_withdrawal(_user uuid, _amount bigint, _idem text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _avail bigint; _req uuid; _sheba text; _u uuid; _clr uuid;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;
  _avail := wallet_balance(_user, 'available');
  IF _avail < _amount THEN RAISE EXCEPTION 'insufficient balance: need %, have %', _amount, _avail; END IF;
  SELECT sheba INTO _sheba FROM users WHERE id = _user;
  _u   := user_account(_user, 'available');
  _clr := system_account('cash_clearing');
  PERFORM post_transaction('withdrawal', _idem, 'wd_request', _user,
    jsonb_build_array(
      jsonb_build_object('account_id', _u,   'amount', -_amount),
      jsonb_build_object('account_id', _clr, 'amount',  _amount)
    ));
  INSERT INTO withdrawal_requests(user_id, amount, sheba) VALUES (_user, _amount, _sheba) RETURNING id INTO _req;
  INSERT INTO notifications(user_id, title, body) VALUES
    (_user, 'درخواست برداشت ثبت شد', 'درخواست برداشت شما در انتظار تأیید مدیر مالی است.');
  RETURN _req;
END $$;

-- admin decision: approve (funds leave the platform) or reject (return to available)
CREATE OR REPLACE FUNCTION decide_withdrawal(_req uuid, _actor uuid, _approve boolean, _note text DEFAULT NULL)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _r withdrawal_requests%ROWTYPE; _u uuid; _clr uuid;
BEGIN
  SELECT * INTO _r FROM withdrawal_requests WHERE id = _req FOR UPDATE;
  IF NOT FOUND OR _r.status <> 'pending' THEN RAISE EXCEPTION 'request not pending'; END IF;
  _clr := system_account('cash_clearing');
  IF _approve THEN
    -- settle out of clearing to an external-settlement system account
    PERFORM post_transaction('withdrawal', NULL, 'wd_settle', _actor,
      jsonb_build_array(
        jsonb_build_object('account_id', _clr, 'amount', -_r.amount),
        jsonb_build_object('account_id', system_account('bank_settlement'), 'amount', _r.amount)
      ));
    UPDATE withdrawal_requests SET status='approved', decided_at=now(), decided_by=_actor, note=_note WHERE id=_req;
    INSERT INTO notifications(user_id, title, body) VALUES (_r.user_id, 'برداشت تأیید شد', 'مبلغ برداشت شما در حال واریز است.');
  ELSE
    _u := user_account(_r.user_id, 'available');
    PERFORM post_transaction('refund', NULL, 'wd_reject', _actor,
      jsonb_build_array(
        jsonb_build_object('account_id', _clr, 'amount', -_r.amount),
        jsonb_build_object('account_id', _u,   'amount',  _r.amount)
      ));
    UPDATE withdrawal_requests SET status='rejected', decided_at=now(), decided_by=_actor, note=_note WHERE id=_req;
    INSERT INTO notifications(user_id, title, body) VALUES (_r.user_id, 'برداشت رد شد', 'درخواست برداشت رد و مبلغ به کیف پول بازگشت.');
  END IF;
END $$;

-- ---- H: cap subscription pre-purchase at one period ahead ----------
-- Re-create subscription_purchase with the same body + a forward-coverage cap.
CREATE OR REPLACE FUNCTION subscription_purchase(_user uuid, _plan_key text, _idem text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _plan subscription_plans%ROWTYPE; _avail bigint; _sub uuid;
        _u_avail uuid; _rev uuid; _from timestamptz; _maxexp timestamptz;
BEGIN
  SELECT * INTO _plan FROM subscription_plans WHERE key = _plan_key AND active;
  IF NOT FOUND THEN RAISE EXCEPTION 'plan not found or inactive'; END IF;
  IF _plan.price <= 0 THEN RAISE EXCEPTION 'free plan needs no purchase'; END IF;

  -- cap: cannot prepay more than one extra period beyond current active coverage
  SELECT MAX(expires_at) INTO _maxexp FROM subscriptions
   WHERE user_id = _user AND plan_id = _plan.id AND status = 'active' AND expires_at > now();
  IF _maxexp IS NOT NULL AND _maxexp > now() + (_plan.period_days || ' days')::interval THEN
    RAISE EXCEPTION 'already prepaid the next period';
  END IF;

  _avail := wallet_balance(_user, 'available');
  IF _avail < _plan.price THEN RAISE EXCEPTION 'insufficient balance: need %, have %', _plan.price, _avail; END IF;

  _u_avail := user_account(_user, 'available');
  _rev     := system_account('platform_revenue');
  PERFORM post_transaction('subscription_fee', _idem, 'plan_' || _plan.key, _user,
    jsonb_build_array(
      jsonb_build_object('account_id', _u_avail, 'amount', -_plan.price),
      jsonb_build_object('account_id', _rev,     'amount',  _plan.price)
    ));

  SELECT GREATEST(now(), MAX(expires_at)) INTO _from
  FROM subscriptions WHERE user_id = _user AND plan_id = _plan.id AND status = 'active' AND expires_at > now();
  _from := COALESCE(_from, now());

  UPDATE subscriptions SET status = 'cancelled'
  WHERE user_id = _user AND status = 'active' AND plan_id <> _plan.id;

  INSERT INTO subscriptions(user_id, plan_id, status, started_at, expires_at)
  VALUES (_user, _plan.id, 'active', now(), _from + (_plan.period_days || ' days')::interval)
  RETURNING id INTO _sub;

  INSERT INTO notifications(user_id, title, body) VALUES
    (_user, 'اشتراک فعال شد', 'اشتراک «' || _plan.name || '» برای شما فعال شد.');
  RETURN _sub;
END $$;

-- ---- S: ratings after a completed transfer (M02) -------------------
CREATE TABLE IF NOT EXISTS ratings (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id    uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  rater_id   uuid NOT NULL REFERENCES users(id),
  ratee_id   uuid NOT NULL REFERENCES users(id),
  score      smallint NOT NULL CHECK (score BETWEEN 1 AND 5),
  answers    jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (deal_id, rater_id)
);
ALTER TABLE ratings ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_rate_read  ON ratings;
DROP POLICY IF EXISTS p_rate_write ON ratings;
CREATE POLICY p_rate_read  ON ratings FOR SELECT USING (rater_id = current_user_id() OR ratee_id = current_user_id() OR is_admin());
CREATE POLICY p_rate_write ON ratings FOR INSERT WITH CHECK (rater_id = current_user_id());

CREATE OR REPLACE FUNCTION submit_rating(_deal uuid, _rater uuid, _score int, _answers jsonb DEFAULT '{}'::jsonb)
RETURNS void LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _d deals%ROWTYPE; _ratee uuid;
BEGIN
  SELECT * INTO _d FROM deals WHERE id = _deal;
  IF NOT FOUND THEN RAISE EXCEPTION 'deal not found'; END IF;
  IF _rater <> _d.buyer_id AND _rater <> _d.seller_id THEN RAISE EXCEPTION 'not a party to this deal'; END IF;
  -- rate the counterparty (the one who transferred the privilege is the seller)
  _ratee := CASE WHEN _rater = _d.buyer_id THEN _d.seller_id ELSE _d.buyer_id END;
  INSERT INTO ratings(deal_id, rater_id, ratee_id, score, answers)
  VALUES (_deal, _rater, _ratee, _score, COALESCE(_answers,'{}'::jsonb))
  ON CONFLICT (deal_id, rater_id) DO NOTHING;
END $$;

-- ---- D/F: deal evidence (receipt / transfer proof, escrow-off) -----
CREATE TABLE IF NOT EXISTS deal_evidence (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id     uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  uploader_id uuid NOT NULL REFERENCES users(id),
  kind        text NOT NULL,         -- payment_receipt | transfer_proof
  file_url    text NOT NULL,
  note        text,
  created_at  timestamptz NOT NULL DEFAULT now()
);
ALTER TABLE deal_evidence ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_ev_read  ON deal_evidence;
DROP POLICY IF EXISTS p_ev_write ON deal_evidence;
CREATE POLICY p_ev_read ON deal_evidence FOR SELECT USING (
  is_admin() OR deal_id IN (SELECT id FROM deals WHERE buyer_id = current_user_id() OR seller_id = current_user_id()));
CREATE POLICY p_ev_write ON deal_evidence FOR INSERT WITH CHECK (uploader_id = current_user_id());

-- ---- D (collect transfer info at acceptance) -----------------------
ALTER TABLE deals ADD COLUMN IF NOT EXISTS transfer_info jsonb NOT NULL DEFAULT '{}'::jsonb;

-- ---- config defaults (X logo, N market-avg, L visibility, Q timers) -
INSERT INTO config(key, value) VALUES
  ('cms.logo_url',                '""'::jsonb),
  ('cms.site_name',               '"بازار امتیاز وام"'::jsonb),
  ('analysis.show_market_average','true'::jsonb),
  ('analysis.avg_windows',        '["week","month","all"]'::jsonb),
  ('listings.visibility_levels',  '{"guest":["loan_type","bank","rate"],"member":["all"]}'::jsonb),
  ('deal.step_deadline_hours',    '{"escrow_funding":48,"seller_transfer":72,"buyer_confirm":48}'::jsonb),
  ('rating.questions',            '["برخورد مناسب","سرعت انتقال","صحت اطلاعات"]'::jsonb)
ON CONFLICT (key) DO NOTHING;

GRANT EXECUTE ON FUNCTION
  request_withdrawal(uuid, bigint, text),
  decide_withdrawal(uuid, uuid, boolean, text),
  subscription_purchase(uuid, text, text),
  submit_rating(uuid, uuid, int, jsonb)
TO app;
