import "server-only";
import { cache } from "react";
import { withUser, sql } from "@/db";

export interface Membership {
  planKey: string;
  planName: string;
  expiresAt: string;
  entitlements: string[];
}

export const ENTITLEMENT_FA: Record<string, string> = {
  calculator: "ماشین‌حساب پیشرفته",
  pricing_advice: "مشاورهٔ هوشمند قیمت‌گذاری",
  sms_alerts: "هشدار پیامکی",
  auto_match: "پیشنهاد خودکار خرید/فروش",
  history_charts: "نمودار تاریخچهٔ معاملات (TradingView-style)",
};

/** Active membership + its entitlement set for a user (M19); null = free tier. */
export const getMembership = cache(async (userId: string | null): Promise<Membership | null> => {
  if (!userId) return null;
  return withUser(userId, async (tx) => {
    const subs = await tx.execute<{ plan_id: string; key: string; name: string; expires_at: string }>(sql`
      select s.plan_id, p.key, p.name, s.expires_at::text
      from subscriptions s join subscription_plans p on p.id = s.plan_id
      where s.user_id = ${userId} and s.status = 'active' and s.expires_at > now()
      order by s.expires_at desc limit 1`);
    const sub = subs[0];
    if (!sub) return null;
    const ents = await tx.execute<{ entitlement: string }>(
      sql`select entitlement from plan_entitlements where plan_id = ${sub.plan_id}`,
    );
    return {
      planKey: sub.key,
      planName: sub.name,
      expiresAt: sub.expires_at,
      entitlements: (ents as { entitlement: string }[]).map((e) => e.entitlement),
    };
  });
});

export async function hasEntitlement(userId: string | null, ent: string): Promise<boolean> {
  const m = await getMembership(userId);
  return !!m?.entitlements.includes(ent);
}
