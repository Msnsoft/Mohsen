import { Palette } from "lucide-react";
import { THEMES, type ThemeKey } from "@/lib/themes";
import { setThemeAction } from "@/app/actions";

/** 6-color-set picker (M02 FR-M02-10). Server-rendered <details> dropdown — no client JS. */
export function ThemeSwitcher({ current }: { current: ThemeKey | string }) {
  return (
    <details className="group relative">
      <summary
        className="grid h-9 w-9 cursor-pointer list-none place-items-center rounded-lg border border-[var(--color-border)] text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)] [&::-webkit-details-marker]:hidden"
        title="انتخاب تم رنگی"
      >
        <Palette size={16} />
      </summary>
      <form
        action={setThemeAction}
        className="card absolute left-0 top-11 z-40 w-48 space-y-1 p-2 shadow-xl"
      >
        {THEMES.map((t) => (
          <button
            key={t.key}
            type="submit"
            name="theme"
            value={t.key}
            className={`flex w-full items-center gap-2 rounded-lg px-2.5 py-2 text-sm hover:bg-[var(--color-surface-2)] ${
              t.key === current ? "bg-[var(--color-surface-2)] font-semibold" : ""
            }`}
          >
            <span
              className="h-4 w-4 rounded-full border border-[var(--color-border)]"
              style={{ background: `linear-gradient(135deg, ${t.primary} 50%, ${t.accent} 50%)` }}
            />
            {t.label}
            {t.key === current && <span className="mr-auto text-xs text-[var(--color-primary)]">✓</span>}
          </button>
        ))}
      </form>
    </details>
  );
}
