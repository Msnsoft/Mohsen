"use server";
import { revalidatePath } from "next/cache";
import { db, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";

export interface DepositState { ok?: boolean; error?: string }

/** Convert an entered amount (toman, or million-toman when unit=million) to IRR. */
function enteredToIrr(formData: FormData): number {
  const n = Number(String(formData.get("amount") ?? "").replace(/[^\d]/g, ""));
  if (!n || n <= 0) return 0;
  const toman = formData.get("unit") === "million" ? n * 1_000_000 : n;
  return toman * 10;
}

export async function depositAction(_prev: DepositState, formData: FormData): Promise<DepositState> {
  const user = await getCurrentUser();
  if (!user) return { error: "ابتدا وارد شوید" };

  const irr = enteredToIrr(formData);
  if (irr <= 0) return { error: "مبلغ نامعتبر است" };

  try {
    await db.execute(sql`select wallet_deposit(${user.id}, ${irr}, ${"dep_" + crypto.randomUUID()})`);
  } catch {
    return { error: "خطا در ثبت واریز" };
  }
  revalidatePath("/wallet");
  return { ok: true };
}

export interface WithdrawState { ok?: boolean; error?: string }

/** Request a withdrawal (M10): reserves funds and queues for admin approval. */
export async function withdrawAction(_prev: WithdrawState, formData: FormData): Promise<WithdrawState> {
  const user = await getCurrentUser();
  if (!user) return { error: "ابتدا وارد شوید" };

  const irr = enteredToIrr(formData);
  if (irr <= 0) return { error: "مبلغ نامعتبر است" };

  try {
    const { withUser } = await import("@/db");
    await withUser(user.id, (tx) =>
      tx.execute(sql`select request_withdrawal(${user.id}::uuid, ${irr}, ${"wd_" + crypto.randomUUID()})`),
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : "";
    if (msg.includes("insufficient balance")) return { error: "موجودی قابل برداشت کافی نیست" };
    return { error: "خطا در ثبت درخواست برداشت" };
  }
  revalidatePath("/wallet");
  return { ok: true };
}
