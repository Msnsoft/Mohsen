import { notFound } from "next/navigation";
import Link from "next/link";
import { getListingById } from "@/services/marketplace";
import { quoteFees, getUserReputation } from "@/services/deals";
import { startDeal } from "@/app/deals/actions";
import { getCurrentUser } from "@/lib/auth";
import { db, sql } from "@/db";
import { calculateAPR, fairValueAtRate, riskFlags } from "@/lib/finance/apr";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CustomFieldInput, type CustomField } from "@/components/custom-field-input";
import { getListingVisibility, canSee } from "@/lib/visibility";
import { formatToman, formatTomanCompact, formatPercent, toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

export default async function ListingDetail({
  params,
  searchParams,
}: {
  params: Promise<{ id: string }>;
  searchParams: Promise<{ error?: string }>;
}) {
  const { id } = await params;
  const { error } = await searchParams;
  const [l, user] = await Promise.all([getListingById(id), getCurrentUser()]);
  if (!l) notFound();

  // req. D: buyer-facing accept-info fields for this loan type
  const buyerFields = (await db.execute<CustomField>(sql`
    select key, label, field_type, audience, required, options
    from loan_type_fields
    where loan_type_id = ${l.loanTypeId} and active and audience in ('buyer','both')
    order by sort, label`)) as CustomField[];

  // req. S: seller reputation
  const sellerRep = await getUserReputation(l.userId);

  // req. L: field visibility for this viewer level
  const allowed = await getListingVisibility(user ? "member" : "guest");
  const lock = "🔒 برای مشاهده وارد شوید";

  const bankRate = Number(l.rate ?? l.fixedRate ?? 0);
  const months = l.durationMonths ?? 12;
  const apr = calculateAPR({ loanAmount: l.loanValue, askingPrice: l.loanPrice, bankRatePct: bankRate, months });
  const fair = fairValueAtRate(l.loanValue, l.loanPrice, bankRate, bankRate, months);
  const risk = riskFlags(apr, fair, l.loanPrice, months);

  // real fee quote from the commission engine (M09)
  const { buyerFee } = await quoteFees(l.loanTypeId, l.loanPrice);
  const grandTotal = l.loanPrice + buyerFee;
  const insufficient = user ? user.availableBalance < grandTotal : false;

  return (
    <div className="space-y-6">
      <Link href="/marketplace" className="text-sm text-[var(--color-muted)]">→ بازگشت به بازار</Link>

      <div className="grid gap-6 lg:grid-cols-3">
        {/* Summary */}
        <div className="space-y-6 lg:col-span-2">
          <Card>
            <div className="mb-4 flex items-start justify-between">
              <div>
                <h1 className="text-2xl font-bold">{l.loanTypeName}</h1>
                <p className="text-[var(--color-muted)]">{l.bankName} · {l.province ?? "سراسری"}</p>
                <p className="mt-1 text-sm text-[var(--color-muted)]">
                  اعتبار فروشنده:{" "}
                  {sellerRep.avg != null ? (
                    <span className="text-[var(--color-warning)]">★ {toFaDigits(sellerRep.avg)} ({toFaDigits(sellerRep.count)} نظر)</span>
                  ) : (
                    "بدون امتیاز"
                  )}
                </p>
              </div>
              <div className="flex gap-1">
                {l.featured && <Badge tone="warning">ویژه</Badge>}
                {l.splittable && <Badge tone="accent">قابل تفکیک</Badge>}
              </div>
            </div>
            <dl className="grid grid-cols-2 gap-y-3 sm:grid-cols-3">
              <Stat label="ارزش وام" value={canSee(allowed, "value") ? formatTomanCompact(l.loanValue) : lock} />
              <Stat label="قیمت امتیاز" value={canSee(allowed, "price") ? formatToman(l.loanPrice) : lock} accent />
              <Stat label="نرخ سود بانک" value={canSee(allowed, "rate") ? formatPercent(bankRate) : lock} />
              <Stat label="مدت بازپرداخت" value={canSee(allowed, "duration") ? `${toFaDigits(months)} ماه` : lock} />
              <Stat label="قیمت هر میلیون" value={canSee(allowed, "price") ? (l.pricePerMillion ? formatToman(l.pricePerMillion) : "—") : lock} />
            </dl>

            {l.splittable && (
              <div className="mt-4 rounded-xl bg-[var(--color-surface-2)] p-3 text-sm">
                این آگهی قابل تفکیک است: حداقل هر انتقال {l.minChunk ? formatTomanCompact(l.minChunk) : "—"} ·
                حداکثر {l.maxSplits ? toFaDigits(l.maxSplits) : "—"} بخش.
              </div>
            )}
          </Card>

          {/* Finance analysis */}
          <Card>
            <CardTitle>تحلیل مالی</CardTitle>
            <CardMuted>هزینهٔ واقعی تأمین مالی برای خریدار</CardMuted>
            <div className="mt-4 grid grid-cols-2 gap-4 sm:grid-cols-4">
              <Metric label="قسط ماهانه" value={formatToman(apr.monthlyInstallment)} />
              <Metric label="نرخ مؤثر سالانه (APR)" value={formatPercent((apr.realAPR * 100).toFixed(1))} />
              <Metric label="نرخ مؤثر مرکب (EAR)" value={formatPercent((apr.effectiveAPR * 100).toFixed(1))} />
              <Metric label="هزینهٔ کل خریدار" value={formatTomanCompact(apr.totalCostToBuyer)} />
            </div>
            <div className="mt-4 flex flex-wrap items-center gap-2">
              <span className="text-sm text-[var(--color-muted)]">قیمت منصفانه برآوردی:</span>
              <Badge tone={fair.verdict === "above" ? "danger" : fair.verdict === "below" ? "accent" : "muted"}>
                {formatToman(fair.fairPrice)} ({fair.verdict === "above" ? "بالاتر از بازار" : fair.verdict === "below" ? "زیر بازار" : "منصفانه"})
              </Badge>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              {risk.highAPR && <Badge tone="danger">نرخ مؤثر بالا</Badge>}
              {risk.expensivePremium && <Badge tone="warning">پرمیوم گران</Badge>}
              {risk.heavyInstallment && <Badge tone="warning">بار قسط سنگین</Badge>}
              {!risk.highAPR && !risk.expensivePremium && !risk.heavyInstallment && <Badge tone="accent">بدون هشدار ریسک</Badge>}
            </div>
          </Card>
        </div>

        {/* Purchase box */}
        <div className="space-y-4">
          <Card className="lg:sticky lg:top-20">
            <CardTitle>شروع معامله</CardTitle>
            <dl className="mt-3 space-y-2 text-sm">
              <Row label="قیمت امتیاز" value={formatToman(l.loanPrice)} />
              <Row label="کارمزد خریدار (تخمینی)" value={formatToman(buyerFee)} />
              <div className="border-t border-[var(--color-border)] pt-2">
                <Row label="مبلغ قابل پرداخت" value={formatToman(grandTotal)} strong />
              </div>
            </dl>
            <div className="mt-4">
              {!user ? (
                <Link href="/login"><Button className="w-full">برای خرید وارد شوید</Button></Link>
              ) : insufficient ? (
                <div className="space-y-2">
                  <Link href="/wallet"><Button className="w-full" variant="accent">شارژ کیف پول</Button></Link>
                  <p className="text-xs text-[var(--color-warning)]">موجودی کافی نیست؛ برای شروع معامله ابتدا کیف پول را شارژ کنید.</p>
                </div>
              ) : (
                <form action={startDeal} className="space-y-3">
                  <input type="hidden" name="listing_id" value={l.id} />
                  {buyerFields.length > 0 && (
                    <div className="space-y-3 rounded-xl border border-[var(--color-border)] p-3">
                      <p className="text-xs font-semibold text-[var(--color-muted)]">اطلاعات لازم برای انتقال</p>
                      {buyerFields.map((f) => (
                        <CustomFieldInput key={f.key} field={f} prefix="info" />
                      ))}
                    </div>
                  )}
                  {user.isSpecial && (
                    <label className="space-y-1.5 text-sm">
                      <span className="text-[var(--color-muted)]">به نمایندگی از (اختیاری — کاربر ویژه)</span>
                      <input name="on_behalf_of" placeholder="نام/کد ملی ذی‌نفع"
                             className="w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]" />
                    </label>
                  )}
                  <Button className="w-full" type="submit">شروع معامله و پرداخت امانی</Button>
                </form>
              )}
              {error === "special" && (
                <p className="mt-2 text-xs text-[var(--color-danger)]">فقط کاربران ویژه می‌توانند به نمایندگی از دیگران معامله کنند.</p>
              )}
              {error === "1" && (
                <p className="mt-2 text-xs text-[var(--color-danger)]">شروع معامله ممکن نشد. لطفاً دوباره تلاش کنید.</p>
              )}
              <p className="mt-2 text-xs text-[var(--color-muted)]">
                مبلغ امتیاز نزد امانت (Escrow) نگهداری می‌شود و پس از تأیید دریافت توسط شما به فروشنده پرداخت می‌گردد؛ کارمزد از کیف پول.
              </p>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-sm text-[var(--color-muted)]">{label}</dt>
      <dd className={`mt-0.5 font-semibold ${accent ? "text-[var(--color-accent)]" : ""}`}>{value}</dd>
    </div>
  );
}
function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-[var(--color-surface-2)] p-3">
      <p className="text-xs text-[var(--color-muted)]">{label}</p>
      <p className="mt-1 font-bold">{value}</p>
    </div>
  );
}
function Row({ label, value, strong }: { label: string; value: string; strong?: boolean }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-[var(--color-muted)]">{label}</dt>
      <dd className={strong ? "font-bold text-[var(--color-accent)]" : ""}>{value}</dd>
    </div>
  );
}
