import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toFaDigits } from "@/lib/persian";
import { TICKET_STATUS_FA, ticketStatusTone } from "@/lib/ticket-status";
import { NewTicketForm } from "./new-ticket-form";

export const dynamic = "force-dynamic";

export default async function MyTicketsPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const tickets = await withUser(user.id, (tx) =>
    tx.execute<{ id: string; subject: string; status: string; created_at: string; msg_count: string }>(sql`
      select t.id, t.subject, t.status, t.created_at::text,
             (select count(*) from ticket_messages m where m.ticket_id = t.id and not m.is_internal)::text as msg_count
      from tickets t where t.user_id = ${user.id}
      order by t.created_at desc`),
  );

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">پشتیبانی و تیکت‌ها</h1>

      <Card className="space-y-3">
        <CardTitle>ثبت تیکت جدید</CardTitle>
        <NewTicketForm />
      </Card>

      {tickets.length === 0 ? (
        <Card><CardMuted>هنوز تیکتی ثبت نکرده‌اید.</CardMuted></Card>
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => (
            <Link key={t.id} href={`/panel/tickets/${t.id}`} className="block">
              <Card className="flex flex-wrap items-center justify-between gap-3 transition-colors hover:border-[var(--color-primary)]">
                <div className="space-y-1">
                  <p className="font-semibold">{t.subject}</p>
                  <p className="text-xs text-[var(--color-muted)]">
                    {toFaDigits(t.msg_count)} پیام · <span dir="ltr">{t.created_at.slice(0, 16)}</span>
                  </p>
                </div>
                <Badge tone={ticketStatusTone(t.status)}>{TICKET_STATUS_FA[t.status] ?? t.status}</Badge>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
