import "server-only";
import { cache } from "react";
import { redirect } from "next/navigation";
import { withUser, sql } from "@/db";
import { getSessionUserId } from "./session";

export interface CurrentUser {
  id: string;
  mobile: string;
  displayName: string | null;
  verificationLevel: number;
  theme: string;
  roles: string[];
  isAdmin: boolean;
  availableBalance: number;
  unreadMessages: number;
  status: string;
  profileCompleted: boolean;
  prefersMillion: boolean;
  isSpecial: boolean;
}

/** Server-only: resolve the logged-in user (or null). Cached per request. */
export const getCurrentUser = cache(async (): Promise<CurrentUser | null> => {
  const userId = await getSessionUserId();
  if (!userId) return null;

  // Run identity reads inside the user's RLS context so policies allow own rows.
  return withUser(userId, async (tx) => {
    const userRows = await tx.execute<{
      id: string; mobile: string; display_name: string | null; verification_level: number; theme: string;
      status: string; profile_completed: boolean; prefers_million: boolean; is_special: boolean;
    }>(sql`select id, mobile, display_name, verification_level, theme, status, profile_completed, prefers_million, is_special from users where id = ${userId}`);
    const u = userRows[0] as { id: string; mobile: string; display_name: string | null; verification_level: number; theme: string; status: string; profile_completed: boolean; prefers_million: boolean; is_special: boolean } | undefined;
    if (!u) return null;

    const roleRows = await tx.execute<{ role: string }>(sql`select role from user_roles where user_id = ${userId}`);
    const roles = (roleRows as { role: string }[]).map((r) => r.role);

    const balRows = await tx.execute<{ bal: number }>(sql`select wallet_balance(${userId}, 'available') as bal`);
    const availableBalance = Number((balRows[0] as { bal: number } | undefined)?.bal ?? 0);

    const unreadRows = await tx.execute<{ n: string }>(
      sql`select count(*)::text as n from notifications where user_id = ${userId} and not read`,
    );
    const unreadMessages = Number((unreadRows[0] as { n: string } | undefined)?.n ?? 0);

    return {
      id: u.id,
      mobile: u.mobile,
      displayName: u.display_name,
      verificationLevel: u.verification_level,
      theme: u.theme,
      roles,
      isAdmin: roles.some((r) => r !== "user" && r !== "customer"),
      availableBalance,
      unreadMessages,
      status: u.status,
      profileCompleted: u.profile_completed,
      prefersMillion: u.prefers_million,
      isSpecial: u.is_special,
    };
  });
});

/**
 * Gate for member areas (panel, wallet, deals, posting). Redirects guests to
 * /login and not-yet-activated accounts to /onboarding (req. A). Returns the
 * active user otherwise.
 */
export async function requireActiveUser(): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (user.status !== "active") redirect("/onboarding");
  return user;
}
