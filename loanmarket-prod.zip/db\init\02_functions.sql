-- =====================================================================
-- Money & identity functions. SECURITY DEFINER (owned by bootstrap superuser)
-- so they enforce invariants centrally and may post to the ledger past RLS.
-- =====================================================================

-- ---- Ledger balanced invariant: sum of entries per transaction = 0 ----
CREATE OR REPLACE FUNCTION ledger_balanced_check() RETURNS trigger
LANGUAGE plpgsql AS $$
DECLARE s bigint;
BEGIN
  SELECT COALESCE(SUM(amount), 0) INTO s FROM ledger_entries WHERE transaction_id = NEW.transaction_id;
  IF s <> 0 THEN
    RAISE EXCEPTION 'unbalanced ledger transaction %: sum=%', NEW.transaction_id, s;
  END IF;
  RETURN NULL;
END $$;

CREATE CONSTRAINT TRIGGER trg_ledger_balanced
AFTER INSERT ON ledger_entries
DEFERRABLE INITIALLY DEFERRED
FOR EACH ROW EXECUTE FUNCTION ledger_balanced_check();

-- ---- Account helpers --------------------------------------------------
CREATE OR REPLACE FUNCTION ensure_wallet(_user uuid) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _wid uuid;
BEGIN
  SELECT id INTO _wid FROM wallets WHERE user_id = _user;
  IF _wid IS NULL THEN
    INSERT INTO wallets(user_id) VALUES (_user) RETURNING id INTO _wid;
  END IF;
  INSERT INTO ledger_accounts(wallet_id, kind) VALUES (_wid, 'available')
    ON CONFLICT (wallet_id, kind) DO NOTHING;
  INSERT INTO ledger_accounts(wallet_id, kind) VALUES (_wid, 'held')
    ON CONFLICT (wallet_id, kind) DO NOTHING;
  RETURN _wid;
END $$;

CREATE OR REPLACE FUNCTION user_account(_user uuid, _kind text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _aid uuid; _wid uuid;
BEGIN
  _wid := ensure_wallet(_user);
  SELECT id INTO _aid FROM ledger_accounts WHERE wallet_id = _wid AND kind = _kind;
  RETURN _aid;
END $$;

CREATE OR REPLACE FUNCTION system_account(_key text) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _aid uuid;
BEGIN
  SELECT id INTO _aid FROM ledger_accounts WHERE system_key = _key;
  IF _aid IS NULL THEN
    INSERT INTO ledger_accounts(system_key, kind) VALUES (_key, 'system') RETURNING id INTO _aid;
  END IF;
  RETURN _aid;
END $$;

-- ---- Core poster: entries = jsonb array of {account_id, amount} -------
CREATE OR REPLACE FUNCTION post_transaction(
  _type text, _idempotency_key text, _reference text, _created_by uuid, _entries jsonb
) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _txn uuid; _e jsonb; _sum bigint := 0;
BEGIN
  -- idempotency: return the existing transaction if the key was already used
  IF _idempotency_key IS NOT NULL THEN
    SELECT id INTO _txn FROM ledger_transactions WHERE idempotency_key = _idempotency_key;
    IF _txn IS NOT NULL THEN RETURN _txn; END IF;
  END IF;

  FOR _e IN SELECT * FROM jsonb_array_elements(_entries) LOOP
    _sum := _sum + (_e->>'amount')::bigint;
  END LOOP;
  IF _sum <> 0 THEN RAISE EXCEPTION 'entries do not balance (sum=%)', _sum; END IF;

  INSERT INTO ledger_transactions(type, idempotency_key, reference, created_by)
  VALUES (_type, _idempotency_key, _reference, _created_by) RETURNING id INTO _txn;

  FOR _e IN SELECT * FROM jsonb_array_elements(_entries) LOOP
    INSERT INTO ledger_entries(transaction_id, account_id, amount)
    VALUES (_txn, (_e->>'account_id')::uuid, (_e->>'amount')::bigint);
  END LOOP;

  RETURN _txn;
END $$;

-- ---- Wallet available balance (derived from entries) ------------------
CREATE OR REPLACE FUNCTION wallet_balance(_user uuid, _kind text DEFAULT 'available') RETURNS bigint
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT COALESCE(SUM(le.amount), 0)
  FROM ledger_entries le
  JOIN ledger_accounts la ON la.id = le.account_id
  JOIN wallets w ON w.id = la.wallet_id
  WHERE w.user_id = _user AND la.kind = _kind
$$;

-- ---- Deposit (top-up): credit available, debit cash_clearing ----------
CREATE OR REPLACE FUNCTION wallet_deposit(_user uuid, _amount bigint, _idem text DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _avail uuid; _cash uuid;
BEGIN
  IF _amount <= 0 THEN RAISE EXCEPTION 'amount must be positive'; END IF;
  _avail := user_account(_user, 'available');
  _cash  := system_account('cash_clearing');
  RETURN post_transaction(
    'deposit', _idem, NULL, _user,
    jsonb_build_array(
      jsonb_build_object('account_id', _avail, 'amount',  _amount),
      jsonb_build_object('account_id', _cash,  'amount', -_amount)
    )
  );
END $$;

-- =====================================================================
-- Identity: resolve-or-create user by mobile (used by OTP verify)
-- =====================================================================
CREATE OR REPLACE FUNCTION get_or_create_user(_mobile text, _super_email text DEFAULT NULL) RETURNS uuid
LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid;
BEGIN
  SELECT id INTO _uid FROM users WHERE mobile = _mobile;
  IF _uid IS NULL THEN
    INSERT INTO users(mobile) VALUES (_mobile) RETURNING id INTO _uid;
    INSERT INTO user_roles(user_id, role) VALUES (_uid, 'user') ON CONFLICT DO NOTHING;
    PERFORM ensure_wallet(_uid);
  END IF;
  RETURN _uid;
END $$;

-- =====================================================================
-- Lock down append-only ledger for the app role; expose functions.
-- =====================================================================
REVOKE UPDATE, DELETE ON ledger_entries, ledger_transactions FROM app;

GRANT EXECUTE ON FUNCTION
  current_user_id(), is_admin(),
  ensure_wallet(uuid), user_account(uuid, text), system_account(text),
  post_transaction(text, text, text, uuid, jsonb),
  wallet_balance(uuid, text), wallet_deposit(uuid, bigint, text),
  get_or_create_user(text, text)
TO app;
