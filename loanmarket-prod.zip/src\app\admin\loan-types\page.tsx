import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { requireSectionPage } from "../guard";
import { saveLoanTypeAction, saveLoanTypeFieldAction, deleteLoanTypeFieldAction } from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

type LoanTypeRow = {
  id: string; name: string; bank_name: string | null; fixed_rate: string | null;
  rate_editable: boolean; default_duration_months: number | null;
  min_price_per_million: string | null; max_price_per_million: string | null; active: boolean;
};

type FieldRow = {
  id: string; loan_type_id: string; key: string; label: string; field_type: string;
  audience: string; required: boolean; active: boolean; sort: number; options: string[];
};

const AUDIENCE_FA: Record<string, string> = { buyer: "خریدار", seller: "فروشنده", both: "هر دو" };
const FTYPE_FA: Record<string, string> = { text: "متن", number: "عدد", select: "انتخابی", bool: "بله/خیر" };

export default async function AdminLoanTypesPage() {
  const admin = await requireSectionPage("loan_types");
  const [types, fields] = await Promise.all([
    withUser(admin.id, (tx) =>
      tx.execute<LoanTypeRow>(sql`
        select id, name, bank_name, fixed_rate::text, rate_editable, default_duration_months,
               min_price_per_million::text, max_price_per_million::text, active
        from loan_types order by name`),
    ) as Promise<LoanTypeRow[]>,
    withUser(admin.id, (tx) =>
      tx.execute<FieldRow>(sql`
        select id, loan_type_id, key, label, field_type, audience, required, active, sort, options
        from loan_type_fields order by sort, label`),
    ) as Promise<FieldRow[]>,
  ]);
  const fieldsByType = new Map<string, FieldRow[]>();
  for (const f of fields) (fieldsByType.get(f.loan_type_id) ?? fieldsByType.set(f.loan_type_id, []).get(f.loan_type_id)!).push(f);

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">انواع وام</h1>
      <CardMuted>
        مبالغ «هر میلیون» به تومان وارد می‌شوند. نرخ ثابت را خالی بگذارید تا کاربر نرخ را وارد کند
        (در این حالت «نرخ قابل ویرایش» را فعال کنید). برای هر نوع وام می‌توانید «فیلدهای تکمیلی» جدا برای فروشنده و خریدار تعریف کنید.
      </CardMuted>

      {types.map((t) => (
        <Card key={t.id}>
          <LoanTypeForm t={t} />
          <LoanTypeFields typeId={t.id} fields={fieldsByType.get(t.id) ?? []} />
        </Card>
      ))}

      <Card className="border-dashed">
        <CardTitle className="mb-3">+ نوع وام جدید</CardTitle>
        <LoanTypeForm />
      </Card>
    </div>
  );
}

function LoanTypeForm({ t }: { t?: LoanTypeRow }) {
  return (
    <form action={saveLoanTypeAction} className="grid items-end gap-3 sm:grid-cols-2 lg:grid-cols-4">
      {t && <input type="hidden" name="id" value={t.id} />}
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        نام
        <input name="name" defaultValue={t?.name ?? ""} className={inputCls} required />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        بانک
        <input name="bank_name" defaultValue={t?.bank_name ?? ""} className={inputCls} />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        نرخ ثابت (٪)
        <input name="fixed_rate" defaultValue={t?.fixed_rate ?? ""} dir="ltr" className={inputCls} />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        مدت پیش‌فرض (ماه)
        <input name="default_duration_months" defaultValue={t?.default_duration_months ?? ""} dir="ltr" className={inputCls} />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        حداقل هر میلیون (تومان)
        <input
          name="min_price_per_million" dir="ltr" className={inputCls}
          defaultValue={t?.min_price_per_million ? Number(t.min_price_per_million) / 10 : ""}
        />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        حداکثر هر میلیون (تومان)
        <input
          name="max_price_per_million" dir="ltr" className={inputCls}
          defaultValue={t?.max_price_per_million ? Number(t.max_price_per_million) / 10 : ""}
        />
      </label>
      <div className="flex items-center gap-4 text-sm">
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="rate_editable" defaultChecked={t?.rate_editable ?? true} />
          نرخ قابل ویرایش
        </label>
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="active" defaultChecked={t?.active ?? true} />
          فعال
        </label>
      </div>
      <Button size="sm" type="submit">{t ? "ذخیره" : "ایجاد"}</Button>
    </form>
  );
}

function LoanTypeFields({ typeId, fields }: { typeId: string; fields: FieldRow[] }) {
  return (
    <div className="mt-5 border-t border-[var(--color-border)] pt-4">
      <CardTitle className="mb-3 text-base">فیلدهای تکمیلی</CardTitle>
      {fields.length === 0 ? (
        <CardMuted className="mb-3">فیلد تکمیلی‌ای تعریف نشده است.</CardMuted>
      ) : (
        <ul className="mb-4 space-y-2">
          {fields.map((f) => (
            <li key={f.id} className="flex flex-wrap items-center gap-2 rounded-lg bg-[var(--color-surface-2)] px-3 py-2 text-sm">
              <span className="font-medium">{f.label}</span>
              <span className="text-xs text-[var(--color-muted)]" dir="ltr">({f.key})</span>
              <Badge tone="default">{AUDIENCE_FA[f.audience] ?? f.audience}</Badge>
              <Badge tone="muted">{FTYPE_FA[f.field_type] ?? f.field_type}</Badge>
              {f.required && <Badge tone="warning">الزامی</Badge>}
              {!f.active && <Badge tone="muted">غیرفعال</Badge>}
              <details className="ms-auto">
                <summary className="cursor-pointer text-xs text-[var(--color-primary)]">ویرایش</summary>
                <FieldForm typeId={typeId} f={f} />
              </details>
              <form action={deleteLoanTypeFieldAction}>
                <input type="hidden" name="id" value={f.id} />
                <Button size="sm" variant="outline" type="submit">حذف</Button>
              </form>
            </li>
          ))}
        </ul>
      )}
      <details>
        <summary className="cursor-pointer text-sm text-[var(--color-primary)]">+ افزودن فیلد تکمیلی</summary>
        <FieldForm typeId={typeId} />
      </details>
    </div>
  );
}

function FieldForm({ typeId, f }: { typeId: string; f?: FieldRow }) {
  return (
    <form action={saveLoanTypeFieldAction} className="mt-3 grid items-end gap-2 sm:grid-cols-2 lg:grid-cols-4">
      <input type="hidden" name="loan_type_id" value={typeId} />
      {f && <input type="hidden" name="id" value={f.id} />}
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        عنوان نمایشی
        <input name="label" defaultValue={f?.label ?? ""} className={inputCls} required />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        کلید (انگلیسی)
        <input name="key" defaultValue={f?.key ?? ""} dir="ltr" className={inputCls} required />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        مخاطب
        <select name="audience" defaultValue={f?.audience ?? "seller"} className={inputCls}>
          <option value="seller">فروشنده</option>
          <option value="buyer">خریدار</option>
          <option value="both">هر دو</option>
        </select>
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        نوع
        <select name="field_type" defaultValue={f?.field_type ?? "text"} className={inputCls}>
          <option value="text">متن</option>
          <option value="number">عدد</option>
          <option value="select">انتخابی</option>
          <option value="bool">بله/خیر</option>
        </select>
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)] lg:col-span-2">
        گزینه‌ها (برای نوع انتخابی؛ با کاما یا خط جدا کنید)
        <input name="options" defaultValue={f?.options?.join("، ") ?? ""} className={inputCls} />
      </label>
      <label className="space-y-1 text-xs text-[var(--color-muted)]">
        ترتیب
        <input name="sort" type="number" defaultValue={f?.sort ?? 0} dir="ltr" className={inputCls} />
      </label>
      <div className="flex items-center gap-3 text-sm">
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="required" defaultChecked={f?.required ?? false} /> الزامی
        </label>
        <label className="flex items-center gap-1.5">
          <input type="checkbox" name="active" defaultChecked={f?.active ?? true} /> فعال
        </label>
      </div>
      <Button size="sm" type="submit">{f ? "ذخیره فیلد" : "افزودن"}</Button>
    </form>
  );
}
