import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { visibleSections, ROLE_FA } from "@/lib/rbac";
import { Badge } from "@/components/ui/badge";

export const dynamic = "force-dynamic";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.isAdmin) redirect("/");
  const sections = visibleSections(user.roles);

  return (
    <div className="grid gap-6 md:grid-cols-[15rem_1fr]">
      <aside className="card h-fit space-y-3 p-3 md:sticky md:top-20">
        <div className="flex flex-wrap gap-1 px-1">
          {user.roles.filter((r) => r !== "user").map((r) => (
            <Badge key={r} tone="accent">{ROLE_FA[r] ?? r}</Badge>
          ))}
        </div>
        <nav className="flex gap-1 overflow-x-auto md:flex-col">
          {sections.map((s) => (
            <Link
              key={s.key}
              href={s.href}
              className="shrink-0 rounded-lg px-3 py-2.5 text-sm text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]"
            >
              {s.label}
            </Link>
          ))}
        </nav>
      </aside>
      <div className="min-w-0 space-y-6">{children}</div>
    </div>
  );
}
