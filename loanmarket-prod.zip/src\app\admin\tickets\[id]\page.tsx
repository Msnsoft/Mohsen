import { notFound } from "next/navigation";
import { withUser, sql } from "@/db";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toFaDigits } from "@/lib/persian";
import { TICKET_STATUS_FA, TICKET_PRIORITY_FA, ticketStatusTone } from "@/lib/ticket-status";
import { requireSectionPage } from "../../guard";
import { adminTicketReplyAction, adminTicketStatusAction, adminTicketAssignAction } from "../../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export default async function AdminTicketThreadPage({ params }: { params: Promise<{ id: string }> }) {
  const admin = await requireSectionPage("tickets");
  const { id } = await params;

  const data = await withUser(admin.id, async (tx) => {
    const tickets = await tx.execute<{
      id: string; subject: string; status: string; priority: string; created_at: string;
      owner_name: string | null; owner_mobile: string; assignee_id: string | null; assignee_name: string | null;
    }>(sql`
      select t.id, t.subject, t.status, t.priority, t.created_at::text,
             u.display_name as owner_name, u.mobile as owner_mobile,
             t.assignee_id, a.display_name as assignee_name
      from tickets t join users u on u.id = t.user_id
      left join users a on a.id = t.assignee_id
      where t.id = ${id}`);
    const ticket = tickets[0];
    if (!ticket) return null;
    const messages = await tx.execute<{
      id: string; body: string; author_id: string; author_name: string | null;
      is_internal: boolean; created_at: string;
    }>(sql`
      select m.id, m.body, m.author_id, u.display_name as author_name, m.is_internal, m.created_at::text
      from ticket_messages m join users u on u.id = m.author_id
      where m.ticket_id = ${id} order by m.created_at`);
    return { ticket, messages };
  });
  if (!data) notFound();
  const { ticket, messages } = data;

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-xl font-bold">{ticket.subject}</h1>
          <p className="text-xs text-[var(--color-muted)]">
            {ticket.owner_name ?? "—"} <span dir="ltr">{toFaDigits(ticket.owner_mobile)}</span> ·
            اولویت {TICKET_PRIORITY_FA[ticket.priority]} · مسئول: {ticket.assignee_name ?? "—"}
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Badge tone={ticketStatusTone(ticket.status)}>{TICKET_STATUS_FA[ticket.status] ?? ticket.status}</Badge>
          {!ticket.assignee_id && (
            <form action={adminTicketAssignAction}>
              <input type="hidden" name="ticket_id" value={ticket.id} />
              <Button size="sm" variant="outline" type="submit">به من واگذار شود</Button>
            </form>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {messages.map((m) => (
          <Card
            key={m.id}
            className={m.is_internal ? "border-dashed border-[var(--color-warning)]" : ""}
          >
            <div className="mb-1 flex items-center justify-between text-xs text-[var(--color-muted)]">
              <span className="flex items-center gap-2">
                {m.author_name ?? "—"}
                {m.is_internal && <Badge tone="warning">یادداشت داخلی</Badge>}
              </span>
              <span dir="ltr">{m.created_at.slice(0, 16)}</span>
            </div>
            <p className="whitespace-pre-wrap text-sm">{m.body}</p>
          </Card>
        ))}
      </div>

      <Card className="space-y-3">
        <form action={adminTicketReplyAction} className="space-y-3">
          <input type="hidden" name="ticket_id" value={ticket.id} />
          <textarea name="body" rows={3} placeholder="پاسخ یا یادداشت…" className={inputCls} required />
          <div className="flex flex-wrap items-center gap-4">
            <label className="flex items-center gap-1.5 text-sm">
              <input type="checkbox" name="is_internal" />
              یادداشت داخلی (کاربر نمی‌بیند)
            </label>
            <Button type="submit" size="sm">ارسال</Button>
          </div>
        </form>
        <form action={adminTicketStatusAction} className="flex flex-wrap items-center gap-2 border-t border-[var(--color-border)] pt-3">
          <input type="hidden" name="ticket_id" value={ticket.id} />
          <span className="text-xs text-[var(--color-muted)]">تغییر وضعیت:</span>
          {Object.entries(TICKET_STATUS_FA).map(([k, label]) => (
            <Button
              key={k} type="submit" name="status" value={k} size="sm"
              variant={ticket.status === k ? "primary" : "ghost"}
            >
              {label}
            </Button>
          ))}
        </form>
      </Card>
    </div>
  );
}
