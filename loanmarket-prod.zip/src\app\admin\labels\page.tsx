import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireSectionPage } from "../guard";
import { saveLabelRuleAction, toggleLabelRuleAction, deleteLabelRuleAction } from "../actions";
import { toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

const FIELD_FA: Record<string, string> = {
  rate: "نرخ سود (٪)", price_per_million: "قیمت هر میلیون (ریال)",
  duration_months: "مدت (ماه)", loan_value: "ارزش وام (ریال)",
};

export default async function AdminLabelsPage() {
  const admin = await requireSectionPage("labels");
  const rules = await withUser(admin.id, (tx) =>
    tx.execute<{ key: string; label: string; tone: string; field: string; op: string; threshold: string; active: boolean }>(
      sql`select key, label, tone, field, op, threshold::text, active from label_rules order by sort, label`),
  ) as { key: string; label: string; tone: string; field: string; op: string; threshold: string; active: boolean }[];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">برچسب‌های آگهی</h1>
      <CardMuted>تعریف کنید هر برچسب (مثل «سود مؤثر بالا») در چه شرایطی روی آگهی‌ها فعال شود.</CardMuted>

      <Card>
        <CardTitle>برچسب‌های فعلی</CardTitle>
        {rules.length === 0 ? (
          <CardMuted>هنوز برچسبی تعریف نشده است.</CardMuted>
        ) : (
          <table className="mt-3 w-full text-sm">
            <thead className="text-[var(--color-muted)]">
              <tr className="border-b border-[var(--color-border)]">
                <th className="py-2 text-start">برچسب</th><th className="py-2 text-start">شرط</th>
                <th className="py-2 text-start">وضعیت</th><th className="py-2 text-start">عملیات</th>
              </tr>
            </thead>
            <tbody>
              {rules.map((r) => (
                <tr key={r.key} className="border-b border-[var(--color-border)]/50">
                  <td className="py-2"><Badge tone={r.tone as "warning"}>{r.label}</Badge></td>
                  <td className="py-2 text-[var(--color-muted)]">{FIELD_FA[r.field] ?? r.field} {r.op} {toFaDigits(r.threshold)}</td>
                  <td className="py-2">{r.active ? <Badge tone="accent">فعال</Badge> : <Badge tone="muted">غیرفعال</Badge>}</td>
                  <td className="py-2">
                    <div className="flex gap-2">
                      <form action={toggleLabelRuleAction}><input type="hidden" name="key" value={r.key} />
                        <Button size="sm" variant="ghost" type="submit">{r.active ? "غیرفعال" : "فعال"}</Button></form>
                      <form action={deleteLabelRuleAction}><input type="hidden" name="key" value={r.key} />
                        <Button size="sm" variant="ghost" type="submit">حذف</Button></form>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </Card>

      <Card>
        <CardTitle>افزودن / ویرایش برچسب</CardTitle>
        <form action={saveLabelRuleAction} className="mt-3 grid items-end gap-3 sm:grid-cols-2 lg:grid-cols-6">
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">کلید (انگلیسی)</span>
            <input name="key" dir="ltr" placeholder="high_rate" className={inputCls} required /></label>
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">عنوان برچسب</span>
            <input name="label" placeholder="سود مؤثر بالا" className={inputCls} required /></label>
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">رنگ</span>
            <select name="tone" className={inputCls} defaultValue="warning">
              <option value="danger">قرمز</option><option value="warning">نارنجی</option>
              <option value="accent">سبز</option><option value="default">آبی</option><option value="muted">خاکستری</option>
            </select></label>
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">فیلد</span>
            <select name="field" className={inputCls} defaultValue="rate">
              {Object.entries(FIELD_FA).map(([k, v]) => <option key={k} value={k}>{v}</option>)}
            </select></label>
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">عملگر</span>
            <select name="op" className={inputCls} defaultValue=">=">
              <option value=">=">≥</option><option value="<=">≤</option><option value=">">&gt;</option><option value="<">&lt;</option>
            </select></label>
          <label className="space-y-1 text-xs"><span className="text-[var(--color-muted)]">آستانه</span>
            <input name="threshold" dir="ltr" inputMode="decimal" className={inputCls} required /></label>
          <div className="sm:col-span-2 lg:col-span-6"><Button type="submit">ذخیرهٔ برچسب</Button></div>
        </form>
      </Card>
    </div>
  );
}
