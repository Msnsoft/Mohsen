import Link from "next/link";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatTomanCompact, formatToman, formatPercent, toFaDigits } from "@/lib/persian";
import { POST_TYPE_SHORT_FA } from "@/lib/post-type";
import type { LabelTone } from "@/lib/labels";
import { canSee, type Allowed } from "@/lib/visibility";
import type { Listing } from "@/services/marketplace";

const LOCKED = <span className="text-end text-xs text-[var(--color-muted)]">🔒 ورود</span>;

export function ListingCard({ l, labels = [], allowed = "all" }: { l: Listing; labels?: { label: string; tone: LabelTone }[]; allowed?: Allowed }) {
  return (
    <Link href={`/marketplace/${l.id}`}>
      <Card className="h-full transition-colors hover:border-[var(--color-primary)]">
        <div className="mb-3 flex items-start justify-between gap-2">
          <div>
            <h3 className="font-semibold">{l.loanTypeName}</h3>
            <p className="text-sm text-[var(--color-muted)]">{l.bankName}</p>
          </div>
          <div className="flex flex-col items-end gap-1">
            <Badge tone={l.type === "buy" ? "default" : "accent"}>{POST_TYPE_SHORT_FA[l.type] ?? l.type}</Badge>
            {l.featured && <Badge tone="warning">ویژه</Badge>}
            {l.splittable && <Badge tone="accent">قابل تفکیک</Badge>}
          </div>
        </div>

        {labels.length > 0 && (
          <div className="mb-3 flex flex-wrap gap-1">
            {labels.map((b) => <Badge key={b.label} tone={b.tone}>{b.label}</Badge>)}
          </div>
        )}

        <dl className="grid grid-cols-2 gap-y-2 text-sm">
          <dt className="text-[var(--color-muted)]">ارزش وام</dt>
          <dd className="text-end font-medium">{canSee(allowed, "value") ? formatTomanCompact(l.loanValue) : LOCKED}</dd>
          <dt className="text-[var(--color-muted)]">قیمت امتیاز</dt>
          <dd className="text-end font-medium text-[var(--color-accent)]">{canSee(allowed, "price") ? formatToman(l.loanPrice) : LOCKED}</dd>
          <dt className="text-[var(--color-muted)]">نرخ سود</dt>
          <dd className="text-end">{canSee(allowed, "rate") ? formatPercent(l.rate ?? l.fixedRate) : LOCKED}</dd>
          <dt className="text-[var(--color-muted)]">مدت</dt>
          <dd className="text-end">{canSee(allowed, "duration") ? (l.durationMonths ? `${toFaDigits(l.durationMonths)} ماه` : "—") : LOCKED}</dd>
        </dl>

        <div className="mt-3 flex items-center justify-between border-t border-[var(--color-border)] pt-3 text-xs text-[var(--color-muted)]">
          <span>{l.province ?? "سراسری"}</span>
          <span>مشاهده جزئیات ←</span>
        </div>
      </Card>
    </Link>
  );
}
