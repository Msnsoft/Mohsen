import Link from "next/link";
import { notFound } from "next/navigation";
import { getDealTimeline } from "@/services/deals";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { DealTimeline } from "@/components/deal-timeline";
import { EvidenceList } from "@/components/deal-evidence";
import { formatToman, formatTomanCompact, formatDateTimeFa, toFaDigits } from "@/lib/persian";
import { DEAL_STATE_FA, dealStateTone } from "@/app/deals/state";
import { requireSectionPage } from "../../guard";

export const dynamic = "force-dynamic";

const TX_TYPE_FA: Record<string, string> = {
  escrow_fund: "واریز امانی",
  escrow_release: "آزادسازی امانی",
  escrow_refund: "بازگشت امانی",
};

export default async function AdminDealDetail({ params }: { params: Promise<{ id: string }> }) {
  const admin = await requireSectionPage("deals");
  const { id } = await params;
  const t = await getDealTimeline(admin.id, id);
  if (!t) notFound();

  const infoEntries = Object.entries(t.transfer_info ?? {});

  return (
    <div className="space-y-4">
      <Link href="/admin/deals" className="text-sm text-[var(--color-muted)]">→ بازگشت به معاملات</Link>

      <Card>
        <div className="mb-4 flex flex-wrap items-start justify-between gap-3">
          <div>
            <h1 className="text-2xl font-bold">{t.loan_type_name}</h1>
            <p className="text-[var(--color-muted)]">{t.bank_name ?? "—"}</p>
            <p className="mt-1 text-xs text-[var(--color-muted)]" dir="ltr">شناسهٔ معامله: {toFaDigits(t.id)}</p>
          </div>
          <Badge tone={dealStateTone(t.state)}>{DEAL_STATE_FA[t.state] ?? t.state}</Badge>
        </div>

        <dl className="grid grid-cols-2 gap-y-3 sm:grid-cols-4">
          <Stat label="ارزش وام" value={formatTomanCompact(t.loan_value)} />
          <Stat label="مبلغ امانی" value={formatToman(t.loan_price)} accent />
          <Stat label="کارمزد خریدار" value={formatToman(t.buyer_fee)} />
          <Stat label="کارمزد فروشنده" value={formatToman(t.seller_fee)} />
        </dl>
      </Card>

      {/* Identities (req. G) */}
      <div className="grid gap-4 sm:grid-cols-2">
        <Card>
          <CardTitle>خریدار</CardTitle>
          <p className="mt-2 font-semibold">{t.buyer_name ?? "—"}</p>
          <p className="text-xs text-[var(--color-muted)]" dir="ltr">{t.buyer_mobile ? toFaDigits(t.buyer_mobile) : "—"}</p>
        </Card>
        <Card>
          <CardTitle>فروشنده</CardTitle>
          <p className="mt-2 font-semibold">{t.seller_name ?? "—"}</p>
          <p className="text-xs text-[var(--color-muted)]" dir="ltr">{t.seller_mobile ? toFaDigits(t.seller_mobile) : "—"}</p>
        </Card>
      </div>

      {/* Workflow timeline (req. O) */}
      <Card>
        <CardTitle>روند معامله</CardTitle>
        <div className="mt-4">
          <DealTimeline stages={t.stages} />
        </div>
      </Card>

      {/* Buyer-supplied transfer info (req. D) */}
      {infoEntries.length > 0 && (
        <Card>
          <CardTitle>اطلاعات تکمیلی خریدار</CardTitle>
          <dl className="mt-3 grid grid-cols-2 gap-y-2 text-sm sm:grid-cols-3">
            {infoEntries.map(([k, v]) => (
              <div key={k}>
                <dt className="text-xs text-[var(--color-muted)]">{k}</dt>
                <dd className="font-medium">{String(v)}</dd>
              </div>
            ))}
          </dl>
        </Card>
      )}

      {/* Manual settlement evidence (req. F) */}
      {t.evidence.length > 0 && (
        <Card>
          <CardTitle>مدارک تسویهٔ دستی</CardTitle>
          <div className="mt-3">
            <EvidenceList evidence={t.evidence} />
          </div>
        </Card>
      )}

      {/* Transaction trace (req. G) */}
      <Card>
        <CardTitle>شماره تراکنش‌ها و امانی</CardTitle>
        <p className="mt-2 text-xs text-[var(--color-muted)]" dir="ltr">
          شناسهٔ امانی: {t.escrow_id ? toFaDigits(t.escrow_id) : "—"}
          {t.escrow_state ? ` · وضعیت: ${t.escrow_state}` : ""}
        </p>
        {t.transactions.length === 0 ? (
          <CardMuted className="mt-3">تراکنش مالی ثبت نشده است (احتمالاً حالت بدون امانت).</CardMuted>
        ) : (
          <div className="mt-3 overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="text-right text-xs text-[var(--color-muted)]">
                  <th className="py-1">نوع</th>
                  <th className="py-1">شماره تراکنش</th>
                  <th className="py-1">زمان</th>
                </tr>
              </thead>
              <tbody>
                {t.transactions.map((tx) => (
                  <tr key={tx.id} className="border-t border-[var(--color-border)]">
                    <td className="py-2">{TX_TYPE_FA[tx.type] ?? tx.type}</td>
                    <td className="py-2 text-xs" dir="ltr">{toFaDigits(tx.id)}</td>
                    <td className="py-2 text-xs text-[var(--color-muted)]">{formatDateTimeFa(tx.created_at)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Card>

      {/* Raw escrow event log */}
      <Card>
        <CardTitle>گزارش رویدادهای امانی</CardTitle>
        <ol className="mt-3 space-y-2 text-xs">
          {t.events.map((e, i) => (
            <li key={i} className="flex flex-wrap items-center gap-2 text-[var(--color-muted)]">
              <span className="text-[var(--color-fg)]">{e.from_state ?? "—"} → {e.to_state ?? "—"}</span>
              {e.reason && <span>· {e.reason}</span>}
              <span className="ms-auto">{formatDateTimeFa(e.created_at)}</span>
            </li>
          ))}
          {t.events.length === 0 && <CardMuted>رویدادی ثبت نشده است.</CardMuted>}
        </ol>
      </Card>
    </div>
  );
}

function Stat({ label, value, accent }: { label: string; value: string; accent?: boolean }) {
  return (
    <div>
      <dt className="text-sm text-[var(--color-muted)]">{label}</dt>
      <dd className={`mt-0.5 font-semibold ${accent ? "text-[var(--color-accent)]" : ""}`}>{value}</dd>
    </div>
  );
}
