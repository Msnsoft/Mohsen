import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { formatToman, toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

export default async function AdminDashboard() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.isAdmin) redirect("/");

  const rows = await withUser(user.id, (tx) =>
    tx.execute<{
      users: string; active_listings: string; pending_listings: string;
      open_deals: string; completed_deals: string; escrow_volume: string;
      revenue: string; wallet_total: string;
    }>(sql`
      select
        (select count(*) from users)::text as users,
        (select count(*) from loan_posts where status = 'active')::text as active_listings,
        (select count(*) from loan_posts where status = 'pending_review')::text as pending_listings,
        (select count(*) from deals where state in ('waiting_seller_transfer','waiting_buyer_confirmation'))::text as open_deals,
        (select count(*) from deals where state = 'completed')::text as completed_deals,
        (select coalesce(sum(le.amount), 0) from ledger_entries le
           join ledger_accounts la on la.id = le.account_id and la.system_key = 'escrow_liability')::text as escrow_volume,
        (select coalesce(sum(le.amount), 0) from ledger_entries le
           join ledger_accounts la on la.id = le.account_id and la.system_key = 'platform_revenue')::text as revenue,
        (select coalesce(sum(le.amount), 0) from ledger_entries le
           join ledger_accounts la on la.id = le.account_id and la.kind = 'available')::text as wallet_total
    `),
  );
  const s = rows[0];

  // Every stat is clickable and lands on the filtered list (AC-ADM-03).
  const cards = [
    { label: "کاربران", value: toFaDigits(s?.users ?? "0"), href: "/admin/users" },
    { label: "آگهی‌های فعال", value: toFaDigits(s?.active_listings ?? "0"), href: "/admin/listings?status=active" },
    { label: "در انتظار تأیید", value: toFaDigits(s?.pending_listings ?? "0"), href: "/admin/listings" },
    { label: "معاملات جاری", value: toFaDigits(s?.open_deals ?? "0"), href: "/admin/deals?state=open" },
    { label: "معاملات تکمیل‌شده", value: toFaDigits(s?.completed_deals ?? "0"), href: "/admin/deals?state=completed" },
    { label: "حجم وجوه امانی", value: formatToman(Number(s?.escrow_volume ?? 0)), href: "/admin/escrows" },
    { label: "درآمد پلتفرم", value: formatToman(Number(s?.revenue ?? 0)), href: "/admin/wallets" },
    { label: "مجموع موجودی کیف پول‌ها", value: formatToman(Number(s?.wallet_total ?? 0)), href: "/admin/wallets" },
  ];

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">داشبورد مدیریت</h1>
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {cards.map((c) => (
          <Link key={c.label} href={c.href}>
            <Card className="h-full transition-colors hover:border-[var(--color-primary)]">
              <CardMuted>{c.label}</CardMuted>
              <p className="mt-1 text-xl font-extrabold">{c.value}</p>
            </Card>
          </Link>
        ))}
      </div>
    </div>
  );
}
