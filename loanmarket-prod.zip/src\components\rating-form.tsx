"use client";
import { useState } from "react";
import { Star } from "lucide-react";
import { Button } from "@/components/ui/button";
import { submitRatingAction } from "@/app/deals/actions";

/** Star rating + admin-defined questions, shown after a deal completes (req. S). */
export function RatingForm({ dealId, questions }: { dealId: string; questions: string[] }) {
  const [score, setScore] = useState(0);
  const [hover, setHover] = useState(0);

  return (
    <form action={submitRatingAction} className="space-y-4">
      <input type="hidden" name="deal_id" value={dealId} />
      <input type="hidden" name="score" value={score} />

      <div className="flex items-center gap-1" dir="ltr">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            onClick={() => setScore(n)}
            onMouseEnter={() => setHover(n)}
            onMouseLeave={() => setHover(0)}
            className="p-0.5"
            aria-label={`${n} ستاره`}
          >
            <Star
              size={26}
              className={(hover || score) >= n ? "fill-[var(--color-warning)] text-[var(--color-warning)]" : "text-[var(--color-border)]"}
            />
          </button>
        ))}
      </div>

      {questions.length > 0 && (
        <div className="space-y-3">
          {questions.map((q) => (
            <label key={q} className="block space-y-1.5 text-sm">
              <span className="text-[var(--color-muted)]">{q}</span>
              <select
                name={`q:${q}`}
                defaultValue="خوب"
                className="w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]"
              >
                <option value="عالی">عالی</option>
                <option value="خوب">خوب</option>
                <option value="متوسط">متوسط</option>
                <option value="ضعیف">ضعیف</option>
              </select>
            </label>
          ))}
        </div>
      )}

      <Button type="submit" variant="accent" disabled={score < 1}>ثبت امتیاز</Button>
    </form>
  );
}
