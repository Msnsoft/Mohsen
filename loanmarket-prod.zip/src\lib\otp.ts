import "server-only";
import { createHmac, randomInt, timingSafeEqual } from "crypto";
import { db, sql } from "@/db";
import { sendSms } from "@/lib/sms";

const secret = process.env.SESSION_SECRET ?? "dev-session-secret-change-me-please-32+chars";
const ttlMin = Number(process.env.OTP_TTL_MINUTES ?? 3);

function hashCode(mobile: string, code: string): string {
  return createHmac("sha256", secret).update(`${mobile}:${code}`).digest("hex");
}

function normalizeMobile(input: string): string {
  // accept 09xxxxxxxxx / +989xxxxxxxxx / ۰۹... → 09xxxxxxxxx
  const en = input.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)));
  const digits = en.replace(/\D/g, "");
  if (digits.startsWith("98")) return "0" + digits.slice(2);
  if (digits.startsWith("0")) return digits;
  if (digits.length === 10) return "0" + digits;
  return digits;
}

export type OtpResult = { ok: boolean; mobile: string; devCode?: string; throttled?: boolean };

export async function requestOtp(rawMobile: string): Promise<OtpResult> {
  const mobile = normalizeMobile(rawMobile);
  if (!/^09\d{9}$/.test(mobile)) return { ok: false, mobile };

  // Phase 9 rate limit: max 5 OTP requests per mobile per 10 minutes.
  const allowed = await db.execute<{ rate_limit_hit: boolean }>(
    sql`select rate_limit_hit(${"otp:" + mobile}, 5, 600) as rate_limit_hit`,
  );
  if ((allowed[0] as { rate_limit_hit: boolean } | undefined)?.rate_limit_hit === false) {
    return { ok: false, mobile, throttled: true };
  }

  const code = String(randomInt(100000, 999999));
  const codeHash = hashCode(mobile, code);
  const expires = new Date(Date.now() + ttlMin * 60_000);

  await db.execute(sql`
    insert into otp_codes (mobile, code_hash, expires_at)
    values (${mobile}, ${codeHash}, ${expires.toISOString()})
  `);

  const devMode = process.env.OTP_DEV_MODE === "true" || (process.env.SMS_PROVIDER ?? "console") === "console";
  await sendSms(mobile, `کد ورود شما: ${code} (اعتبار ${ttlMin} دقیقه)`);
  return devMode ? { ok: true, mobile, devCode: code } : { ok: true, mobile };
}

export async function verifyOtp(rawMobile: string, rawCode: string): Promise<{ ok: boolean; userId?: string }> {
  const mobile = normalizeMobile(rawMobile);
  const code = rawCode.replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d))).replace(/\D/g, "");

  const rows = await db.execute<{ id: string; code_hash: string }>(sql`
    select id, code_hash from otp_codes
    where mobile = ${mobile} and consumed = false and expires_at > now()
    order by created_at desc limit 1
  `);
  const row = rows[0] as { id: string; code_hash: string } | undefined;
  if (!row) return { ok: false };

  const expected = Buffer.from(row.code_hash, "hex");
  const got = Buffer.from(hashCode(mobile, code), "hex");
  if (expected.length !== got.length || !timingSafeEqual(expected, got)) {
    await db.execute(sql`update otp_codes set attempts = attempts + 1 where id = ${row.id}`);
    return { ok: false };
  }

  await db.execute(sql`update otp_codes set consumed = true where id = ${row.id}`);
  const superEmail = process.env.SUPER_ADMIN_EMAIL ?? null;
  const res = await db.execute<{ get_or_create_user: string }>(sql`
    select get_or_create_user(${mobile}, ${superEmail}) as get_or_create_user
  `);
  const userId = (res[0] as { get_or_create_user: string }).get_or_create_user;
  return { ok: true, userId };
}
