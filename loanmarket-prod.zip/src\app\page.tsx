import Link from "next/link";
import { ShieldCheck, Wallet, Scale, Crown } from "lucide-react";
import { getActiveListings } from "@/services/marketplace";
import { getWidgets, getFaqs, getMenu, getSiteStats, STAT_METRIC_FA } from "@/lib/cms";
import { ListingCard } from "@/components/listing-card";
import { Button } from "@/components/ui/button";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { formatTomanCompact, toFaDigits } from "@/lib/persian";

export const dynamic = "force-dynamic";

const DEFAULT_CTA = [
  { label: "ورود به بازار", url: "/marketplace" },
  { label: "ماشین‌حساب وام", url: "/calculator" },
];

export default async function HomePage() {
  const widgets = await getWidgets();
  const enabled = (key: string) => widgets.find((w) => w.key === key)?.enabled ?? true;
  const heroPayload = (widgets.find((w) => w.key === "hero")?.payload ?? {}) as { title?: string; subtitle?: string; eyebrow?: string; image_url?: string };
  const statsPayload = (widgets.find((w) => w.key === "stats")?.payload ?? {}) as { title?: string; metrics?: string[] };
  const featuredLimit = Number((widgets.find((w) => w.key === "featured_listings")?.payload as { limit?: number })?.limit ?? 4);
  const faqLimit = Number((widgets.find((w) => w.key === "faq_section")?.payload as { limit?: number })?.limit ?? 4);

  const ctaLinks = await getMenu("landing");
  const cta = ctaLinks.length > 0 ? ctaLinks : DEFAULT_CTA;
  const featured = enabled("featured_listings") ? await getActiveListings({ limit: featuredLimit }) : [];
  const faqs = enabled("faq_section") ? await getFaqs(faqLimit) : [];
  const stats = enabled("stats") ? await getSiteStats() : null;
  const statMetrics = statsPayload.metrics ?? ["users", "active_listings", "completed_deals", "volume"];

  return (
    <div className="space-y-12">
      {/* Hero */}
      {enabled("hero") && (
        <section className="relative overflow-hidden rounded-3xl border border-[var(--color-border)] bg-gradient-to-bl from-[color-mix(in_oklab,var(--color-primary)_14%,transparent)] via-[var(--color-surface)] to-[color-mix(in_oklab,var(--color-accent)_12%,transparent)] p-6 md:p-10">
          <div className="pointer-events-none absolute -left-16 -top-16 h-56 w-56 rounded-full bg-[color-mix(in_oklab,var(--color-primary)_22%,transparent)] blur-3xl" />
          <div className="pointer-events-none absolute -bottom-20 -right-10 h-56 w-56 rounded-full bg-[color-mix(in_oklab,var(--color-accent)_20%,transparent)] blur-3xl" />
          <div className="relative grid items-center gap-8 md:grid-cols-2">
            <div className="space-y-5">
              {heroPayload.eyebrow && (
                <span className="inline-block rounded-full border border-[var(--color-border)] bg-[var(--color-surface)] px-3 py-1 text-xs font-medium text-[var(--color-primary)]">
                  {heroPayload.eyebrow}
                </span>
              )}
              <h1 className="text-3xl font-extrabold leading-tight md:text-5xl">
                {heroPayload.title ?? "خرید و فروش امن امتیاز وام"}
              </h1>
              <p className="text-lg text-[var(--color-muted)]">
                {heroPayload.subtitle ??
                  "معامله‌ی تضمین‌شده با امانت‌داری وجه، شفافیت کامل نرخ مؤثر سالانه (APR)، و کارمزد منصفانه. بدون ریسک کلاهبرداری."}
              </p>
              <div className="flex flex-wrap gap-3">
                {cta.map((c, i) => (
                  <Link key={c.url + i} href={c.url}>
                    <Button size="lg" variant={i === 0 ? "primary" : "outline"}>{c.label}</Button>
                  </Link>
                ))}
              </div>
            </div>
            {heroPayload.image_url ? (
              // eslint-disable-next-line @next/next/no-img-element
              <img src={heroPayload.image_url} alt="" className="h-full max-h-72 w-full rounded-2xl object-cover shadow-lg" />
            ) : (
              enabled("features") && (
                <div className="grid grid-cols-2 gap-3">
                  <Feature icon={<ShieldCheck />} title="امانی امن" body="اصل مبلغ تا تکمیل انتقال نزد امانت نگهداری می‌شود." />
                  <Feature icon={<Wallet />} title="کیف پول و دفترکل" body="حسابداری دو‌طرفه و شفاف برای کارمزد و تسویه." />
                  <Feature icon={<Scale />} title="قیمت منصفانه" body="پیشنهاد قیمت بر اساس بازار و بازده هدف شما." />
                  <Feature icon={<Crown />} title="اشتراک ویژه" body="مشاوره هوشمند قیمت، هشدار پیامکی و پیشنهاد خودکار." />
                </div>
              )
            )}
          </div>
        </section>
      )}

      {/* Site statistics (editable via admin CMS) */}
      {stats && (
        <section className="space-y-4">
          {statsPayload.title && <h2 className="text-center text-xl font-bold">{statsPayload.title}</h2>}
          <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
            {statMetrics.map((m) => {
              const raw = stats[m as keyof typeof stats] ?? 0;
              const value = m === "volume" ? formatTomanCompact(raw) : toFaDigits(raw);
              return (
                <Card key={m} className="text-center">
                  <p className="text-2xl font-extrabold text-[var(--color-primary)]">{value}</p>
                  <CardMuted>{STAT_METRIC_FA[m] ?? m}</CardMuted>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {/* Featured listings */}
      {enabled("featured_listings") && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">آگهی‌های منتخب</h2>
            <Link href="/marketplace" className="text-sm text-[var(--color-primary)]">مشاهده همه ←</Link>
          </div>
          {featured.length === 0 ? (
            <Card><CardMuted>هنوز آگهی فعالی ثبت نشده است.</CardMuted></Card>
          ) : (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
              {featured.map((l) => <ListingCard key={l.id} l={l} />)}
            </div>
          )}
        </section>
      )}

      {/* FAQ */}
      {enabled("faq_section") && faqs.length > 0 && (
        <section className="space-y-4">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-bold">سوالات متداول</h2>
            <Link href="/faq" className="text-sm text-[var(--color-primary)]">همه ←</Link>
          </div>
          <div className="grid gap-3 md:grid-cols-2">
            {faqs.map((f) => (
              <Card key={f.id} className="space-y-1">
                <CardTitle>{f.question}</CardTitle>
                <CardMuted>{f.answer}</CardMuted>
              </Card>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}

function Feature({ icon, title, body }: { icon: React.ReactNode; title: string; body: string }) {
  return (
    <Card className="space-y-2">
      <span className="grid h-10 w-10 place-items-center rounded-xl bg-[var(--color-surface-2)] text-[var(--color-primary)]">{icon}</span>
      <CardTitle>{title}</CardTitle>
      <CardMuted>{body}</CardMuted>
    </Card>
  );
}
