import Link from "next/link";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, toFaDigits } from "@/lib/persian";
import { POST_STATUS_FA, postStatusTone } from "@/lib/post-status";
import { requireSectionPage } from "../guard";
import { moderateListingAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminListingsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const admin = await requireSectionPage("listings");
  const { status = "pending_review" } = await searchParams;

  const posts = await withUser(admin.id, (tx) =>
    tx.execute<{
      id: string; type: string; status: string; loan_value: string; loan_price: string;
      price_per_million: string | null; province: string | null; created_at: string;
      loan_type_name: string; owner_name: string | null; owner_mobile: string;
    }>(sql`
      select p.id, p.type, p.status, p.loan_value::text, p.loan_price::text,
             p.price_per_million::text, p.province, p.created_at::text,
             t.name as loan_type_name, u.display_name as owner_name, u.mobile as owner_mobile
      from loan_posts p
      join loan_types t on t.id = p.loan_type_id
      join users u on u.id = p.user_id
      where p.status = ${status}
      order by p.created_at asc limit 100`),
  );

  const tabs = ["pending_review", "active", "rejected", "sold", "cancelled"];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">تأیید آگهی‌ها</h1>

      <div className="flex flex-wrap gap-2">
        {tabs.map((t) => (
          <Link
            key={t}
            href={`/admin/listings?status=${t}`}
            className={`rounded-full border px-3 py-1 text-xs ${
              status === t
                ? "border-[var(--color-primary)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {POST_STATUS_FA[t]}
          </Link>
        ))}
      </div>

      {posts.length === 0 ? (
        <Card><CardMuted>آگهی‌ای با این وضعیت وجود ندارد.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {posts.map((p) => (
            <Card key={p.id} className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="flex items-center gap-2 font-semibold">
                  {p.loan_type_name}
                  <Badge tone={p.type === "sell" ? "accent" : "warning"}>{p.type === "sell" ? "فروش" : "خرید"}</Badge>
                  <Badge tone={postStatusTone(p.status)}>{POST_STATUS_FA[p.status] ?? p.status}</Badge>
                </p>
                <p className="text-sm text-[var(--color-muted)]">
                  مبلغ {formatToman(Number(p.loan_value))} · قیمت {formatToman(Number(p.loan_price))}
                  {p.price_per_million && <> · هر میلیون {formatToman(Number(p.price_per_million))}</>}
                  {p.province && <> · {p.province}</>}
                </p>
                <p className="text-xs text-[var(--color-muted)]">
                  آگهی‌دهنده: {p.owner_name ?? "—"} <span dir="ltr">{toFaDigits(p.owner_mobile)}</span>
                </p>
              </div>
              {p.status === "pending_review" && (
                <div className="flex gap-2">
                  <form action={moderateListingAction}>
                    <input type="hidden" name="post_id" value={p.id} />
                    <input type="hidden" name="decision" value="approve" />
                    <Button variant="accent" size="sm" type="submit">تأیید و انتشار</Button>
                  </form>
                  <form action={moderateListingAction}>
                    <input type="hidden" name="post_id" value={p.id} />
                    <input type="hidden" name="decision" value="reject" />
                    <Button variant="outline" size="sm" type="submit" className="text-[var(--color-danger)]">رد</Button>
                  </form>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
