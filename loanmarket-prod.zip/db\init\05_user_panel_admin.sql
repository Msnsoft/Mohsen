-- =====================================================================
-- Increment 3: user panel + admin panel + UI themes.
--  * users.theme — one of 6 color sets (M02 FR-M02-10), user-saveable
--  * self-service policies (profile update, listing create/cancel)
--  * admin write policies for catalog/commission/plans/config/roles
--  * config keys: ui.default_theme, marketplace.listing_approval_mode
-- =====================================================================
SET check_function_bodies = off;

-- ---- Theme preference (M02 FR-M02-10) --------------------------------
ALTER TABLE users ADD COLUMN IF NOT EXISTS theme text NOT NULL DEFAULT 'ocean';
ALTER TABLE users DROP CONSTRAINT IF EXISTS users_theme_ck;
ALTER TABLE users ADD CONSTRAINT users_theme_ck
  CHECK (theme IN ('ocean','emerald','violet','sunset','rose','light'));

-- ---- Config keys ------------------------------------------------------
INSERT INTO config(key, value) VALUES
  ('ui.default_theme', '"ocean"'),
  ('marketplace.listing_approval_mode', '"manual"')   -- auto | manual
ON CONFLICT (key) DO NOTHING;

-- ---- Self-service policies --------------------------------------------
-- users may update their own row (server actions limit columns: name/theme);
-- admins may update any (suspend, level changes).
DROP POLICY IF EXISTS p_users_self_update ON users;
CREATE POLICY p_users_self_update ON users FOR UPDATE
  USING (id = current_user_id() OR is_admin())
  WITH CHECK (id = current_user_id() OR is_admin());

-- ---- Admin write policies ----------------------------------------------
DROP POLICY IF EXISTS p_loan_types_admin_ins ON loan_types;
DROP POLICY IF EXISTS p_loan_types_admin_upd ON loan_types;
CREATE POLICY p_loan_types_admin_ins ON loan_types FOR INSERT WITH CHECK (is_admin());
CREATE POLICY p_loan_types_admin_upd ON loan_types FOR UPDATE USING (is_admin());

DROP POLICY IF EXISTS p_commission_admin_ins ON commission_rules;
DROP POLICY IF EXISTS p_commission_admin_upd ON commission_rules;
DROP POLICY IF EXISTS p_commission_admin_del ON commission_rules;
CREATE POLICY p_commission_admin_ins ON commission_rules FOR INSERT WITH CHECK (is_admin());
CREATE POLICY p_commission_admin_upd ON commission_rules FOR UPDATE USING (is_admin());
CREATE POLICY p_commission_admin_del ON commission_rules FOR DELETE USING (is_admin());

DROP POLICY IF EXISTS p_commission_bands_admin ON commission_bands;
CREATE POLICY p_commission_bands_admin ON commission_bands FOR ALL
  USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS p_plans_admin_ins ON subscription_plans;
DROP POLICY IF EXISTS p_plans_admin_upd ON subscription_plans;
CREATE POLICY p_plans_admin_ins ON subscription_plans FOR INSERT WITH CHECK (is_admin());
CREATE POLICY p_plans_admin_upd ON subscription_plans FOR UPDATE USING (is_admin());

DROP POLICY IF EXISTS p_plan_ent_admin ON plan_entitlements;
CREATE POLICY p_plan_ent_admin ON plan_entitlements FOR ALL
  USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS p_config_admin_ins ON config;
DROP POLICY IF EXISTS p_config_admin_upd ON config;
CREATE POLICY p_config_admin_ins ON config FOR INSERT WITH CHECK (is_admin());
CREATE POLICY p_config_admin_upd ON config FOR UPDATE USING (is_admin());

-- role management (super-admin gating enforced in the service layer)
DROP POLICY IF EXISTS p_user_roles_admin_ins ON user_roles;
DROP POLICY IF EXISTS p_user_roles_admin_del ON user_roles;
CREATE POLICY p_user_roles_admin_ins ON user_roles FOR INSERT WITH CHECK (is_admin());
CREATE POLICY p_user_roles_admin_del ON user_roles FOR DELETE USING (is_admin());

-- admins may notify users (e.g. listing approved/rejected) and read for support
DROP POLICY IF EXISTS p_notif_insert ON notifications;
CREATE POLICY p_notif_insert ON notifications FOR INSERT
  WITH CHECK (is_admin() OR user_id = current_user_id());
DROP POLICY IF EXISTS p_notif_self ON notifications;
CREATE POLICY p_notif_self ON notifications FOR SELECT
  USING (user_id = current_user_id() OR is_admin());
