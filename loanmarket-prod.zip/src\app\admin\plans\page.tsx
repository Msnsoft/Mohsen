import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toFaDigits } from "@/lib/persian";
import { requireSectionPage } from "../guard";
import { savePlanAction } from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

const ENT_FA: Record<string, string> = {
  calculator: "ماشین‌حساب پیشرفته",
  pricing_advice: "مشاورهٔ هوشمند قیمت",
  sms_alerts: "هشدار پیامکی",
  auto_match: "پیشنهاد خودکار خرید/فروش",
  history_charts: "نمودار تاریخچهٔ معاملات",
};

export default async function AdminPlansPage() {
  const admin = await requireSectionPage("plans");

  const data = await withUser(admin.id, async (tx) => {
    const plans = await tx.execute<{
      id: string; key: string; name: string; price: string; period_days: number;
      active: boolean; members: string;
    }>(sql`
      select p.id, p.key, p.name, p.price::text, p.period_days, p.active,
             (select count(*) from subscriptions s where s.plan_id = p.id and s.status = 'active')::text as members
      from subscription_plans p order by p.sort`);
    const ents = await tx.execute<{ plan_id: string; entitlement: string }>(
      sql`select plan_id, entitlement from plan_entitlements`,
    );
    return { plans, ents };
  });

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">اشتراک‌ها و طرح‌ها</h1>
      <CardMuted>تغییر قیمت/امکانات فقط روی اشتراک‌های جدید یا تمدیدی اثر می‌گذارد، نه اشتراک‌های جاری.</CardMuted>

      {data.plans.map((p) => {
        const planEnts = data.ents.filter((e) => e.plan_id === p.id).map((e) => e.entitlement);
        return (
          <Card key={p.id} className="space-y-3">
            <div className="flex items-center gap-2">
              <CardTitle>{p.name}</CardTitle>
              <Badge tone="default">{p.key}</Badge>
              {!p.active && <Badge tone="muted">غیرفعال</Badge>}
              <span className="text-xs text-[var(--color-muted)]">{toFaDigits(p.members)} عضو فعال</span>
            </div>
            <form action={savePlanAction} className="space-y-3">
              <input type="hidden" name="id" value={p.id} />
              <div className="grid items-end gap-3 sm:grid-cols-4">
                <label className="space-y-1 text-xs text-[var(--color-muted)]">
                  قیمت (تومان)
                  <input name="price" defaultValue={Number(p.price) / 10} dir="ltr" className={inputCls} />
                </label>
                <label className="space-y-1 text-xs text-[var(--color-muted)]">
                  مدت (روز)
                  <input name="period_days" defaultValue={p.period_days} dir="ltr" className={inputCls} />
                </label>
                <label className="flex items-center gap-1.5 text-sm">
                  <input type="checkbox" name="active" defaultChecked={p.active} />
                  فعال
                </label>
                <Button size="sm" type="submit">ذخیره</Button>
              </div>
              <div className="flex flex-wrap gap-x-5 gap-y-2 border-t border-[var(--color-border)] pt-3 text-sm">
                {Object.entries(ENT_FA).map(([key, label]) => (
                  <label key={key} className="flex items-center gap-1.5">
                    <input type="checkbox" name={`ent_${key}`} defaultChecked={planEnts.includes(key)} />
                    {label}
                  </label>
                ))}
              </div>
            </form>
          </Card>
        );
      })}
    </div>
  );
}
