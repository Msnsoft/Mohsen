import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, formatPercent } from "@/lib/persian";
import { requireSectionPage } from "../guard";
import { saveCommissionRuleAction } from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

export default async function AdminCommissionsPage({
  searchParams,
}: {
  searchParams: Promise<{ amount?: string }>;
}) {
  const admin = await requireSectionPage("commissions");
  const { amount } = await searchParams;
  const previewToman = Number((amount ?? "").replace(/[^\d]/g, "")) || 120_000_000; // worked example default
  const previewIrr = previewToman * 10;

  const data = await withUser(admin.id, async (tx) => {
    const rules = await tx.execute<{
      id: string; side: string; method: string; percent_rate: string | null;
      base_fee: string; tax_rate: string; source: string; active: boolean;
      loan_type_name: string | null;
    }>(sql`
      select r.id, r.side, r.method, r.percent_rate::text, r.base_fee::text,
             r.tax_rate::text, r.source, r.active, t.name as loan_type_name
      from commission_rules r
      left join loan_types t on t.id = r.loan_type_id
      order by t.name nulls first, r.side`);
    const bands = await tx.execute<{
      rule_id: string; from_amount: string; to_amount: string | null;
      amount_per_band: string | null; rate_per_million: string | null; sort: number;
    }>(sql`
      select rule_id, from_amount::text, to_amount::text, amount_per_band::text,
             rate_per_million::text, sort
      from commission_bands order by rule_id, sort`);
    // live preview via the same SQL function used by deal_start (AC-ADM-07)
    const previews = await tx.execute<{ side: string; loan_type_name: string | null; fee: string }>(sql`
      select r.side, t.name as loan_type_name,
             commission_compute(r.loan_type_id, r.side, ${previewIrr}::bigint)::text as fee
      from (select distinct loan_type_id, side from commission_rules where active) r
      left join loan_types t on t.id = r.loan_type_id
      order by t.name nulls first, r.side`);
    return { rules, bands, previews };
  });

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">قوانین کارمزد</h1>

      <Card className="space-y-3">
        <CardTitle>پیش‌نمایش زنده</CardTitle>
        <form className="flex flex-wrap items-end gap-3" method="get">
          <label className="space-y-1 text-xs text-[var(--color-muted)]">
            مبلغ نمونه (تومان)
            <input name="amount" defaultValue={previewToman.toLocaleString("en-US")} dir="ltr" className={inputCls} />
          </label>
          <Button size="sm" type="submit" variant="outline">محاسبه</Button>
        </form>
        <div className="grid gap-2 sm:grid-cols-2">
          {data.previews.map((p, i) => (
            <div key={i} className="rounded-lg bg-[var(--color-surface-2)] px-3 py-2 text-sm">
              {p.loan_type_name ?? "قانون سراسری"} · {p.side === "buyer" ? "خریدار" : "فروشنده"}:{" "}
              <strong>{formatToman(Number(p.fee))}</strong>
            </div>
          ))}
        </div>
      </Card>

      <div className="space-y-3">
        {data.rules.map((r) => {
          const ruleBands = data.bands.filter((b) => b.rule_id === r.id);
          return (
            <Card key={r.id} className="space-y-3">
              <div className="flex flex-wrap items-center gap-2">
                <CardTitle>{r.loan_type_name ?? "پیش‌فرض سراسری"}</CardTitle>
                <Badge tone={r.side === "buyer" ? "warning" : "accent"}>{r.side === "buyer" ? "خریدار" : "فروشنده"}</Badge>
                <Badge tone="default">{r.method === "percent" ? "درصدی" : "پلکانی"}</Badge>
                {!r.active && <Badge tone="muted">غیرفعال</Badge>}
              </div>

              {r.method === "progressive" && ruleBands.length > 0 && (
                <ul className="space-y-1 text-sm text-[var(--color-muted)]">
                  {ruleBands.map((b, i) => (
                    <li key={i}>
                      از {formatToman(Number(b.from_amount))} {b.to_amount ? `تا ${formatToman(Number(b.to_amount))}` : "به بالا"} →{" "}
                      {b.amount_per_band
                        ? `${formatToman(Number(b.amount_per_band))} (ثابت)`
                        : `${formatToman(Number(b.rate_per_million ?? 0))} به ازای هر میلیون تومان`}
                    </li>
                  ))}
                </ul>
              )}

              <form action={saveCommissionRuleAction} className="grid items-end gap-3 sm:grid-cols-2 lg:grid-cols-5">
                <input type="hidden" name="id" value={r.id} />
                {r.method === "percent" ? (
                  <label className="space-y-1 text-xs text-[var(--color-muted)]">
                    نرخ درصدی (٪)
                    <input name="percent_rate" defaultValue={r.percent_rate ?? ""} dir="ltr" className={inputCls} />
                  </label>
                ) : (
                  <p className="text-xs text-[var(--color-muted)]">
                    نرخ فعلی: {r.percent_rate ? formatPercent(r.percent_rate) : "پلکانی (جدول بالا)"}
                  </p>
                )}
                <label className="space-y-1 text-xs text-[var(--color-muted)]">
                  کارمزد پایه (تومان)
                  <input name="base_fee" defaultValue={Number(r.base_fee) / 10 || ""} dir="ltr" className={inputCls} />
                </label>
                <label className="space-y-1 text-xs text-[var(--color-muted)]">
                  ضریب مالیات (مثلاً 0.09)
                  <input name="tax_rate" defaultValue={r.tax_rate ?? "0"} dir="ltr" className={inputCls} />
                </label>
                <label className="flex items-center gap-1.5 text-sm">
                  <input type="checkbox" name="active" defaultChecked={r.active} />
                  فعال
                </label>
                <Button size="sm" type="submit">ذخیره</Button>
              </form>
            </Card>
          );
        })}
        {data.rules.length === 0 && <Card><CardMuted>قانونی تعریف نشده است.</CardMuted></Card>}
      </div>
    </div>
  );
}
