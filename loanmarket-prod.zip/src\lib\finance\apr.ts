// APR / EAR / fair-value / risk engine for the secondary loan marketplace.
// Carried from the prototype (docs: keep). Amounts are plain numbers (IRR or toman,
// caller-consistent); ratios are unitless.
import { irr, annualizeMonthly } from "./irr";
import { monthlyInstallment } from "./amortization";

export interface APRInputs {
  loanAmount: number;     // disbursement the buyer receives from the bank
  askingPrice: number;    // what the buyer pays the seller for the privilege
  bankRatePct: number;    // bank's nominal annual rate
  months: number;
  insurance?: number;
  platformFee?: number;
  escrowFee?: number;
}

export interface APRResult {
  monthlyInstallment: number;
  totalRepayment: number;
  totalCostToBuyer: number;
  realAPR: number;        // nominal annual (monthlyIRR * 12)
  effectiveAPR: number;   // EAR
  monthlyIRR: number | null;
}

export function calculateAPR(input: APRInputs): APRResult {
  const insurance = input.insurance ?? 0;
  const platformFee = input.platformFee ?? 0;
  const escrowFee = input.escrowFee ?? 0;
  const pmt = monthlyInstallment(input.loanAmount, input.bankRatePct, input.months);

  const t0 = input.loanAmount - input.askingPrice - insurance - platformFee - escrowFee;
  const cf = [t0, ...Array.from({ length: input.months }, () => -pmt)];

  const monthlyIRR = irr(cf, 0.01);
  const realAPR = monthlyIRR !== null ? monthlyIRR * 12 : NaN;
  const effectiveAPR = monthlyIRR !== null ? annualizeMonthly(monthlyIRR) : NaN;
  const totalRepayment = pmt * input.months;
  const totalCostToBuyer = input.askingPrice + insurance + platformFee + escrowFee + totalRepayment - input.loanAmount;

  return {
    monthlyInstallment: Math.round(pmt),
    totalRepayment: Math.round(totalRepayment),
    totalCostToBuyer: Math.round(totalCostToBuyer),
    realAPR: Number.isFinite(realAPR) ? realAPR : 0,
    effectiveAPR: Number.isFinite(effectiveAPR) ? effectiveAPR : 0,
    monthlyIRR,
  };
}

export interface FairValueResult {
  fairPrice: number;
  premiumPct: number;
  verdict: "below" | "fair" | "above";
}

/** Fair price = PV of installments discounted at a target annual rate. */
export function fairValueAtRate(loanAmount: number, askingPrice: number, targetAnnualPct: number, bankRatePct: number, months: number): FairValueResult {
  const r = targetAnnualPct / 100 / 12;
  const pmt = monthlyInstallment(loanAmount, bankRatePct, months);
  const pv = r === 0 ? pmt * months : (pmt * (1 - Math.pow(1 + r, -months))) / r;
  // value to buyer = loanAmount - PV(installments at target rate); fair price = that surplus
  const fairPrice = Math.max(0, Math.round(loanAmount - pv));
  const premiumPct = fairPrice === 0 ? 0 : ((askingPrice - fairPrice) / fairPrice) * 100;
  const verdict: FairValueResult["verdict"] = premiumPct < -2 ? "below" : premiumPct > 2 ? "above" : "fair";
  return { fairPrice, premiumPct, verdict };
}

export interface RiskFlags {
  highAPR: boolean;
  expensivePremium: boolean;
  heavyInstallment: boolean;
}

export function riskFlags(apr: APRResult, fair: FairValueResult, askingPrice: number, months: number): RiskFlags {
  return {
    highAPR: apr.realAPR > 0.5,
    expensivePremium: fair.premiumPct > 10,
    heavyInstallment: apr.monthlyInstallment > (askingPrice / Math.max(months, 1)) * 1.5,
  };
}
