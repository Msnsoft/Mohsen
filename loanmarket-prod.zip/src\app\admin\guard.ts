import "server-only";
import { redirect } from "next/navigation";
import { getCurrentUser, type CurrentUser } from "@/lib/auth";
import { canAccessSection } from "@/lib/rbac";

/** Page-level admin-section gate (AC-ADM-02). */
export async function requireSectionPage(section: string): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.isAdmin) redirect("/");
  if (!canAccessSection(user.roles, section)) redirect("/admin");
  return user;
}
