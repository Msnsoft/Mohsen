import { notFound } from "next/navigation";
import { getPage } from "@/lib/cms";

export const dynamic = "force-dynamic";

export default async function CmsPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const page = await getPage(slug);
  if (!page) notFound();
  return (
    <article className="prose-rtl space-y-4">
      <h1 className="text-2xl font-bold">{page.title}</h1>
      <div className="whitespace-pre-wrap leading-8 text-[var(--color-fg)]">{page.body}</div>
    </article>
  );
}
