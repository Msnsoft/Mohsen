import Link from "next/link";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatToman, toFaDigits } from "@/lib/persian";
import { DEAL_STATE_FA, dealStateTone } from "@/app/deals/state";
import { requireSectionPage } from "../guard";

export const dynamic = "force-dynamic";

const FILTERS: Record<string, { label: string; states: string[] | null }> = {
  all: { label: "همه", states: null },
  open: { label: "جاری", states: ["waiting_seller_transfer", "waiting_buyer_confirmation"] },
  completed: { label: "تکمیل‌شده", states: ["completed"] },
  cancelled: { label: "لغوشده", states: ["cancelled"] },
  disputed: { label: "اختلاف", states: ["disputed"] },
};

export default async function AdminDealsPage({
  searchParams,
}: {
  searchParams: Promise<{ state?: string }>;
}) {
  const admin = await requireSectionPage("deals");
  const { state = "all" } = await searchParams;
  const filter = FILTERS[state] ?? FILTERS.all;

  const deals = await withUser(admin.id, (tx) =>
    tx.execute<{
      id: string; state: string; loan_price: string; buyer_fee: string; seller_fee: string;
      created_at: string; buyer_name: string | null; seller_name: string | null; loan_type_name: string;
    }>(sql`
      select d.id, d.state, d.loan_price::text, d.buyer_fee::text, d.seller_fee::text,
             d.created_at::text, b.display_name as buyer_name, s.display_name as seller_name,
             t.name as loan_type_name
      from deals d
      join users b on b.id = d.buyer_id
      join users s on s.id = d.seller_id
      join loan_types t on t.id = d.loan_type_id
      where (${filter.states ? sql`d.state = any(${filter.states})` : sql`true`})
      order by d.created_at desc limit 100`),
  );

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">معاملات</h1>

      <div className="flex flex-wrap gap-2">
        {Object.entries(FILTERS).map(([k, f]) => (
          <Link
            key={k}
            href={`/admin/deals?state=${k}`}
            className={`rounded-full border px-3 py-1 text-xs ${
              state === k
                ? "border-[var(--color-primary)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {f.label}
          </Link>
        ))}
      </div>

      {deals.length === 0 ? (
        <Card><CardMuted>معامله‌ای یافت نشد.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {deals.map((d) => (
            <Link key={d.id} href={`/admin/deals/${d.id}`} className="block">
              <Card className="flex flex-wrap items-center justify-between gap-3 transition-colors hover:border-[var(--color-primary)]">
                <div className="space-y-1">
                  <p className="flex items-center gap-2 font-semibold">
                    {d.loan_type_name} · {formatToman(Number(d.loan_price))}
                    <Badge tone={dealStateTone(d.state)}>{DEAL_STATE_FA[d.state] ?? d.state}</Badge>
                  </p>
                  <p className="text-xs text-[var(--color-muted)]" dir="ltr">#{toFaDigits(d.id.slice(0, 8))}</p>
                  <p className="text-xs text-[var(--color-muted)]">
                    خریدار {d.buyer_name ?? "—"} · فروشنده {d.seller_name ?? "—"} ·
                    کارمزد خریدار {formatToman(Number(d.buyer_fee))} · کارمزد فروشنده {formatToman(Number(d.seller_fee))}
                  </p>
                </div>
                <span className="text-xs text-[var(--color-muted)]" dir="ltr">{d.created_at.slice(0, 16)}</span>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
