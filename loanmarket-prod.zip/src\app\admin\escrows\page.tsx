import Link from "next/link";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { formatToman, toFaDigits } from "@/lib/persian";
import { requireSectionPage } from "../guard";
import { adminEscrowAction, runDueJobsAction } from "../actions";

export const dynamic = "force-dynamic";

const ESCROW_STATE_FA: Record<string, string> = {
  funded: "تأمین‌شده",
  in_inspection: "در حال بررسی",
  released: "آزادشده",
  refunded: "مستردشده",
  frozen: "مسدود",
};
const stateTone = (s: string) =>
  s === "released" ? "accent" : s === "refunded" ? "muted" : s === "frozen" ? "danger" : "warning";

export default async function AdminEscrowsPage({
  searchParams,
}: {
  searchParams: Promise<{ jobs?: string }>;
}) {
  const admin = await requireSectionPage("escrows");
  const { jobs } = await searchParams;
  const jobsResult = jobs?.split("-").map(Number);

  const escrows = await withUser(admin.id, (tx) =>
    tx.execute<{
      id: string; deal_id: string; deal_state: string; amount: string; state: string;
      auto_release_at: string | null; created_at: string;
      buyer_name: string | null; seller_name: string | null;
    }>(sql`
      select e.id, e.deal_id, d.state as deal_state, e.amount::text, e.state,
             e.auto_release_at::text, e.created_at::text,
             b.display_name as buyer_name, s.display_name as seller_name
      from escrows e
      join deals d on d.id = e.deal_id
      join users b on b.id = e.buyer_id
      join users s on s.id = e.seller_id
      order by e.created_at desc limit 100`),
  );

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">کنسول امانی</h1>
        <form action={runDueJobsAction}>
          <Button variant="outline" size="sm" type="submit">اجرای کارهای زمان‌بندی‌شده</Button>
        </form>
      </div>
      <CardMuted>
        آزادسازی، وجه را به فروشنده تسویه و کارمزدها را ثبت می‌کند؛ استرداد، کل مبلغ و کارمزد را به خریدار برمی‌گرداند.
        هر اقدام در رویدادهای امانی ثبت می‌شود. «اجرای کارهای زمان‌بندی‌شده» همان وظایفی است که worker به‌صورت خودکار اجرا می‌کند
        (آزادسازی خودکار، انقضای مهلت فروشنده، یادآوری‌ها، پایان اشتراک).
      </CardMuted>
      {jobsResult && (
        <Card>
          <CardMuted>
            نتیجهٔ اجرا: آزادسازی خودکار {toFaDigits(jobsResult[0] ?? 0)} · انقضای مهلت فروشنده {toFaDigits(jobsResult[1] ?? 0)} ·
            یادآوری {toFaDigits(jobsResult[2] ?? 0)} · پایان اشتراک {toFaDigits(jobsResult[3] ?? 0)}
          </CardMuted>
        </Card>
      )}

      {escrows.length === 0 ? (
        <Card><CardMuted>هنوز وجه امانی ثبت نشده است.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {escrows.map((e) => (
            <Card key={e.id} className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="flex items-center gap-2 font-semibold">
                  {formatToman(Number(e.amount))}
                  <Badge tone={stateTone(e.state)}>{ESCROW_STATE_FA[e.state] ?? e.state}</Badge>
                </p>
                <p className="text-xs text-[var(--color-muted)]">
                  خریدار {e.buyer_name ?? "—"} · فروشنده {e.seller_name ?? "—"}
                  {e.auto_release_at && <> · آزادسازی خودکار: <span dir="ltr">{e.auto_release_at.slice(0, 16)}</span></>}
                </p>
                <Link href={`/deals/${e.deal_id}`} className="text-xs text-[var(--color-primary)]">مشاهدهٔ معامله ←</Link>
              </div>
              {["funded", "in_inspection"].includes(e.state) && (
                <div className="flex gap-2">
                  {e.deal_state === "waiting_buyer_confirmation" && (
                    <form action={adminEscrowAction}>
                      <input type="hidden" name="deal_id" value={e.deal_id} />
                      <input type="hidden" name="op" value="release" />
                      <Button variant="accent" size="sm" type="submit">آزادسازی به فروشنده</Button>
                    </form>
                  )}
                  <form action={adminEscrowAction}>
                    <input type="hidden" name="deal_id" value={e.deal_id} />
                    <input type="hidden" name="op" value="refund" />
                    <Button variant="outline" size="sm" type="submit" className="text-[var(--color-danger)]">استرداد به خریدار</Button>
                  </form>
                </div>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
