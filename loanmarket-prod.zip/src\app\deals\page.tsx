import Link from "next/link";
import { requireActiveUser } from "@/lib/auth";
import { getMyDeals } from "@/services/deals";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { formatToman, formatTomanCompact } from "@/lib/persian";
import { DEAL_STATE_FA, dealStateTone } from "./state";

export const dynamic = "force-dynamic";

export default async function DealsPage() {
  const user = await requireActiveUser();
  const deals = await getMyDeals(user.id);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">معاملات من</h1>
      {deals.length === 0 ? (
        <Card><CardMuted>هنوز معامله‌ای ندارید. از <Link href="/marketplace" className="text-[var(--color-primary)]">بازار</Link> شروع کنید.</CardMuted></Card>
      ) : (
        <div className="space-y-3">
          {deals.map((d) => (
            <Link key={d.id} href={`/deals/${d.id}`}>
              <Card className="flex flex-wrap items-center justify-between gap-3 transition-colors hover:border-[var(--color-primary)]">
                <div>
                  <p className="font-semibold">{d.loan_type_name} <span className="text-sm text-[var(--color-muted)]">· {d.bank_name}</span></p>
                  <p className="text-sm text-[var(--color-muted)]">
                    {d.role === "buyer" ? "خرید از" : "فروش به"} {d.counterparty} · ارزش {formatTomanCompact(d.loan_value)}
                  </p>
                </div>
                <div className="flex items-center gap-3">
                  <span className="font-medium text-[var(--color-accent)]">{formatToman(d.loan_price)}</span>
                  <Badge tone={dealStateTone(d.state)}>{DEAL_STATE_FA[d.state] ?? d.state}</Badge>
                </div>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
