import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { requireSectionPage } from "../guard";
import { formatDateTimeFa } from "@/lib/persian";

export const dynamic = "force-dynamic";

type AuditRow = {
  id: string; actor_name: string | null; actor_mobile: string | null;
  action: string; entity: string | null; entity_id: string | null;
  detail: Record<string, unknown>; created_at: string;
};

// money/ledger events vs administrative events get different tones
const tone = (action: string) =>
  action.startsWith("ledger.") ? "accent"
    : action.includes("reject") || action.includes("refund") ? "danger"
    : "warning";

export default async function AdminAuditPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const admin = await requireSectionPage("audit");
  const { q } = await searchParams;
  const filter = (q ?? "").trim();

  const rows = (await withUser(admin.id, (tx) =>
    tx.execute<AuditRow>(sql`
      select a.id, u.display_name as actor_name, u.mobile as actor_mobile,
             a.action, a.entity, a.entity_id, a.detail, a.created_at::text
      from audit_log a
      left join users u on u.id = a.actor_id
      ${filter ? sql`where a.action ilike ${"%" + filter + "%"} or a.entity_id ilike ${"%" + filter + "%"}` : sql``}
      order by a.created_at desc
      limit 200`),
  )) as AuditRow[];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">گزارش حسابرسی</h1>
      <CardMuted>
        ثبت تغییرناپذیر اقدامات مدیریتی و همهٔ تراکنش‌های مالی. این رکوردها فقط‌خواندنی هستند و قابل ویرایش یا حذف نیستند (M13).
      </CardMuted>

      <form method="get">
        <input
          name="q" defaultValue={filter} placeholder="جستجو بر اساس اقدام یا شناسه…"
          className="w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)] sm:w-80"
        />
      </form>

      {rows.length === 0 ? (
        <Card><CardMuted>رکوردی یافت نشد.</CardMuted></Card>
      ) : (
        <Card className="space-y-2">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[var(--color-muted)]">
                <tr className="border-b border-[var(--color-border)] text-start">
                  <th className="py-2 text-start">زمان</th>
                  <th className="py-2 text-start">کاربر</th>
                  <th className="py-2 text-start">اقدام</th>
                  <th className="py-2 text-start">موجودیت</th>
                  <th className="py-2 text-start">جزئیات</th>
                </tr>
              </thead>
              <tbody>
                {rows.map((r) => (
                  <tr key={r.id} className="border-b border-[var(--color-border)]/40 align-top">
                    <td className="py-2 whitespace-nowrap text-xs text-[var(--color-muted)]">{formatDateTimeFa(r.created_at)}</td>
                    <td className="py-2 text-xs">{r.actor_name ?? r.actor_mobile ?? "سیستم"}</td>
                    <td className="py-2"><Badge tone={tone(r.action)}>{r.action}</Badge></td>
                    <td className="py-2 text-xs" dir="ltr">{r.entity}{r.entity_id && r.entity_id !== "*" ? `:${r.entity_id.slice(0, 8)}` : ""}</td>
                    <td className="py-2 text-xs text-[var(--color-muted)]" dir="ltr">
                      {Object.keys(r.detail ?? {}).length ? JSON.stringify(r.detail) : "—"}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}
