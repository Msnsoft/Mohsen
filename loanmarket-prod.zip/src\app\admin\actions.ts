"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser, type CurrentUser } from "@/lib/auth";
import { canAccessSection, GRANTABLE_ROLES } from "@/lib/rbac";

async function requireSection(section: string): Promise<CurrentUser> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  if (!user.isAdmin || !canAccessSection(user.roles, section)) redirect("/admin");
  return user;
}

const num = (formData: FormData, k: string) =>
  Number(String(formData.get(k) ?? "").replace(/[^\d.]/g, ""));

/** M13: record an admin action in the immutable audit log. */
async function logAudit(actorId: string, action: string, entity: string, entityId: string, detail: Record<string, unknown> = {}) {
  await withUser(actorId, (tx) =>
    tx.execute(sql`select audit(${actorId}::uuid, ${action}, ${entity}, ${entityId}, ${JSON.stringify(detail)}::jsonb)`),
  );
}

// ---- Listing moderation (M04) -----------------------------------------
export async function moderateListingAction(formData: FormData) {
  const user = await requireSection("listings");
  const id = String(formData.get("post_id") ?? "");
  const decision = String(formData.get("decision") ?? ""); // approve | reject
  if (!["approve", "reject"].includes(decision)) return;
  const status = decision === "approve" ? "active" : "rejected";

  await withUser(user.id, async (tx) => {
    const rows = await tx.execute<{ user_id: string }>(sql`
      update loan_posts set status = ${status}
      where id = ${id} and status = 'pending_review' returning user_id`);
    const ownerId = rows[0]?.user_id;
    if (ownerId) {
      await tx.execute(sql`
        insert into notifications(user_id, title, body) values (${ownerId},
          ${decision === "approve" ? "آگهی شما تأیید شد" : "آگهی شما رد شد"},
          ${decision === "approve"
            ? "آگهی شما پس از بررسی تأیید و در بازار منتشر شد."
            : "آگهی شما در بررسی رد شد. برای جزئیات با پشتیبانی در تماس باشید."})`);
    }
  });
  await logAudit(user.id, `listing.${decision}`, "loan_post", id);
  revalidatePath("/admin/listings");
  revalidatePath("/marketplace");
}

// ---- Users & roles (M01) ----------------------------------------------
export async function setUserStatusAction(formData: FormData) {
  const user = await requireSection("users");
  const id = String(formData.get("user_id") ?? "");
  const status = String(formData.get("status") ?? "");
  if (!["active", "suspended"].includes(status) || id === user.id) return;
  await withUser(user.id, (tx) =>
    tx.execute(sql`update users set status = ${status} where id = ${id}`),
  );
  revalidatePath("/admin/users");
}

export async function grantRoleAction(formData: FormData) {
  const user = await requireSection("users");
  // role management is super-admin only (service-layer gate on top of RLS)
  if (!user.roles.includes("super_admin")) return;
  const id = String(formData.get("user_id") ?? "");
  const role = String(formData.get("role") ?? "");
  if (!GRANTABLE_ROLES.includes(role)) return;
  await withUser(user.id, (tx) =>
    tx.execute(sql`insert into user_roles(user_id, role) values (${id}, ${role}) on conflict do nothing`),
  );
  revalidatePath("/admin/users");
}

export async function revokeRoleAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user?.roles.includes("super_admin")) return;
  const id = String(formData.get("user_id") ?? "");
  const role = String(formData.get("role") ?? "");
  if (role === "user" || (id === user.id && role === "super_admin")) return; // never orphan the bootstrap
  await withUser(user.id, (tx) =>
    tx.execute(sql`delete from user_roles where user_id = ${id} and role = ${role}`),
  );
  revalidatePath("/admin/users");
}

// ---- Loan types (M04 builder) ------------------------------------------
export async function saveLoanTypeAction(formData: FormData) {
  const user = await requireSection("loan_types");
  const id = String(formData.get("id") ?? "");
  const name = String(formData.get("name") ?? "").trim();
  if (!name) return;
  const bank = String(formData.get("bank_name") ?? "").trim() || null;
  const fixedRate = String(formData.get("fixed_rate") ?? "").trim();
  const rateEditable = formData.get("rate_editable") === "on";
  const duration = num(formData, "default_duration_months") || null;
  const minPpm = num(formData, "min_price_per_million") * 10 || null; // toman → IRR
  const maxPpm = num(formData, "max_price_per_million") * 10 || null;
  const active = formData.get("active") === "on";
  const rate = fixedRate ? Number(fixedRate) : null;

  await withUser(user.id, (tx) =>
    id
      ? tx.execute(sql`
          update loan_types set name = ${name}, bank_name = ${bank}, fixed_rate = ${rate},
            rate_editable = ${rateEditable}, default_duration_months = ${duration},
            min_price_per_million = ${minPpm}, max_price_per_million = ${maxPpm}, active = ${active}
          where id = ${id}`)
      : tx.execute(sql`
          insert into loan_types(name, bank_name, fixed_rate, rate_editable,
            default_duration_months, min_price_per_million, max_price_per_million, active)
          values (${name}, ${bank}, ${rate}, ${rateEditable}, ${duration}, ${minPpm}, ${maxPpm}, ${active})`),
  );
  revalidatePath("/admin/loan-types");
  revalidatePath("/panel/loans/new");
}

// ---- B: loan-type custom fields (per audience) --------------------------
const FIELD_TYPES = ["text", "number", "select", "bool"];
const AUDIENCES = ["buyer", "seller", "both"];

export async function saveLoanTypeFieldAction(formData: FormData) {
  const user = await requireSection("loan_types");
  const id = String(formData.get("id") ?? "");
  const loanTypeId = String(formData.get("loan_type_id") ?? "");
  const key = String(formData.get("key") ?? "").trim().replace(/\s+/g, "_");
  const label = String(formData.get("label") ?? "").trim();
  if (!loanTypeId || !key || !label) return;
  const fieldType = FIELD_TYPES.includes(String(formData.get("field_type"))) ? String(formData.get("field_type")) : "text";
  const audience = AUDIENCES.includes(String(formData.get("audience"))) ? String(formData.get("audience")) : "both";
  const required = formData.get("required") === "on";
  const active = formData.get("active") === "on";
  const sort = num(formData, "sort") || 0;
  // options: newline- or comma-separated for select fields
  const options = String(formData.get("options") ?? "")
    .split(/[\n,]+/).map((s) => s.trim()).filter(Boolean);
  const optionsJson = JSON.stringify(options);

  await withUser(user.id, (tx) =>
    id
      ? tx.execute(sql`
          update loan_type_fields set key = ${key}, label = ${label}, field_type = ${fieldType},
            audience = ${audience}, required = ${required}, active = ${active}, sort = ${sort},
            options = ${optionsJson}::jsonb
          where id = ${id} and loan_type_id = ${loanTypeId}`)
      : tx.execute(sql`
          insert into loan_type_fields (loan_type_id, key, label, field_type, audience, required, active, sort, options)
          values (${loanTypeId}, ${key}, ${label}, ${fieldType}, ${audience}, ${required}, ${active}, ${sort}, ${optionsJson}::jsonb)
          on conflict (loan_type_id, key) do update set
            label = excluded.label, field_type = excluded.field_type, audience = excluded.audience,
            required = excluded.required, active = excluded.active, sort = excluded.sort, options = excluded.options`),
  );
  revalidatePath("/admin/loan-types");
  revalidatePath("/panel/loans/new");
}

export async function deleteLoanTypeFieldAction(formData: FormData) {
  const user = await requireSection("loan_types");
  const id = String(formData.get("id") ?? "");
  if (!id) return;
  await withUser(user.id, (tx) => tx.execute(sql`delete from loan_type_fields where id = ${id}`));
  revalidatePath("/admin/loan-types");
  revalidatePath("/panel/loans/new");
}

// ---- Escrow console (M08) -----------------------------------------------
export async function adminEscrowAction(formData: FormData) {
  const user = await requireSection("escrows");
  const dealId = String(formData.get("deal_id") ?? "");
  const op = String(formData.get("op") ?? ""); // release | refund
  await withUser(user.id, (tx) =>
    op === "release"
      ? tx.execute(sql`select deal_buyer_confirm(${dealId}::uuid, ${user.id}::uuid)`)
      : tx.execute(sql`select deal_refund(${dealId}::uuid, ${user.id}::uuid, 'admin refund from escrow console')`),
  );
  await logAudit(user.id, `escrow.${op}`, "deal", dealId);
  revalidatePath("/admin/escrows");
  revalidatePath("/admin/deals");
}

// ---- Commission rules (M09) ----------------------------------------------
export async function saveCommissionRuleAction(formData: FormData) {
  const user = await requireSection("commissions");
  const id = String(formData.get("id") ?? "");
  const percent = String(formData.get("percent_rate") ?? "").trim();
  const baseFee = num(formData, "base_fee") * 10 || 0;
  const tax = String(formData.get("tax_rate") ?? "").trim();
  const active = formData.get("active") === "on";
  await withUser(user.id, (tx) =>
    tx.execute(sql`
      update commission_rules set
        percent_rate = ${percent ? Number(percent) : null},
        base_fee = ${baseFee}, tax_rate = ${tax ? Number(tax) : 0}, active = ${active}
      where id = ${id}`),
  );
  revalidatePath("/admin/commissions");
}

// ---- Membership plans (M19) ------------------------------------------------
const ENTITLEMENTS = ["calculator", "pricing_advice", "sms_alerts", "auto_match", "history_charts"];

export async function savePlanAction(formData: FormData) {
  const user = await requireSection("plans");
  const id = String(formData.get("id") ?? "");
  const price = num(formData, "price") * 10; // toman → IRR
  const period = num(formData, "period_days") || 30;
  const active = formData.get("active") === "on";
  const ents = ENTITLEMENTS.filter((e) => formData.get(`ent_${e}`) === "on");

  await withUser(user.id, async (tx) => {
    await tx.execute(sql`
      update subscription_plans set price = ${price}, period_days = ${period}, active = ${active}
      where id = ${id}`);
    await tx.execute(sql`delete from plan_entitlements where plan_id = ${id}`);
    for (const e of ents) {
      await tx.execute(sql`insert into plan_entitlements(plan_id, entitlement) values (${id}, ${e})`);
    }
  });
  revalidatePath("/admin/plans");
  revalidatePath("/membership");
}

// ---- Ticketing (M12, Zendesk model) ---------------------------------------
const TICKET_STATUSES = ["new", "open", "pending", "on_hold", "solved", "closed"];

export async function adminTicketReplyAction(formData: FormData) {
  const user = await requireSection("tickets");
  const ticketId = String(formData.get("ticket_id") ?? "");
  const body = String(formData.get("body") ?? "").trim();
  const isInternal = formData.get("is_internal") === "on";
  if (!body) return;
  await withUser(user.id, async (tx) => {
    await tx.execute(sql`
      insert into ticket_messages(ticket_id, author_id, body, is_internal)
      values (${ticketId}, ${user.id}, ${body}, ${isInternal})`);
    if (!isInternal) {
      // public agent reply → ball in the user's court (Zendesk: pending)
      await tx.execute(sql`
        update tickets set status = 'pending', assignee_id = coalesce(assignee_id, ${user.id})
        where id = ${ticketId} and status in ('new','open')`);
      const owners = await tx.execute<{ user_id: string }>(
        sql`select user_id from tickets where id = ${ticketId}`,
      );
      if (owners[0]) {
        await tx.execute(sql`
          insert into notifications(user_id, title, body)
          values (${owners[0].user_id}, 'پاسخ جدید پشتیبانی', 'تیکت شما پاسخ جدیدی دارد.')`);
      }
    }
  });
  revalidatePath(`/admin/tickets/${ticketId}`);
  revalidatePath("/admin/tickets");
}

export async function adminTicketStatusAction(formData: FormData) {
  const user = await requireSection("tickets");
  const ticketId = String(formData.get("ticket_id") ?? "");
  const status = String(formData.get("status") ?? "");
  if (!TICKET_STATUSES.includes(status)) return;
  await withUser(user.id, (tx) =>
    tx.execute(sql`update tickets set status = ${status} where id = ${ticketId}`),
  );
  revalidatePath(`/admin/tickets/${ticketId}`);
  revalidatePath("/admin/tickets");
}

export async function adminTicketAssignAction(formData: FormData) {
  const user = await requireSection("tickets");
  const ticketId = String(formData.get("ticket_id") ?? "");
  await withUser(user.id, (tx) =>
    tx.execute(sql`update tickets set assignee_id = ${user.id} where id = ${ticketId}`),
  );
  revalidatePath(`/admin/tickets/${ticketId}`);
  revalidatePath("/admin/tickets");
}

// ---- CMS (M15) --------------------------------------------------------------
async function reloadPublic() {
  revalidatePath("/", "layout");
  revalidatePath("/faq");
}

export async function toggleWidgetAction(formData: FormData) {
  const user = await requireSection("cms");
  const key = String(formData.get("key") ?? "");
  await withUser(user.id, (tx) =>
    tx.execute(sql`update cms_widgets set enabled = not enabled where key = ${key}`),
  );
  await reloadPublic();
}

export async function saveFaqAction(formData: FormData) {
  const user = await requireSection("cms");
  const id = String(formData.get("id") ?? "");
  const question = String(formData.get("question") ?? "").trim();
  const answer = String(formData.get("answer") ?? "").trim();
  const sort = Number(String(formData.get("sort") ?? "0").replace(/[^\d]/g, "")) || 0;
  const published = formData.get("published") === "on";
  if (!question || !answer) return;
  await withUser(user.id, (tx) =>
    id
      ? tx.execute(sql`update cms_faqs set question=${question}, answer=${answer}, sort=${sort}, published=${published} where id=${id}`)
      : tx.execute(sql`insert into cms_faqs(question, answer, sort, published) values (${question}, ${answer}, ${sort}, ${published})`),
  );
  await reloadPublic();
  revalidatePath("/admin/cms");
}

export async function deleteFaqAction(formData: FormData) {
  const user = await requireSection("cms");
  const id = String(formData.get("id") ?? "");
  await withUser(user.id, (tx) => tx.execute(sql`delete from cms_faqs where id = ${id}`));
  await reloadPublic();
  revalidatePath("/admin/cms");
}

const STAT_METRICS = ["users", "active_listings", "completed_deals", "volume", "loan_types"];

/** Edit the landing stats widget: title + which metrics to show (M15 editable landing). */
export async function saveStatsWidgetAction(formData: FormData) {
  const user = await requireSection("cms");
  const title = String(formData.get("title") ?? "").trim();
  const metrics = STAT_METRICS.filter((m) => formData.get(`metric_${m}`) === "on");
  const payload = JSON.stringify({ title, metrics });
  await withUser(user.id, (tx) =>
    tx.execute(sql`update cms_widgets set payload = ${payload}::jsonb where key = 'stats'`),
  );
  await reloadPublic();
  revalidatePath("/admin/cms");
}

// req. K: editable hero content (title, subtitle, eyebrow, image)
export async function saveHeroWidgetAction(formData: FormData) {
  const user = await requireSection("cms");
  const payload = JSON.stringify({
    eyebrow: String(formData.get("eyebrow") ?? "").trim(),
    title: String(formData.get("title") ?? "").trim(),
    subtitle: String(formData.get("subtitle") ?? "").trim(),
    image_url: String(formData.get("image_url") ?? "").trim(),
  });
  await withUser(user.id, (tx) =>
    tx.execute(sql`update cms_widgets set payload = ${payload}::jsonb where key = 'hero'`),
  );
  await reloadPublic();
  revalidatePath("/admin/cms");
}

export async function saveMenuItemAction(formData: FormData) {
  const user = await requireSection("cms");
  const id = String(formData.get("id") ?? "");
  const location = String(formData.get("location") ?? "footer");
  const label = String(formData.get("label") ?? "").trim();
  const url = String(formData.get("url") ?? "").trim();
  const sort = Number(String(formData.get("sort") ?? "0").replace(/[^\d]/g, "")) || 0;
  const visible = formData.get("visible") === "on";
  if (!label || !url || !["header", "footer", "landing"].includes(location)) return;
  await withUser(user.id, (tx) =>
    id
      ? tx.execute(sql`update cms_menu_items set location=${location}, label=${label}, url=${url}, sort=${sort}, visible=${visible} where id=${id}`)
      : tx.execute(sql`insert into cms_menu_items(location, label, url, sort, visible) values (${location}, ${label}, ${url}, ${sort}, ${visible})`),
  );
  await reloadPublic();
  revalidatePath("/admin/cms");
}

export async function deleteMenuItemAction(formData: FormData) {
  const user = await requireSection("cms");
  const id = String(formData.get("id") ?? "");
  await withUser(user.id, (tx) => tx.execute(sql`delete from cms_menu_items where id = ${id}`));
  await reloadPublic();
  revalidatePath("/admin/cms");
}

export async function savePageAction(formData: FormData) {
  const user = await requireSection("cms");
  const id = String(formData.get("id") ?? "");
  const slug = String(formData.get("slug") ?? "").trim().replace(/[^a-z0-9-]/gi, "");
  const title = String(formData.get("title") ?? "").trim();
  const body = String(formData.get("body") ?? "");
  const published = formData.get("published") === "on";
  if (!slug || !title) return;
  await withUser(user.id, (tx) =>
    id
      ? tx.execute(sql`update cms_pages set slug=${slug}, title=${title}, body=${body}, published=${published}, updated_at=now() where id=${id}`)
      : tx.execute(sql`insert into cms_pages(slug, title, body, published) values (${slug}, ${title}, ${body}, ${published})`),
  );
  await reloadPublic();
  revalidatePath(`/p/${slug}`);
  revalidatePath("/admin/cms");
}

// ---- Scheduled jobs: manual run (Phase 2 worker; admin trigger) ----------
export async function runDueJobsAction() {
  const user = await requireSection("escrows");
  const rows = (await withUser(user.id, (tx) =>
    tx.execute<{ auto_released: number; seller_timeouts: number; reminders: number; expired: number }>(
      sql`select * from run_due_jobs()`,
    ),
  )) as { auto_released: number; seller_timeouts: number; reminders: number; expired: number }[];
  const r = rows[0];
  revalidatePath("/admin/escrows");
  revalidatePath("/admin/deals");
  redirect(`/admin/escrows?jobs=${r?.auto_released ?? 0}-${r?.seller_timeouts ?? 0}-${r?.reminders ?? 0}-${r?.expired ?? 0}`);
}

// ---- Configuration (M16) ------------------------------------------------------
// Typed config keys editable from the panel; value is stored as jsonb.
const CONFIG_KEYS: Record<string, "string" | "int" | "bool"> = {
  "marketplace.listing_approval_mode": "string",
  "ui.default_theme": "string",
  "escrow.mode": "string",
  "escrow.api_url": "string",
  "escrow.inspection_hours": "int",
  "escrow.seller_timeout_hours": "int",
  "membership.default_plan_key": "string",
  "membership.default_duration_days": "int",
  "membership.grace_days": "int",
  "otp.ttl_minutes": "int",
  "commission.prorate_partial_band": "bool",
  // Increment 5: branding (X), market-average toggle (N), contact info (AA)
  "cms.site_name": "string",
  "cms.logo_url": "string",
  "analysis.show_market_average": "bool",
  "notifications.sms_enabled": "bool",
  "contact.phone": "string",
  "contact.email": "string",
  "contact.address": "string",
};

export async function saveConfigAction(formData: FormData) {
  const user = await requireSection("config");
  await withUser(user.id, async (tx) => {
    for (const [key, kind] of Object.entries(CONFIG_KEYS)) {
      const raw = formData.get(`cfg:${key}`);
      if (raw === null) continue;
      const v = String(raw);
      if (kind === "int") {
        const n = Number(v.replace(/[^\d]/g, ""));
        if (!Number.isFinite(n)) continue;
        await tx.execute(sql`update config set value = to_jsonb(${n}::int), updated_at = now() where key = ${key}`);
      } else if (kind === "bool") {
        await tx.execute(sql`update config set value = to_jsonb(${v === "on" || v === "true"}::bool), updated_at = now() where key = ${key}`);
      } else {
        await tx.execute(sql`update config set value = to_jsonb(${v}::text), updated_at = now() where key = ${key}`);
      }
    }
    // req. Q: hidden workflow stages (multi-checkbox → jsonb array)
    if (formData.has("cfg:deal.hidden_stages.present")) {
      const hidden = formData.getAll("cfg:deal.hidden_stages").map(String).filter(Boolean);
      await tx.execute(sql`
        insert into config(key, value) values ('deal.hidden_stages', ${JSON.stringify(hidden)}::jsonb)
        on conflict (key) do update set value = excluded.value, updated_at = now()`);
    }
  });
  await logAudit(user.id, "config.update", "config", "*");
  revalidatePath("/admin/config");
  revalidatePath("/", "layout");
}

// ---- Increment 5: label rules (req. M) ------------------------------
export async function saveLabelRuleAction(formData: FormData) {
  const admin = await requireSection("labels");
  const key = String(formData.get("key") ?? "").trim().toLowerCase().replace(/\s+/g, "_");
  const label = String(formData.get("label") ?? "").trim();
  const tone = String(formData.get("tone") ?? "warning");
  const field = String(formData.get("field") ?? "rate");
  const op = String(formData.get("op") ?? ">=");
  const threshold = Number(String(formData.get("threshold") ?? "0").replace(/[^\d.\-]/g, ""));
  if (!key || !label) return;
  await withUser(admin.id, (tx) =>
    tx.execute(sql`
      insert into label_rules(key, label, tone, field, op, threshold)
      values (${key}, ${label}, ${tone}, ${field}, ${op}, ${threshold})
      on conflict (key) do update set label = excluded.label, tone = excluded.tone,
        field = excluded.field, op = excluded.op, threshold = excluded.threshold`),
  );
  revalidatePath("/admin/labels");
  revalidatePath("/marketplace");
}

export async function toggleLabelRuleAction(formData: FormData) {
  const admin = await requireSection("labels");
  const key = String(formData.get("key") ?? "");
  await withUser(admin.id, (tx) =>
    tx.execute(sql`update label_rules set active = not active where key = ${key}`),
  );
  revalidatePath("/admin/labels");
  revalidatePath("/marketplace");
}

export async function deleteLabelRuleAction(formData: FormData) {
  const admin = await requireSection("labels");
  const key = String(formData.get("key") ?? "");
  await withUser(admin.id, (tx) => tx.execute(sql`delete from label_rules where key = ${key}`));
  revalidatePath("/admin/labels");
  revalidatePath("/marketplace");
}

// ---- Increment 5: withdrawal decisions (req. I) ---------------------
export async function decideWithdrawalAction(formData: FormData) {
  const admin = await requireSection("withdrawals");
  const id = String(formData.get("request_id") ?? "");
  const approve = String(formData.get("decision") ?? "") === "approve";
  const note = String(formData.get("note") ?? "").trim() || null;
  await withUser(admin.id, (tx) =>
    tx.execute(sql`select decide_withdrawal(${id}::uuid, ${admin.id}::uuid, ${approve}, ${note})`),
  );
  await logAudit(admin.id, `withdrawal.${approve ? "approve" : "reject"}`, "withdrawal_request", id, { note });
  revalidatePath("/admin/withdrawals");
}

// ---- Increment 5: special-user toggle (req. E) ----------------------
export async function toggleSpecialUserAction(formData: FormData) {
  const admin = await requireSection("users");
  const userId = String(formData.get("user_id") ?? "");
  await withUser(admin.id, (tx) =>
    tx.execute(sql`update users set is_special = not is_special where id = ${userId}`),
  );
  revalidatePath("/admin/users");
}
