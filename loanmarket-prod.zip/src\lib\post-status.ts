// Loan post (listing) status display — statuses per M04 / 01_schema.sql.
export const POST_STATUS_FA: Record<string, string> = {
  draft: "پیش‌نویس",
  pending_review: "در انتظار بررسی",
  active: "فعال",
  reserved: "رزرو شده",
  sold: "فروخته‌شده",
  rejected: "رد شده",
  cancelled: "لغو شده",
};

type Tone = "default" | "accent" | "warning" | "danger" | "muted";
export function postStatusTone(status: string): Tone {
  switch (status) {
    case "active": return "accent";
    case "pending_review": return "warning";
    case "rejected": return "danger";
    case "sold": return "default";
    case "draft":
    case "reserved":
    case "cancelled":
    default: return "muted";
  }
}

/** Statuses the owner may still cancel from the panel. */
export const CANCELLABLE_STATUSES = ["draft", "pending_review", "active"];
