import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { requireSectionPage } from "../guard";
import { STAT_METRIC_FA } from "@/lib/cms";
import {
  toggleWidgetAction, saveFaqAction, deleteFaqAction,
  saveMenuItemAction, deleteMenuItemAction, savePageAction, saveStatsWidgetAction, saveHeroWidgetAction,
} from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

const WIDGET_FA: Record<string, string> = {
  hero: "بخش معرفی (Hero)",
  features: "کارت‌های ویژگی‌ها",
  featured_listings: "آگهی‌های منتخب",
  faq_section: "بخش سوالات متداول",
};

export default async function AdminCmsPage() {
  const admin = await requireSectionPage("cms");

  const data = await withUser(admin.id, async (tx) => {
    const widgets = await tx.execute<{ key: string; enabled: boolean; sort: number; payload: Record<string, unknown> }>(
      sql`select key, enabled, sort, payload from cms_widgets order by sort`,
    );
    const faqs = await tx.execute<{ id: string; question: string; answer: string; sort: number; published: boolean }>(
      sql`select id, question, answer, sort, published from cms_faqs order by sort`,
    );
    const menu = await tx.execute<{ id: string; location: string; label: string; url: string; sort: number; visible: boolean }>(
      sql`select id, location, label, url, sort, visible from cms_menu_items order by location, sort`,
    );
    const pages = await tx.execute<{ id: string; slug: string; title: string; body: string; published: boolean }>(
      sql`select id, slug, title, body, published from cms_pages order by slug`,
    );
    return { widgets, faqs, menu, pages };
  });

  return (
    <div className="space-y-8">
      <h1 className="text-2xl font-bold">مدیریت محتوا (CMS)</h1>
      <CardMuted>تغییرات بلافاصله روی سایت عمومی اعمال می‌شوند.</CardMuted>

      {/* Widgets */}
      <section className="space-y-3">
        <CardTitle>بخش‌های صفحهٔ اصلی</CardTitle>
        <div className="grid gap-3 sm:grid-cols-2">
          {data.widgets.map((w) => (
            <Card key={w.key} className="flex items-center justify-between gap-3">
              <span className="text-sm">{WIDGET_FA[w.key] ?? w.key}</span>
              <form action={toggleWidgetAction}>
                <input type="hidden" name="key" value={w.key} />
                <Button size="sm" variant={w.enabled ? "accent" : "outline"} type="submit">
                  {w.enabled ? "روشن" : "خاموش"}
                </Button>
              </form>
            </Card>
          ))}
        </div>
      </section>

      {/* Hero content editor (req. K) */}
      <section className="space-y-3">
        <CardTitle>محتوای بخش معرفی (Hero)</CardTitle>
        <CardMuted>عنوان، زیرعنوان، برچسب بالا و تصویر بخش معرفی صفحهٔ اصلی را ویرایش کنید. دکمه‌های فراخوان از «منوها → صفحهٔ اصلی» تنظیم می‌شوند.</CardMuted>
        <Card>
          {(() => {
            const hero = data.widgets.find((w) => w.key === "hero");
            const p = (hero?.payload ?? {}) as { eyebrow?: string; title?: string; subtitle?: string; image_url?: string };
            return (
              <form action={saveHeroWidgetAction} className="space-y-3">
                <label className="space-y-1 text-xs text-[var(--color-muted)]">برچسب بالا (اختیاری)
                  <input name="eyebrow" defaultValue={p.eyebrow ?? ""} className={inputCls} />
                </label>
                <label className="space-y-1 text-xs text-[var(--color-muted)]">عنوان اصلی
                  <input name="title" defaultValue={p.title ?? ""} className={inputCls} />
                </label>
                <label className="space-y-1 text-xs text-[var(--color-muted)]">زیرعنوان
                  <textarea name="subtitle" defaultValue={p.subtitle ?? ""} rows={2} className={inputCls} />
                </label>
                <label className="space-y-1 text-xs text-[var(--color-muted)]">آدرس تصویر (URL — اختیاری)
                  <input name="image_url" defaultValue={p.image_url ?? ""} dir="ltr" placeholder="https://…/hero.jpg" className={inputCls} />
                </label>
                <Button size="sm" type="submit">ذخیرهٔ بخش معرفی</Button>
              </form>
            );
          })()}
        </Card>
      </section>

      {/* Landing statistics widget settings */}
      <section className="space-y-3">
        <CardTitle>آمار صفحهٔ اصلی</CardTitle>
        <CardMuted>عنوان بخش آمار و شاخص‌هایی که روی صفحهٔ اصلی نمایش داده می‌شوند را انتخاب کنید (داده‌ها زنده هستند).</CardMuted>
        <Card>
          {(() => {
            const stats = data.widgets.find((w) => w.key === "stats");
            const payload = (stats?.payload ?? {}) as { title?: string; metrics?: string[] };
            const selected = payload.metrics ?? ["users", "active_listings", "completed_deals", "volume"];
            return (
              <form action={saveStatsWidgetAction} className="space-y-3">
                <label className="space-y-1 text-xs text-[var(--color-muted)]">
                  عنوان بخش
                  <input name="title" defaultValue={payload.title ?? ""} className={inputCls} />
                </label>
                <div className="flex flex-wrap gap-x-5 gap-y-2 text-sm">
                  {Object.entries(STAT_METRIC_FA).map(([key, label]) => (
                    <label key={key} className="flex items-center gap-1.5">
                      <input type="checkbox" name={`metric_${key}`} defaultChecked={selected.includes(key)} />
                      {label}
                    </label>
                  ))}
                </div>
                <Button size="sm" type="submit">ذخیرهٔ آمار</Button>
              </form>
            );
          })()}
        </Card>
      </section>

      {/* Menu items */}
      <section className="space-y-3">
        <CardTitle>منوها و لینک‌ها</CardTitle>
        <CardMuted>محل «صفحهٔ اصلی» = دکمه‌های فراخوان (CTA) در بالای صفحهٔ اصلی.</CardMuted>
        {data.menu.map((m) => (
          <Card key={m.id}>
            <form action={saveMenuItemAction} className="grid items-end gap-3 sm:grid-cols-5">
              <input type="hidden" name="id" value={m.id} />
              <label className="space-y-1 text-xs text-[var(--color-muted)]">محل
                <select name="location" defaultValue={m.location} className={inputCls}>
                  <option value="header">سربرگ</option>
                  <option value="footer">پاورقی</option>
                  <option value="landing">صفحهٔ اصلی (CTA)</option>
                </select>
              </label>
              <label className="space-y-1 text-xs text-[var(--color-muted)]">عنوان
                <input name="label" defaultValue={m.label} className={inputCls} />
              </label>
              <label className="space-y-1 text-xs text-[var(--color-muted)]">لینک
                <input name="url" defaultValue={m.url} dir="ltr" className={inputCls} />
              </label>
              <label className="flex items-center gap-1.5 text-sm">
                <input type="checkbox" name="visible" defaultChecked={m.visible} /> نمایش
              </label>
              <div className="flex gap-2">
                <Button size="sm" type="submit">ذخیره</Button>
              </div>
            </form>
            <form action={deleteMenuItemAction} className="mt-2">
              <input type="hidden" name="id" value={m.id} />
              <Button size="sm" variant="ghost" type="submit" className="text-[var(--color-danger)]">حذف</Button>
            </form>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardTitle className="mb-3">+ لینک جدید</CardTitle>
          <form action={saveMenuItemAction} className="grid items-end gap-3 sm:grid-cols-5">
            <label className="space-y-1 text-xs text-[var(--color-muted)]">محل
              <select name="location" defaultValue="footer" className={inputCls}>
                <option value="header">سربرگ</option>
                <option value="footer">پاورقی</option>
                <option value="landing">صفحهٔ اصلی (CTA)</option>
              </select>
            </label>
            <label className="space-y-1 text-xs text-[var(--color-muted)]">عنوان
              <input name="label" className={inputCls} />
            </label>
            <label className="space-y-1 text-xs text-[var(--color-muted)]">لینک
              <input name="url" dir="ltr" placeholder="/p/about" className={inputCls} />
            </label>
            <label className="flex items-center gap-1.5 text-sm">
              <input type="checkbox" name="visible" defaultChecked /> نمایش
            </label>
            <Button size="sm" type="submit">افزودن</Button>
          </form>
        </Card>
      </section>

      {/* FAQs */}
      <section className="space-y-3">
        <CardTitle>سوالات متداول</CardTitle>
        {data.faqs.map((f) => (
          <Card key={f.id} className="space-y-2">
            <form action={saveFaqAction} className="space-y-2">
              <input type="hidden" name="id" value={f.id} />
              <input name="question" defaultValue={f.question} className={inputCls} />
              <textarea name="answer" defaultValue={f.answer} rows={2} className={inputCls} />
              <div className="flex flex-wrap items-center gap-3">
                <label className="space-y-1 text-xs text-[var(--color-muted)]">ترتیب
                  <input name="sort" defaultValue={f.sort} dir="ltr" className="w-20 rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2 py-1 text-sm" />
                </label>
                <label className="flex items-center gap-1.5 text-sm">
                  <input type="checkbox" name="published" defaultChecked={f.published} /> منتشرشده
                </label>
                <Button size="sm" type="submit">ذخیره</Button>
              </div>
            </form>
            <form action={deleteFaqAction}>
              <input type="hidden" name="id" value={f.id} />
              <Button size="sm" variant="ghost" type="submit" className="text-[var(--color-danger)]">حذف</Button>
            </form>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardTitle className="mb-3">+ پرسش جدید</CardTitle>
          <form action={saveFaqAction} className="space-y-2">
            <input name="question" placeholder="پرسش" className={inputCls} />
            <textarea name="answer" placeholder="پاسخ" rows={2} className={inputCls} />
            <label className="flex items-center gap-1.5 text-sm">
              <input type="checkbox" name="published" defaultChecked /> منتشرشده
            </label>
            <Button size="sm" type="submit">افزودن</Button>
          </form>
        </Card>
      </section>

      {/* Pages */}
      <section className="space-y-3">
        <CardTitle>صفحات</CardTitle>
        {data.pages.map((p) => (
          <Card key={p.id} className="space-y-2">
            <div className="flex items-center gap-2">
              <Badge tone={p.published ? "accent" : "muted"}>{p.published ? "منتشرشده" : "پیش‌نویس"}</Badge>
              <a href={`/p/${p.slug}`} className="text-xs text-[var(--color-primary)]" dir="ltr">/p/{p.slug}</a>
            </div>
            <form action={savePageAction} className="space-y-2">
              <input type="hidden" name="id" value={p.id} />
              <div className="grid gap-2 sm:grid-cols-2">
                <input name="slug" defaultValue={p.slug} dir="ltr" className={inputCls} />
                <input name="title" defaultValue={p.title} className={inputCls} />
              </div>
              <textarea name="body" defaultValue={p.body} rows={4} className={inputCls} />
              <div className="flex items-center gap-3">
                <label className="flex items-center gap-1.5 text-sm">
                  <input type="checkbox" name="published" defaultChecked={p.published} /> منتشرشده
                </label>
                <Button size="sm" type="submit">ذخیره</Button>
              </div>
            </form>
          </Card>
        ))}
        <Card className="border-dashed">
          <CardTitle className="mb-3">+ صفحهٔ جدید</CardTitle>
          <form action={savePageAction} className="space-y-2">
            <div className="grid gap-2 sm:grid-cols-2">
              <input name="slug" placeholder="slug (مثلاً about)" dir="ltr" className={inputCls} />
              <input name="title" placeholder="عنوان" className={inputCls} />
            </div>
            <textarea name="body" placeholder="متن صفحه" rows={4} className={inputCls} />
            <label className="flex items-center gap-1.5 text-sm">
              <input type="checkbox" name="published" defaultChecked /> منتشرشده
            </label>
            <Button size="sm" type="submit">ایجاد</Button>
          </form>
        </Card>
      </section>
    </div>
  );
}
