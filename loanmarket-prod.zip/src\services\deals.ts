import "server-only";
import { withUser, sql } from "@/db";

export type DealRow = {
  id: string; state: string; loan_value: number; loan_price: number;
  buyer_fee: number; seller_fee: number; buyer_id: string; seller_id: string;
  loan_type_name: string; bank_name: string | null; created_at: string;
  escrow_state: string | null; auto_release_at: string | null;
  counterparty: string; role: "buyer" | "seller";
};

export async function getMyDeals(userId: string) {
  return withUser(userId, (tx) =>
    tx.execute<DealRow>(sql`
      select d.id, d.state, d.loan_value, d.loan_price, d.buyer_fee, d.seller_fee,
             d.buyer_id, d.seller_id, d.created_at,
             lt.name as loan_type_name, lt.bank_name,
             e.state as escrow_state, e.auto_release_at,
             case when d.buyer_id = ${userId} then 'buyer' else 'seller' end as role,
             coalesce(cp.display_name, '—') as counterparty
      from deals d
      join loan_types lt on lt.id = d.loan_type_id
      left join escrows e on e.deal_id = d.id
      left join users cp on cp.id = (case when d.buyer_id = ${userId} then d.seller_id else d.buyer_id end)
      where d.buyer_id = ${userId} or d.seller_id = ${userId}
      order by d.created_at desc
    `),
  ) as Promise<DealRow[]>;
}

export async function getDeal(userId: string, dealId: string): Promise<DealRow | null> {
  const rows = (await withUser(userId, (tx) =>
    tx.execute<DealRow>(sql`
      select d.id, d.state, d.loan_value, d.loan_price, d.buyer_fee, d.seller_fee,
             d.buyer_id, d.seller_id, d.created_at,
             lt.name as loan_type_name, lt.bank_name,
             e.state as escrow_state, e.auto_release_at,
             case when d.buyer_id = ${userId} then 'buyer' else 'seller' end as role,
             coalesce(cp.display_name, '—') as counterparty
      from deals d
      join loan_types lt on lt.id = d.loan_type_id
      left join escrows e on e.deal_id = d.id
      left join users cp on cp.id = (case when d.buyer_id = ${userId} then d.seller_id else d.buyer_id end)
      where d.id = ${dealId} and (d.buyer_id = ${userId} or d.seller_id = ${userId})
      limit 1
    `),
  )) as DealRow[];
  return rows[0] ?? null;
}

// ---------------------------------------------------------------------------
// Full workflow timeline + traceability (req. O / G).
// Read-model assembled from existing tables — no money function is touched.
// ---------------------------------------------------------------------------

export type StageStatus = "done" | "current" | "pending" | "skipped" | "cancelled";
export type TimelineStage = {
  key: string;
  label: string;
  status: StageStatus;
  at: string | null;
  hint?: string;
  /** ISO deadline for the current stage (req. Q countdown); null otherwise. */
  deadline?: string | null;
};

export type DealTxn = { id: string; type: string; reference: string | null; created_at: string };
export type DealEvent = { from_state: string | null; to_state: string | null; reason: string | null; created_at: string };
export type DealEvidenceRow = { id: string; kind: string; file_url: string; note: string | null; uploader_id: string; created_at: string };

export type DealTimeline = {
  id: string;
  state: string;
  escrow_state: string | null;
  escrow_id: string | null;
  loan_type_name: string;
  bank_name: string | null;
  loan_value: number;
  loan_price: number;
  buyer_fee: number;
  seller_fee: number;
  buyer_name: string | null;
  buyer_mobile: string | null;
  seller_name: string | null;
  seller_mobile: string | null;
  transfer_info: Record<string, unknown>;
  created_at: string;
  completed_at: string | null;
  listing_created_at: string | null;
  auto_release_at: string | null;
  stages: TimelineStage[];
  events: DealEvent[];
  transactions: DealTxn[];
  evidence: DealEvidenceRow[];
};

type TimelineCoreRow = {
  id: string; state: string; loan_value: number; loan_price: number;
  buyer_fee: number; seller_fee: number; transfer_info: Record<string, unknown> | null;
  created_at: string; completed_at: string | null;
  loan_type_name: string; bank_name: string | null; listing_created_at: string | null;
  escrow_id: string | null; escrow_state: string | null; funded_at: string | null;
  inspection_started_at: string | null; released_at: string | null; refunded_at: string | null;
  auto_release_at: string | null;
  buyer_name: string | null; buyer_mobile: string | null;
  seller_name: string | null; seller_mobile: string | null;
};

export async function getDealTimeline(userId: string, dealId: string): Promise<DealTimeline | null> {
  return withUser(userId, async (tx) => {
    const coreRows = (await tx.execute<TimelineCoreRow>(sql`
      select d.id, d.state, d.loan_value, d.loan_price, d.buyer_fee, d.seller_fee,
             d.transfer_info, d.created_at, d.completed_at,
             lt.name as loan_type_name, lt.bank_name,
             lp.created_at as listing_created_at,
             e.id as escrow_id, e.state as escrow_state, e.funded_at,
             e.inspection_started_at, e.released_at, e.refunded_at, e.auto_release_at,
             b.display_name as buyer_name, b.mobile as buyer_mobile,
             s.display_name as seller_name, s.mobile as seller_mobile
      from deals d
      join loan_types lt on lt.id = d.loan_type_id
      left join loan_posts lp on lp.id = d.listing_id
      left join escrows e on e.deal_id = d.id
      left join users b on b.id = d.buyer_id
      left join users s on s.id = d.seller_id
      where d.id = ${dealId} and (d.buyer_id = ${userId} or d.seller_id = ${userId} or is_admin())
      limit 1
    `)) as TimelineCoreRow[];
    const c = coreRows[0];
    if (!c) return null;

    const events = (await tx.execute<DealEvent>(sql`
      select ev.from_state, ev.to_state, ev.reason, ev.created_at
      from escrow_events ev join escrows e on e.id = ev.escrow_id
      where e.deal_id = ${dealId}
      order by ev.created_at asc
    `)) as DealEvent[];

    // ledger_transactions is admin-readable only → empty array for a normal party.
    const transactions = (await tx.execute<DealTxn>(sql`
      select id, type, reference, created_at
      from ledger_transactions
      where reference = ${dealId} or idempotency_key like ${"deal_%" + dealId + "%"}
      order by created_at asc
    `)) as DealTxn[];

    const evidence = (await tx.execute<DealEvidenceRow>(sql`
      select id, kind, file_url, note, uploader_id, created_at
      from deal_evidence where deal_id = ${dealId}
      order by created_at asc
    `)) as DealEvidenceRow[];

    // req. Q: per-stage deadline hours + admin-hidden stages
    const cfg = (await tx.execute<{ key: string; value: unknown }>(sql`
      select key, value from config where key in ('deal.step_deadline_hours','deal.hidden_stages')
    `)) as { key: string; value: unknown }[];
    const deadlineHours = (cfg.find((r) => r.key === "deal.step_deadline_hours")?.value ?? {}) as Record<string, number>;
    const hiddenStages = (cfg.find((r) => r.key === "deal.hidden_stages")?.value ?? []) as string[];

    return {
      id: c.id,
      state: c.state,
      escrow_state: c.escrow_state,
      escrow_id: c.escrow_id,
      loan_type_name: c.loan_type_name,
      bank_name: c.bank_name,
      loan_value: Number(c.loan_value),
      loan_price: Number(c.loan_price),
      buyer_fee: Number(c.buyer_fee),
      seller_fee: Number(c.seller_fee),
      buyer_name: c.buyer_name,
      buyer_mobile: c.buyer_mobile,
      seller_name: c.seller_name,
      seller_mobile: c.seller_mobile,
      transfer_info: c.transfer_info ?? {},
      created_at: c.created_at,
      completed_at: c.completed_at,
      listing_created_at: c.listing_created_at,
      auto_release_at: c.auto_release_at,
      stages: buildStages(c, events, deadlineHours, hiddenStages),
      events,
      transactions,
      evidence,
    };
  });
}

/** Build the 9 ordered workflow stages (req. O) from deal + escrow data. */
function buildStages(
  c: TimelineCoreRow,
  events: DealEvent[],
  deadlineHours: Record<string, number> = {},
  hiddenStages: string[] = [],
): TimelineStage[] {
  const bypassed = c.escrow_state === "bypassed";
  const sellerTransferAt =
    c.inspection_started_at ??
    events.find((e) => /seller transferred/i.test(e.reason ?? ""))?.created_at ??
    null;
  const releaseAt =
    c.released_at ?? events.find((e) => e.to_state === "released")?.created_at ?? null;
  const refundAt =
    c.refunded_at ?? events.find((e) => e.to_state === "refunded")?.created_at ?? null;

  // Highest completed stage index (1-based) for an active/terminal deal.
  let reached: number;
  switch (c.state) {
    case "waiting_seller_transfer": reached = 6; break;
    case "waiting_buyer_confirmation": reached = 7; break;
    case "disputed": reached = 7; break;
    case "completed": reached = 9; break;
    case "cancelled": case "expired": reached = 6; break;
    default: reached = 4;
  }
  const cancelled = c.state === "cancelled" || c.state === "expired";

  const infoKeys = Object.keys(c.transfer_info ?? {});

  // req. Q: deadline for whichever stage is currently waiting
  const addHours = (iso: string | null, h?: number) =>
    iso && h ? new Date(new Date(iso).getTime() + h * 3600_000).toISOString() : null;
  const sellerDeadline = bypassed ? null : addHours(c.created_at, deadlineHours.seller_transfer);
  const buyerDeadline = c.auto_release_at ?? addHours(sellerTransferAt, deadlineHours.buyer_confirm);

  const defs: { key: string; label: string; at: string | null; hint?: string; skipped?: boolean; deadline?: string | null }[] = [
    { key: "post", label: "ثبت آگهی", at: c.listing_created_at },
    { key: "fee", label: "پرداخت کارمزد", at: bypassed ? null : c.created_at,
      hint: bypassed ? "بدون کارمزد (حالت دستی)" : undefined, skipped: bypassed },
    { key: "approve", label: "تأیید آگهی", at: null },
    { key: "accept", label: "پذیرش توسط طرف مقابل", at: c.created_at },
    { key: "buyer_info", label: "تکمیل اطلاعات خریدار", at: c.created_at,
      hint: infoKeys.length ? `${infoKeys.length} مورد ثبت شد` : "اطلاعاتی ثبت نشده" },
    { key: "escrow_fund", label: "واریز به امانی", at: bypassed ? null : c.funded_at,
      hint: bypassed ? "حالت بدون امانت (توافق دستی)" : undefined, skipped: bypassed },
    { key: "seller_transfer", label: "انتقال توسط فروشنده", at: sellerTransferAt, deadline: sellerDeadline },
    { key: "buyer_confirm", label: "تأیید توسط خریدار", at: releaseAt, deadline: buyerDeadline },
    { key: "release", label: bypassed ? "تکمیل معامله" : "آزادسازی و واریز به فروشنده", at: releaseAt },
  ];

  // map with the ORIGINAL index (so `reached` stays aligned), then drop hidden
  return defs
    .map((d, i): TimelineStage => {
      const idx = i + 1;
      let status: StageStatus;
      if (d.skipped) status = "skipped";
      else if (idx <= reached) status = "done";
      else if (idx === reached + 1 && !cancelled) status = "current";
      else status = "pending";
      return { key: d.key, label: d.label, status, at: d.at, hint: d.hint, deadline: status === "current" ? d.deadline ?? null : null };
    })
    .filter((s) => !hiddenStages.includes(s.key))
    .concat(
      cancelled
        ? [{ key: "cancelled", label: c.state === "expired" ? "منقضی شد" : "لغو و بازگشت وجه", status: "cancelled", at: refundAt }]
        : [],
    );
}

// ---------------------------------------------------------------------------
// Ratings (req. S)
// ---------------------------------------------------------------------------

export type Reputation = { avg: number | null; count: number };

/** Public reputation (avg score + count) for a user, via SECURITY DEFINER fn. */
export async function getUserReputation(userId: string): Promise<Reputation> {
  const { db } = await import("@/db");
  const rows = (await db.execute<{ avg_score: string | null; rating_count: string }>(sql`
    select avg_score, rating_count from user_reputation(${userId}::uuid)
  `)) as { avg_score: string | null; rating_count: string }[];
  const r = rows[0];
  return { avg: r?.avg_score != null ? Number(r.avg_score) : null, count: Number(r?.rating_count ?? 0) };
}

/** Whether `userId` has already rated `dealId`. */
export async function hasRatedDeal(userId: string, dealId: string): Promise<boolean> {
  const rows = (await withUser(userId, (tx) =>
    tx.execute<{ id: string }>(sql`select id from ratings where deal_id = ${dealId} and rater_id = ${userId} limit 1`),
  )) as { id: string }[];
  return rows.length > 0;
}

/** Public fee quote for a listing's price (uses the SECURITY DEFINER fn). */
export async function quoteFees(loanTypeId: string, amount: number) {
  const { db } = await import("@/db");
  const rows = (await db.execute<{ buyer_fee: number; seller_fee: number }>(sql`
    select commission_compute(${loanTypeId}::uuid, 'buyer',  ${amount}) as buyer_fee,
           commission_compute(${loanTypeId}::uuid, 'seller', ${amount}) as seller_fee
  `)) as { buyer_fee: number; seller_fee: number }[];
  return { buyerFee: Number(rows[0]?.buyer_fee ?? 0), sellerFee: Number(rows[0]?.seller_fee ?? 0) };
}
