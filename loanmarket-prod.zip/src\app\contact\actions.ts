"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";

export interface ContactState { ok?: boolean; error?: string }

// Contact form → ticketing, marked source='contact_form' (req. AA).
export async function contactAction(_prev: ContactState, formData: FormData): Promise<ContactState> {
  const user = await getCurrentUser();
  if (!user) redirect("/login?next=/contact");

  const subject = String(formData.get("subject") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();
  if (!subject || subject.length > 150) return { error: "موضوع را وارد کنید" };
  if (!body) return { error: "متن پیام را وارد کنید" };

  await withUser(user.id, async (tx) => {
    const rows = await tx.execute<{ id: string }>(sql`
      insert into tickets(user_id, subject, priority, source)
      values (${user.id}, ${"[تماس با ما] " + subject}, 'normal', 'contact_form')
      returning id`);
    const tid = (rows[0] as { id: string }).id;
    await tx.execute(sql`
      insert into ticket_messages(ticket_id, author_id, body) values (${tid}, ${user.id}, ${body})`);
  });
  revalidatePath("/panel/tickets");
  return { ok: true };
}
