import Link from "next/link";
import {
  LayoutDashboard, FileText, FilePlus2, Bell, Handshake, Wallet, Crown, Settings, LifeBuoy,
} from "lucide-react";
import { requireActiveUser } from "@/lib/auth";

export const dynamic = "force-dynamic";

const NAV = [
  { href: "/panel", icon: LayoutDashboard, label: "نمای کلی" },
  { href: "/panel/loans", icon: FileText, label: "وام‌های من" },
  { href: "/panel/loans/new", icon: FilePlus2, label: "ثبت وام جدید" },
  { href: "/panel/messages", icon: Bell, label: "پیام‌ها" },
  { href: "/deals", icon: Handshake, label: "معاملات" },
  { href: "/wallet", icon: Wallet, label: "کیف پول" },
  { href: "/membership", icon: Crown, label: "اشتراک" },
  { href: "/panel/tickets", icon: LifeBuoy, label: "پشتیبانی" },
  { href: "/panel/settings", icon: Settings, label: "تنظیمات" },
];

export default async function PanelLayout({ children }: { children: React.ReactNode }) {
  await requireActiveUser();

  return (
    <div className="grid gap-6 md:grid-cols-[14rem_1fr]">
      <aside className="card h-fit p-2 md:sticky md:top-20">
        <nav className="flex gap-1 overflow-x-auto md:flex-col">
          {NAV.map(({ href, icon: Icon, label }) => (
            <Link
              key={href}
              href={href}
              className="flex shrink-0 items-center gap-2 rounded-lg px-3 py-2.5 text-sm text-[var(--color-muted)] hover:bg-[var(--color-surface-2)] hover:text-[var(--color-fg)]"
            >
              <Icon size={16} />{label}
            </Link>
          ))}
        </nav>
      </aside>
      <div className="min-w-0 space-y-6">{children}</div>
    </div>
  );
}
