-- =====================================================================
-- Increment 5 · Slice S1 — Post-signup profile completion + activation.
-- Idempotent: safe to re-run.
-- New users land in status 'pending_profile'; they must complete the
-- profile (with two API verifications) before status becomes 'active'.
-- =====================================================================
SET check_function_bodies = off;

-- ---- Profile / KYC columns on users --------------------------------
ALTER TABLE users ADD COLUMN IF NOT EXISTS first_name        text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS last_name         text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS national_id       text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS card_number       text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS sheba             text;
ALTER TABLE users ADD COLUMN IF NOT EXISTS profile_completed boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS mobile_verified   boolean NOT NULL DEFAULT false;
ALTER TABLE users ADD COLUMN IF NOT EXISTS bank_verified     boolean NOT NULL DEFAULT false;
-- UI preference: enter amounts in million-toman instead of toman (req. V).
ALTER TABLE users ADD COLUMN IF NOT EXISTS prefers_million   boolean NOT NULL DEFAULT false;

-- ---- Admin-defined onboarding fields (which data is required) -------
CREATE TABLE IF NOT EXISTS onboarding_fields (
  key      text PRIMARY KEY,
  label    text NOT NULL,
  required boolean NOT NULL DEFAULT true,
  active   boolean NOT NULL DEFAULT true,
  sort     integer NOT NULL DEFAULT 0
);
ALTER TABLE onboarding_fields ENABLE ROW LEVEL SECURITY;
DROP POLICY IF EXISTS p_onb_read  ON onboarding_fields;
DROP POLICY IF EXISTS p_onb_admin ON onboarding_fields;
CREATE POLICY p_onb_read  ON onboarding_fields FOR SELECT USING (true);
CREATE POLICY p_onb_admin ON onboarding_fields USING (is_admin()) WITH CHECK (is_admin());

INSERT INTO onboarding_fields(key, label, required, active, sort) VALUES
  ('first_name',   'نام',                       true,  true, 1),
  ('last_name',    'نام خانوادگی',              true,  true, 2),
  ('national_id',  'کد ملی',                    true,  true, 3),
  ('card_number',  'شماره کارت',                true,  true, 4),
  ('sheba',        'شماره شبا',                 true,  true, 5),
  ('display_name', 'نام نمایشی',                true,  true, 6)
ON CONFLICT (key) DO NOTHING;

-- ---- New signups start unverified ----------------------------------
-- Patch get_or_create_user so freshly created accounts need onboarding.
CREATE OR REPLACE FUNCTION get_or_create_user(_mobile text, _super_email text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _uid uuid;
BEGIN
  SELECT id INTO _uid FROM users WHERE mobile = _mobile;
  IF _uid IS NULL THEN
    INSERT INTO users(mobile, status) VALUES (_mobile, 'pending_profile') RETURNING id INTO _uid;
    INSERT INTO user_roles(user_id, role) VALUES (_uid, 'customer') ON CONFLICT DO NOTHING;
    PERFORM ensure_wallet(_uid);
    PERFORM grant_default_membership(_uid);
  END IF;
  RETURN _uid;
END $$;

-- ---- Persist a completed profile and activate the account ----------
-- App layer runs the two API verifications (Shahkar + bank) and passes the
-- boolean results in; the account only activates when both are true and all
-- admin-required fields are present.
CREATE OR REPLACE FUNCTION complete_profile(
  _uid uuid,
  _first text, _last text, _national_id text,
  _card text, _sheba text, _display text,
  _mobile_verified boolean, _bank_verified boolean
) RETURNS users LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _row users; _missing text;
BEGIN
  -- enforce admin-required fields
  SELECT string_agg(label, '، ') INTO _missing
  FROM onboarding_fields f
  WHERE f.active AND f.required AND
    CASE f.key
      WHEN 'first_name'   THEN coalesce(_first,'')       = ''
      WHEN 'last_name'    THEN coalesce(_last,'')        = ''
      WHEN 'national_id'  THEN coalesce(_national_id,'') = ''
      WHEN 'card_number'  THEN coalesce(_card,'')        = ''
      WHEN 'sheba'        THEN coalesce(_sheba,'')       = ''
      WHEN 'display_name' THEN coalesce(_display,'')     = ''
      ELSE false
    END;
  IF _missing IS NOT NULL THEN
    RAISE EXCEPTION 'missing required fields: %', _missing;
  END IF;

  IF NOT (_mobile_verified AND _bank_verified) THEN
    RAISE EXCEPTION 'identity verification incomplete';
  END IF;

  UPDATE users SET
    first_name = _first, last_name = _last, national_id = _national_id,
    card_number = _card, sheba = _sheba,
    display_name = coalesce(nullif(_display,''), display_name),
    mobile_verified = _mobile_verified, bank_verified = _bank_verified,
    profile_completed = true, status = 'active', verification_level = greatest(verification_level, 2),
    updated_at = now()
  WHERE id = _uid
  RETURNING * INTO _row;

  INSERT INTO notifications(user_id, title, body) VALUES
    (_uid, 'حساب شما فعال شد', 'اطلاعات تکمیلی شما تأیید و حساب کاربری‌تان فعال شد.');
  RETURN _row;
END $$;

GRANT EXECUTE ON FUNCTION
  get_or_create_user(text, text),
  complete_profile(uuid, text, text, text, text, text, text, boolean, boolean)
TO app;

-- ---- config defaults -----------------------------------------------
INSERT INTO config(key, value) VALUES
  ('onboarding.enabled', 'true'::jsonb)
ON CONFLICT (key) DO NOTHING;
