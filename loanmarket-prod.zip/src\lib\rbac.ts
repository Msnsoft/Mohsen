// Admin-panel section gating per docs/05-admin/01-admin-panel.md §2 and the
// RBAC matrix. Roles are data (user_roles); super_admin sees everything.
export interface AdminSection {
  key: string;
  href: string;
  label: string;
  roles: string[]; // non-super roles allowed into the section
}

export const ADMIN_SECTIONS: AdminSection[] = [
  { key: "dashboard", href: "/admin", label: "داشبورد", roles: ["finance_admin", "escrow_admin", "support_admin", "moderator", "analyst", "compliance_officer"] },
  { key: "users", href: "/admin/users", label: "کاربران و نقش‌ها", roles: ["support_admin", "moderator", "compliance_officer"] },
  { key: "loan_types", href: "/admin/loan-types", label: "انواع وام", roles: ["moderator"] },
  { key: "listings", href: "/admin/listings", label: "تأیید آگهی‌ها", roles: ["moderator"] },
  { key: "deals", href: "/admin/deals", label: "معاملات", roles: ["finance_admin", "escrow_admin", "support_admin", "moderator", "analyst"] },
  { key: "escrows", href: "/admin/escrows", label: "کنسول امانی", roles: ["escrow_admin", "finance_admin"] },
  { key: "wallets", href: "/admin/wallets", label: "کیف پول و دفترکل", roles: ["finance_admin", "analyst"] },
  { key: "commissions", href: "/admin/commissions", label: "قوانین کارمزد", roles: ["finance_admin"] },
  { key: "plans", href: "/admin/plans", label: "اشتراک‌ها", roles: ["finance_admin"] },
  { key: "withdrawals", href: "/admin/withdrawals", label: "برداشت‌ها", roles: ["finance_admin"] },
  { key: "labels", href: "/admin/labels", label: "برچسب‌های آگهی", roles: ["moderator"] },
  { key: "tickets", href: "/admin/tickets", label: "تیکت‌ها و پشتیبانی", roles: ["support_admin"] },
  { key: "cms", href: "/admin/cms", label: "مدیریت محتوا (CMS)", roles: ["moderator", "support_admin"] },
  { key: "audit", href: "/admin/audit", label: "گزارش حسابرسی", roles: ["compliance_officer", "finance_admin"] },
  { key: "config", href: "/admin/config", label: "پیکربندی", roles: [] }, // super admin only
];

export function canAccessSection(roles: string[], sectionKey: string): boolean {
  if (roles.includes("super_admin")) return true;
  const s = ADMIN_SECTIONS.find((x) => x.key === sectionKey);
  return !!s && s.roles.some((r) => roles.includes(r));
}

export function visibleSections(roles: string[]): AdminSection[] {
  return ADMIN_SECTIONS.filter((s) => canAccessSection(roles, s.key));
}

export const GRANTABLE_ROLES = [
  "super_admin", "finance_admin", "escrow_admin", "support_admin",
  "moderator", "analyst", "compliance_officer",
];

export const ROLE_FA: Record<string, string> = {
  super_admin: "مدیر کل",
  finance_admin: "مدیر مالی",
  escrow_admin: "مدیر امانی",
  support_admin: "پشتیبانی",
  moderator: "ناظر محتوا",
  analyst: "تحلیلگر",
  compliance_officer: "افسر انطباق",
  customer: "مشتری",
  user: "کاربر",
};
