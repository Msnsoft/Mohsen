import { getCurrentUser } from "@/lib/auth";
import { hasEntitlement } from "@/lib/entitlements";
import { db, sql } from "@/db";
import { getMarketAverages, type MarketAverages } from "@/services/marketplace";
import { CalculatorClient } from "./calculator-client";

export const dynamic = "force-dynamic";

export default async function CalculatorPage() {
  const user = await getCurrentUser();
  // advanced calculator (fair value + amortization) is a membership entitlement (M19)
  const advanced = await hasEntitlement(user?.id ?? null, "calculator");

  // req. N: market-average analysis, shown only when the admin enables it
  const cfg = (await db.execute<{ value: boolean }>(
    sql`select value from config where key = 'analysis.show_market_average'`,
  )) as { value: boolean }[];
  const showMarketAvg = cfg[0]?.value === true;
  const marketAvg: MarketAverages | null = showMarketAvg ? await getMarketAverages() : null;

  return <CalculatorClient advanced={advanced} marketAvg={marketAvg} />;
}
