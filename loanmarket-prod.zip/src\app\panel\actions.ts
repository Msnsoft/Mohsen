"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";
import { formatToman } from "@/lib/persian";
import { CANCELLABLE_STATUSES } from "@/lib/post-status";

export interface NewLoanState { ok?: boolean; error?: string; status?: string; id?: string }

/** Register a new sell listing / buy request (FR-UP-04/05). */
export async function createLoanAction(_prev: NewLoanState, formData: FormData): Promise<NewLoanState> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const type = String(formData.get("type") ?? "sell");
  const loanTypeId = String(formData.get("loan_type_id") ?? "");
  const num = (k: string) => Number(String(formData.get(k) ?? "").replace(/[^\d.]/g, ""));
  const loanValue = num("loan_value") * 10;   // toman input → IRR
  const loanPrice = num("loan_price") * 10;
  const province = String(formData.get("province") ?? "").trim() || null;

  // admin-defined seller custom fields (req. B) arrive as custom:<key>
  const custom: Record<string, string> = {};
  for (const [k, v] of formData.entries()) {
    if (k.startsWith("custom:")) {
      const val = String(v).trim();
      if (val) custom[k.slice("custom:".length)] = val;
    }
  }
  const customJson = JSON.stringify(custom);

  if (!["sell", "buy"].includes(type)) return { error: "نوع آگهی نامعتبر است" };
  if (!loanValue || loanValue <= 0) return { error: "مبلغ وام نامعتبر است" };
  if (!loanPrice || loanPrice <= 0) return { error: "قیمت پیشنهادی نامعتبر است" };

  return withUser(user.id, async (tx) => {
    const ltRows = await tx.execute<{
      id: string; rate_editable: boolean; fixed_rate: string | null;
      default_duration_months: number | null;
      min_price_per_million: string | null; max_price_per_million: string | null;
    }>(sql`select id, rate_editable, fixed_rate, default_duration_months,
                  min_price_per_million, max_price_per_million
           from loan_types where id = ${loanTypeId} and active`);
    const lt = ltRows[0];
    if (!lt) return { error: "نوع وام انتخاب‌شده معتبر نیست" };

    // price per million toman, validated against the loan type's allowed range (FR-UP-04)
    const ppm = Math.round(loanPrice / (loanValue / 10_000_000));
    const min = lt.min_price_per_million ? Number(lt.min_price_per_million) : null;
    const max = lt.max_price_per_million ? Number(lt.max_price_per_million) : null;
    if ((min && ppm < min) || (max && ppm > max)) {
      return {
        error: `قیمت هر میلیون (${formatToman(ppm)}) خارج از بازهٔ مجاز این نوع وام است` +
          (min && max ? ` (${formatToman(min)} تا ${formatToman(max)})` : ""),
      };
    }

    const rate = lt.rate_editable
      ? (num("rate") || null)
      : (lt.fixed_rate !== null ? Number(lt.fixed_rate) : null);
    const duration = num("duration_months") || lt.default_duration_months || null;

    // listing approval mode (admin-configurable, M16): auto → active, manual → pending_review
    const cfgRows = await tx.execute<{ value: string }>(
      sql`select value::text as value from config where key = 'marketplace.listing_approval_mode'`,
    );
    const mode = (cfgRows[0]?.value ?? '"manual"').replaceAll('"', "");
    const status = mode === "auto" ? "active" : "pending_review";

    const inserted = await tx.execute<{ id: string }>(sql`
      insert into loan_posts (user_id, type, loan_type_id, loan_value, loan_price,
                              price_per_million, rate, duration_months, province, status, custom)
      values (${user.id}, ${type}, ${loanTypeId}, ${loanValue}, ${loanPrice},
              ${ppm}, ${rate}, ${duration}, ${province}, ${status}, ${customJson}::jsonb)
      returning id`);

    revalidatePath("/panel/loans");
    revalidatePath("/marketplace");
    return { ok: true, status, id: inserted[0]?.id };
  });
}

export async function cancelPostAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const id = String(formData.get("post_id") ?? "");
  await withUser(user.id, (tx) =>
    tx.execute(sql`
      update loan_posts set status = 'cancelled'
      where id = ${id} and user_id = ${user.id}
        and status = any(${CANCELLABLE_STATUSES})`),
  );
  revalidatePath("/panel/loans");
  revalidatePath("/marketplace");
}

export async function markReadAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const id = String(formData.get("notification_id") ?? "");
  await withUser(user.id, (tx) =>
    tx.execute(sql`update notifications set read = true where id = ${id} and user_id = ${user.id}`),
  );
  revalidatePath("/panel/messages");
  revalidatePath("/", "layout");
}

export async function markAllReadAction() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  await withUser(user.id, (tx) =>
    tx.execute(sql`update notifications set read = true where user_id = ${user.id} and not read`),
  );
  revalidatePath("/panel/messages");
  revalidatePath("/", "layout");
}

export interface ProfileState { ok?: boolean; error?: string }

export async function updateProfileAction(_prev: ProfileState, formData: FormData): Promise<ProfileState> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const name = String(formData.get("display_name") ?? "").trim();
  if (!name || name.length > 60) return { error: "نام نمایشی نامعتبر است" };
  await withUser(user.id, (tx) =>
    tx.execute(sql`update users set display_name = ${name} where id = ${user.id}`),
  );
  revalidatePath("/", "layout");
  return { ok: true };
}
