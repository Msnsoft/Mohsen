-- =====================================================================
-- Dev seed / bootstrap fixtures. Real users register via OTP; these are
-- local-dev fixtures + required bootstrap (config, plans, commission, super admin).
-- =====================================================================

-- ---- Config (M16) ----------------------------------------------------
INSERT INTO config(key, value) VALUES
  ('display.currency_format', '{"unit":"toman","scale":10,"suffix":"تومان"}'),
  ('escrow.seller_timeout_hours', '12'),
  ('escrow.inspection_hours', '72'),
  ('membership.grace_days', '3'),
  ('otp.ttl_minutes', '3'),
  ('commission.prorate_partial_band', 'true')
ON CONFLICT (key) DO NOTHING;

-- ---- Membership plans (M19) -----------------------------------------
DO $$
DECLARE _free uuid; _basic uuid; _pro uuid;
BEGIN
  INSERT INTO subscription_plans(key,name,price,period_days,sort)
    VALUES ('free','رایگان',0,3650,0) RETURNING id INTO _free;
  INSERT INTO subscription_plans(key,name,price,period_days,sort)
    VALUES ('basic','پایه',9900000,30,1) RETURNING id INTO _basic;   -- 990,000 toman
  INSERT INTO subscription_plans(key,name,price,period_days,sort)
    VALUES ('pro','حرفه‌ای',24900000,30,2) RETURNING id INTO _pro;   -- 2,490,000 toman

  INSERT INTO plan_entitlements(plan_id, entitlement) VALUES
    (_basic,'calculator'), (_basic,'pricing_advice'), (_basic,'sms_alerts'),
    (_pro,'calculator'), (_pro,'pricing_advice'), (_pro,'sms_alerts'),
    (_pro,'auto_match'), (_pro,'history_charts');
END $$;

-- ---- Loan types (M04) -----------------------------------------------
DO $$
DECLARE _t1 uuid; _t2 uuid; _t3 uuid; _seller uuid; _admin uuid; _gdef_s uuid; _prog uuid;
BEGIN
  INSERT INTO loan_types(name,bank_name,fixed_rate,rate_editable,default_duration_months,min_price_per_million,max_price_per_million)
    VALUES ('وام ازدواج','بانک ملی',4,false,60, 800000, 1300000) RETURNING id INTO _t1;
  INSERT INTO loan_types(name,bank_name,fixed_rate,rate_editable,default_duration_months)
    VALUES ('وام مسکن','بانک مسکن',18,false,144) RETURNING id INTO _t2;
  INSERT INTO loan_types(name,bank_name,fixed_rate,rate_editable,default_duration_months)
    VALUES ('وام خوداشتغالی','بانک رفاه',NULL,true,36) RETURNING id INTO _t3;

  -- ---- Super admin (dev: login via OTP with this mobile) ----
  INSERT INTO users(mobile,email,display_name,verification_level)
    VALUES ('09120000000','mohsen.hajalizadeh@gmail.com','مدیر کل',2) RETURNING id INTO _admin;
  INSERT INTO user_roles(user_id,role) VALUES (_admin,'super_admin'),(_admin,'user');
  PERFORM ensure_wallet(_admin);

  -- ---- Demo seller (dev fixture) ----
  INSERT INTO users(mobile,display_name,verification_level)
    VALUES ('09121111111','فروشنده نمونه',2) RETURNING id INTO _seller;
  INSERT INTO user_roles(user_id,role) VALUES (_seller,'user');
  PERFORM ensure_wallet(_seller);

  -- ---- Sample active sell listings (IRR; 1 toman = 10 IRR) ----
  INSERT INTO loan_posts(user_id,type,loan_type_id,loan_value,loan_price,price_per_million,rate,duration_months,province,status,featured)
  VALUES
    (_seller,'sell',_t1, 1500000000, 180000000, 1200000, 4,  60,'تهران','active',true),
    (_seller,'sell',_t2, 8000000000, 950000000, 1187500, 18,144,'اصفهان','active',false),
    (_seller,'sell',_t3, 3000000000, 240000000,  800000, 23, 36,'فارس','active',false),
    (_seller,'sell',_t1, 1000000000, 110000000, 1100000, 4,  60,'خراسان رضوی','active',false);

  -- splittable example
  INSERT INTO loan_posts(user_id,type,loan_type_id,loan_value,loan_price,price_per_million,rate,duration_months,province,status,splittable,min_chunk,max_splits,min_acceptable,max_acceptable)
  VALUES (_seller,'sell',_t2, 3000000000, 360000000, 1200000, 18,144,'تهران','active',true, 1000000000, 3, 2700000000, 3300000000);

  -- ---- Commission rules (M09) ----
  -- global defaults
  INSERT INTO commission_rules(loan_type_id,side,method,percent_rate)
    VALUES (NULL,'buyer','percent',0.5), (NULL,'seller','percent',1.5);
  -- progressive example on loan type 1 (seller side): breakpoints 0/50/100 (M toman)
  INSERT INTO commission_rules(loan_type_id,side,method) VALUES (_t1,'seller','progressive') RETURNING id INTO _prog;
  INSERT INTO commission_bands(rule_id,from_amount,to_amount,amount_per_band,sort) VALUES
    (_prog, 0,           500000000,  5000000, 0),   -- 0–50M toman → 500k toman flat
    (_prog, 500000000,  1000000000,  4000000, 1);   -- 50–100M toman → 400k toman flat
  INSERT INTO commission_bands(rule_id,from_amount,to_amount,rate_per_million,sort) VALUES
    (_prog, 1000000000, NULL,           60000, 2);  -- 100M+ → 6k toman per million toman
END $$;
