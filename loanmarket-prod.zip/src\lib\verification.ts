import "server-only";

// Identity-verification provider seam (Increment 5 · req. A).
// Two layers, both required before an account activates:
//   1. national-id ⇄ mobile belong to the same person  (Shahkar-type service)
//   2. card-number ⇄ SHEBA  belong to the same person   (bank / Finnotech-type service)
//
// Real Iranian providers (Shahkar via Finnotech/IranAPI, bank matching via
// Finnotech `/v2/clients/.../sms/verify` etc.) need API keys + signed requests.
// Until those are wired, dev mode returns success so the flow is testable.
// Set VERIFICATION_DEV_MODE=false to force the real adapters (TODOs below).

const devMode = process.env.VERIFICATION_DEV_MODE !== "false";

export interface VerifyResult {
  ok: boolean;
  reason?: string;
}

function digits(s: string): string {
  return (s ?? "")
    .replace(/[۰-۹]/g, (d) => String("۰۱۲۳۴۵۶۷۸۹".indexOf(d)))
    .replace(/\D/g, "");
}

/** Basic structural validity for an Iranian national id (کد ملی). */
export function isValidNationalId(raw: string): boolean {
  const c = digits(raw);
  if (!/^\d{10}$/.test(c)) return false;
  if (/^(\d)\1{9}$/.test(c)) return false;
  const check = Number(c[9]);
  let sum = 0;
  for (let i = 0; i < 9; i++) sum += Number(c[i]) * (10 - i);
  const r = sum % 11;
  return r < 2 ? check === r : check === 11 - r;
}

/** Basic structural validity for a SHEBA/IBAN (IR + 24 digits). */
export function isValidSheba(raw: string): boolean {
  const s = (raw ?? "").replace(/\s/g, "").toUpperCase().replace(/^IR/, "");
  return /^\d{24}$/.test(digits(s));
}

/** Layer 1: national-id and mobile registered to the same person. */
export async function verifyMobileNationalId(mobile: string, nationalId: string): Promise<VerifyResult> {
  if (!isValidNationalId(nationalId)) return { ok: false, reason: "کد ملی نامعتبر است" };
  if (digits(mobile).length !== 11) return { ok: false, reason: "شماره موبایل نامعتبر است" };
  if (devMode) return { ok: true };
  // TODO: call Shahkar provider; map response to { ok, reason }.
  return { ok: false, reason: "سرویس استعلام در دسترس نیست" };
}

/** Layer 2: card number and SHEBA belong to the same person. */
export async function verifyCardSheba(card: string, sheba: string, nationalId?: string): Promise<VerifyResult> {
  if (digits(card).length !== 16) return { ok: false, reason: "شماره کارت نامعتبر است" };
  if (!isValidSheba(sheba)) return { ok: false, reason: "شماره شبا نامعتبر است" };
  void nationalId;
  if (devMode) return { ok: true };
  // TODO: call bank/Finnotech card⇄sheba⇄owner matching; map to { ok, reason }.
  return { ok: false, reason: "سرویس استعلام بانکی در دسترس نیست" };
}
