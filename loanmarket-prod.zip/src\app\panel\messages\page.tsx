import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/auth";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { toFaDigits } from "@/lib/persian";
import { markReadAction, markAllReadAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function MessagesPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  const messages = await withUser(user.id, (tx) =>
    tx.execute<{ id: string; title: string; body: string | null; read: boolean; created_at: string }>(
      sql`select id, title, body, read, created_at::text from notifications
          where user_id = ${user.id} order by created_at desc limit 100`,
    ),
  );
  const unread = messages.filter((m) => !m.read).length;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">
          پیام‌ها {unread > 0 && <span className="text-sm font-normal text-[var(--color-muted)]">({toFaDigits(unread)} خوانده‌نشده)</span>}
        </h1>
        {unread > 0 && (
          <form action={markAllReadAction}>
            <Button variant="outline" size="sm" type="submit">خواندن همه</Button>
          </form>
        )}
      </div>

      {messages.length === 0 ? (
        <Card><CardMuted>پیامی ندارید.</CardMuted></Card>
      ) : (
        <div className="space-y-2">
          {messages.map((m) => (
            <Card
              key={m.id}
              className={`flex items-start justify-between gap-3 ${m.read ? "opacity-70" : "border-[var(--color-primary)]"}`}
            >
              <div className="space-y-1">
                <p className="flex items-center gap-2 font-semibold">
                  {!m.read && <span className="h-2 w-2 rounded-full bg-[var(--color-primary)]" />}
                  {m.title}
                </p>
                {m.body && <p className="text-sm text-[var(--color-muted)]">{m.body}</p>}
                <p className="text-xs text-[var(--color-muted)]" dir="ltr">{m.created_at.slice(0, 16)}</p>
              </div>
              {!m.read && (
                <form action={markReadAction}>
                  <input type="hidden" name="notification_id" value={m.id} />
                  <Button variant="ghost" size="sm" type="submit">خواندم</Button>
                </form>
              )}
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
