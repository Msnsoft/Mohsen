"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { destroySession, getSessionUserId } from "@/lib/session";
import { withUser, sql } from "@/db";
import { isThemeKey, THEME_COOKIE } from "@/lib/themes";

export async function logout() {
  await destroySession();
  redirect("/");
}

/** Save the chosen color set: cookie for guests, account row for users (FR-M02-10). */
export async function setThemeAction(formData: FormData) {
  const theme = String(formData.get("theme") ?? "");
  if (!isThemeKey(theme)) return;

  const c = await cookies();
  c.set(THEME_COOKIE, theme, { path: "/", sameSite: "lax", maxAge: 365 * 24 * 3600 });

  const userId = await getSessionUserId();
  if (userId) {
    await withUser(userId, (tx) =>
      tx.execute(sql`update users set theme = ${theme} where id = ${userId}`),
    );
  }
  revalidatePath("/", "layout");
}

/** Save the million-toman input preference (req. V). */
export async function setPrefersMillionAction(formData: FormData) {
  const userId = await getSessionUserId();
  if (!userId) redirect("/login");
  const on = formData.get("prefers_million") === "on";
  await withUser(userId, (tx) =>
    tx.execute(sql`update users set prefers_million = ${on} where id = ${userId}`),
  );
  revalidatePath("/panel/settings");
  revalidatePath("/panel/loans/new");
  revalidatePath("/wallet");
}
