import Link from "next/link";
import { getActiveListings, getLoanTypeOptions } from "@/services/marketplace";
import { ListingCard } from "@/components/listing-card";
import { Card, CardMuted } from "@/components/ui/card";
import { getLabelRules, computeLabels } from "@/lib/labels";
import { getCurrentUser } from "@/lib/auth";
import { getListingVisibility } from "@/lib/visibility";

export const dynamic = "force-dynamic";

type SP = {
  type?: string; loan_type?: string; bank?: string; province?: string;
  min_price?: string; max_price?: string; min_value?: string; max_value?: string;
};

const toman = (v?: string) => {
  const n = Number((v ?? "").replace(/[^\d]/g, ""));
  return n > 0 ? n * 10 : undefined; // toman → IRR
};

export default async function MarketplacePage({ searchParams }: { searchParams: Promise<SP> }) {
  const sp = await searchParams;
  const type = sp.type === "buy" ? "buy" : sp.type === "sell" ? "sell" : undefined;

  const user = await getCurrentUser();
  const [listings, loanTypeOptions, rules, allowed] = await Promise.all([
    getActiveListings({
      type,
      loanTypeId: sp.loan_type || undefined,
      bank: sp.bank || undefined,
      province: sp.province || undefined,
      minPrice: toman(sp.min_price),
      maxPrice: toman(sp.max_price),
      minValue: toman(sp.min_value),
      maxValue: toman(sp.max_value),
    }),
    getLoanTypeOptions(),
    getLabelRules(),
    getListingVisibility(user ? "member" : "guest"),
  ]);

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <h1 className="text-2xl font-bold">بازار امتیاز وام</h1>
        <div className="flex gap-1 rounded-xl border border-[var(--color-border)] p-1 text-sm">
          <Tab type={undefined} active={!type}>همه</Tab>
          <Tab type="sell" active={type === "sell"}>درخواست فروش وام</Tab>
          <Tab type="buy" active={type === "buy"}>درخواست خرید وام</Tab>
        </div>
      </div>

      {/* Digikala-style filter panel (req. C) — GET form so URLs are shareable */}
      <Card>
        <form method="get" className="grid items-end gap-3 sm:grid-cols-2 lg:grid-cols-4">
          {type && <input type="hidden" name="type" value={type} />}
          <Field label="نوع وام">
            <select name="loan_type" defaultValue={sp.loan_type ?? ""} className={inputCls}>
              <option value="">همه</option>
              {loanTypeOptions.map((t) => (
                <option key={t.id} value={t.id}>{t.name}{t.bankName ? ` — ${t.bankName}` : ""}</option>
              ))}
            </select>
          </Field>
          <Field label="بانک"><input name="bank" defaultValue={sp.bank ?? ""} placeholder="نام بانک" className={inputCls} /></Field>
          <Field label="استان"><input name="province" defaultValue={sp.province ?? ""} placeholder="مثلاً تهران" className={inputCls} /></Field>
          <div className="grid grid-cols-2 gap-2">
            <Field label="حداقل قیمت (ت)"><input name="min_price" inputMode="numeric" dir="ltr" defaultValue={sp.min_price ?? ""} className={inputCls} /></Field>
            <Field label="حداکثر قیمت (ت)"><input name="max_price" inputMode="numeric" dir="ltr" defaultValue={sp.max_price ?? ""} className={inputCls} /></Field>
          </div>
          <div className="grid grid-cols-2 gap-2">
            <Field label="حداقل ارزش (ت)"><input name="min_value" inputMode="numeric" dir="ltr" defaultValue={sp.min_value ?? ""} className={inputCls} /></Field>
            <Field label="حداکثر ارزش (ت)"><input name="max_value" inputMode="numeric" dir="ltr" defaultValue={sp.max_value ?? ""} className={inputCls} /></Field>
          </div>
          <div className="flex gap-2 sm:col-span-2 lg:col-span-2">
            <button className="rounded-xl bg-[var(--color-primary)] px-5 py-2.5 text-sm font-medium text-white">اعمال فیلتر</button>
            <Link href={type ? `/marketplace?type=${type}` : "/marketplace"} className="rounded-xl border border-[var(--color-border)] px-5 py-2.5 text-sm">حذف فیلترها</Link>
          </div>
        </form>
      </Card>

      {allowed !== "all" && (
        <CardMuted>برای مشاهدهٔ کامل قیمت و ارزش آگهی‌ها <Link href="/login" className="text-[var(--color-primary)]">وارد شوید</Link>.</CardMuted>
      )}

      {listings.length === 0 ? (
        <Card><CardMuted>آگهی‌ای با این فیلترها یافت نشد.</CardMuted></Card>
      ) : (
        <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {listings.map((l) => <ListingCard key={l.id} l={l} labels={computeLabels(l, rules)} allowed={allowed} />)}
        </div>
      )}
    </div>
  );
}

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="space-y-1 text-xs">
      <span className="text-[var(--color-muted)]">{label}</span>
      {children}
    </label>
  );
}

function Tab({ type, active, children }: { type?: string; active: boolean; children: React.ReactNode }) {
  const href = type ? `/marketplace?type=${type}` : "/marketplace";
  return (
    <Link href={href} className={`rounded-lg px-3 py-1.5 ${active ? "bg-[var(--color-primary)] text-white" : "text-[var(--color-muted)] hover:text-[var(--color-fg)]"}`}>
      {children}
    </Link>
  );
}
