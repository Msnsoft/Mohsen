-- =====================================================================
-- Increment 4: M19 subscription purchase · M12 ticketing · M15 CMS.
-- Idempotent: safe to re-run.
-- =====================================================================
SET check_function_bodies = off;

-- =====================================================================
-- M19 — subscription purchase (wallet-paid, ledger-booked)
-- =====================================================================
CREATE OR REPLACE FUNCTION subscription_purchase(_user uuid, _plan_key text, _idem text DEFAULT NULL)
RETURNS uuid LANGUAGE plpgsql SECURITY DEFINER SET search_path = public AS $$
DECLARE _plan subscription_plans%ROWTYPE; _avail bigint; _sub uuid;
        _u_avail uuid; _rev uuid; _from timestamptz;
BEGIN
  SELECT * INTO _plan FROM subscription_plans WHERE key = _plan_key AND active;
  IF NOT FOUND THEN RAISE EXCEPTION 'plan not found or inactive'; END IF;
  IF _plan.price <= 0 THEN RAISE EXCEPTION 'free plan needs no purchase'; END IF;

  _avail := wallet_balance(_user, 'available');
  IF _avail < _plan.price THEN
    RAISE EXCEPTION 'insufficient balance: need %, have %', _plan.price, _avail;
  END IF;

  _u_avail := user_account(_user, 'available');
  _rev     := system_account('platform_revenue');
  PERFORM post_transaction('subscription_fee', _idem, 'plan_' || _plan.key, _user,
    jsonb_build_array(
      jsonb_build_object('account_id', _u_avail, 'amount', -_plan.price),
      jsonb_build_object('account_id', _rev,     'amount',  _plan.price)
    ));

  -- extend if the same plan is already active; otherwise supersede others
  SELECT GREATEST(now(), MAX(expires_at)) INTO _from
  FROM subscriptions WHERE user_id = _user AND plan_id = _plan.id AND status = 'active' AND expires_at > now();
  _from := COALESCE(_from, now());

  UPDATE subscriptions SET status = 'cancelled'
  WHERE user_id = _user AND status = 'active' AND plan_id <> _plan.id;

  INSERT INTO subscriptions(user_id, plan_id, status, started_at, expires_at)
  VALUES (_user, _plan.id, 'active', now(), _from + (_plan.period_days || ' days')::interval)
  RETURNING id INTO _sub;

  INSERT INTO notifications(user_id, title, body) VALUES
    (_user, 'اشتراک فعال شد', 'اشتراک «' || _plan.name || '» برای شما فعال شد.');
  RETURN _sub;
END $$;

GRANT EXECUTE ON FUNCTION subscription_purchase(uuid, text, text) TO app;

-- =====================================================================
-- M12 — Ticketing (Zendesk model)
-- =====================================================================
CREATE TABLE IF NOT EXISTS tickets (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id     uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  subject     text NOT NULL,
  status      text NOT NULL DEFAULT 'new',  -- new|open|pending|on_hold|solved|closed
  priority    text NOT NULL DEFAULT 'normal',  -- low|normal|high|urgent
  assignee_id uuid REFERENCES users(id),
  created_at  timestamptz NOT NULL DEFAULT now(),
  updated_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS tickets_user_idx ON tickets (user_id, created_at DESC);
CREATE INDEX IF NOT EXISTS tickets_queue_idx ON tickets (status, created_at);

CREATE TABLE IF NOT EXISTS ticket_messages (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id   uuid NOT NULL REFERENCES tickets(id) ON DELETE CASCADE,
  author_id   uuid NOT NULL REFERENCES users(id),
  body        text NOT NULL,
  is_internal boolean NOT NULL DEFAULT false,  -- internal note: admins only
  created_at  timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS ticket_messages_idx ON ticket_messages (ticket_id, created_at);

DROP TRIGGER IF EXISTS trg_tickets_updated ON tickets;
CREATE TRIGGER trg_tickets_updated BEFORE UPDATE ON tickets FOR EACH ROW EXECUTE FUNCTION set_updated_at();

ALTER TABLE tickets ENABLE ROW LEVEL SECURITY;
ALTER TABLE ticket_messages ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS p_tickets_read ON tickets;
CREATE POLICY p_tickets_read ON tickets FOR SELECT
  USING (user_id = current_user_id() OR is_admin());
DROP POLICY IF EXISTS p_tickets_insert ON tickets;
CREATE POLICY p_tickets_insert ON tickets FOR INSERT
  WITH CHECK (user_id = current_user_id());
DROP POLICY IF EXISTS p_tickets_update ON tickets;
CREATE POLICY p_tickets_update ON tickets FOR UPDATE
  USING (user_id = current_user_id() OR is_admin());

DROP POLICY IF EXISTS p_ticket_msgs_read ON ticket_messages;
CREATE POLICY p_ticket_msgs_read ON ticket_messages FOR SELECT
  USING (
    (NOT is_internal AND ticket_id IN (SELECT id FROM tickets WHERE user_id = current_user_id()))
    OR is_admin()
  );
DROP POLICY IF EXISTS p_ticket_msgs_insert ON ticket_messages;
CREATE POLICY p_ticket_msgs_insert ON ticket_messages FOR INSERT
  WITH CHECK (
    author_id = current_user_id()
    AND (is_admin() OR (NOT is_internal AND ticket_id IN (SELECT id FROM tickets WHERE user_id = current_user_id())))
  );

-- =====================================================================
-- M15 — Dynamic CMS
-- =====================================================================
CREATE TABLE IF NOT EXISTS cms_pages (
  id         uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug       text UNIQUE NOT NULL,
  title      text NOT NULL,
  body       text NOT NULL DEFAULT '',
  published  boolean NOT NULL DEFAULT false,
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS cms_menu_items (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  location  text NOT NULL DEFAULT 'header',  -- header|footer
  label     text NOT NULL,
  url       text NOT NULL,
  sort      int NOT NULL DEFAULT 0,
  visible   boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS cms_faqs (
  id        uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  question  text NOT NULL,
  answer    text NOT NULL,
  sort      int NOT NULL DEFAULT 0,
  published boolean NOT NULL DEFAULT true
);

CREATE TABLE IF NOT EXISTS cms_widgets (
  key       text PRIMARY KEY,             -- hero|features|featured_listings|faq_section
  enabled   boolean NOT NULL DEFAULT true,
  payload   jsonb NOT NULL DEFAULT '{}',
  sort      int NOT NULL DEFAULT 0
);

ALTER TABLE cms_pages ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_menu_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_faqs ENABLE ROW LEVEL SECURITY;
ALTER TABLE cms_widgets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS p_cms_pages_read ON cms_pages;
CREATE POLICY p_cms_pages_read ON cms_pages FOR SELECT USING (published OR is_admin());
DROP POLICY IF EXISTS p_cms_pages_admin ON cms_pages;
CREATE POLICY p_cms_pages_admin ON cms_pages FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS p_cms_menu_read ON cms_menu_items;
CREATE POLICY p_cms_menu_read ON cms_menu_items FOR SELECT USING (visible OR is_admin());
DROP POLICY IF EXISTS p_cms_menu_admin ON cms_menu_items;
CREATE POLICY p_cms_menu_admin ON cms_menu_items FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS p_cms_faqs_read ON cms_faqs;
CREATE POLICY p_cms_faqs_read ON cms_faqs FOR SELECT USING (published OR is_admin());
DROP POLICY IF EXISTS p_cms_faqs_admin ON cms_faqs;
CREATE POLICY p_cms_faqs_admin ON cms_faqs FOR ALL USING (is_admin()) WITH CHECK (is_admin());

DROP POLICY IF EXISTS p_cms_widgets_read ON cms_widgets;
CREATE POLICY p_cms_widgets_read ON cms_widgets FOR SELECT USING (true);
DROP POLICY IF EXISTS p_cms_widgets_admin ON cms_widgets;
CREATE POLICY p_cms_widgets_admin ON cms_widgets FOR ALL USING (is_admin()) WITH CHECK (is_admin());

-- ---- Seeds (only when empty) ------------------------------------------
INSERT INTO cms_widgets(key, enabled, payload, sort) VALUES
  ('hero', true, '{"title":"خرید و فروش امن امتیاز وام","subtitle":"معامله‌ی تضمین‌شده با امانت‌داری وجه، شفافیت کامل نرخ مؤثر سالانه (APR)، و کارمزد منصفانه. بدون ریسک کلاهبرداری."}', 0),
  ('features', true, '{}', 1),
  ('featured_listings', true, '{"limit":4}', 2),
  ('faq_section', true, '{"limit":4}', 3)
ON CONFLICT (key) DO NOTHING;

INSERT INTO cms_faqs(question, answer, sort)
SELECT * FROM (VALUES
  ('امتیاز وام چیست؟', 'حق دریافت یک وام بانکی قابل انتقال (مانند وام ازدواج یا مسکن) که دارنده می‌تواند آن را به دیگری واگذار کند.', 0),
  ('پول من چطور محافظت می‌شود؟', 'مبلغ معامله تا تأیید انتقال وام توسط خریدار، نزد پلتفرم به امانت نگه داشته می‌شود و سپس به فروشنده تسویه می‌گردد.', 1),
  ('کارمزد معامله چقدر است؟', 'کارمزد بر اساس نوع وام و مبلغ، به‌صورت درصدی یا پلکانی محاسبه و پیش از پرداخت به شما نمایش داده می‌شود.', 2)
) AS v(question, answer, sort)
WHERE NOT EXISTS (SELECT 1 FROM cms_faqs);

INSERT INTO cms_menu_items(location, label, url, sort)
SELECT * FROM (VALUES
  ('footer', 'سوالات متداول', '/faq', 0),
  ('footer', 'درباره ما', '/p/about', 1),
  ('footer', 'قوانین و مقررات', '/p/terms', 2)
) AS v(location, label, url, sort)
WHERE NOT EXISTS (SELECT 1 FROM cms_menu_items);

INSERT INTO cms_pages(slug, title, body, published)
SELECT * FROM (VALUES
  ('about', 'درباره ما', 'بازار امتیاز وام، سکویی امن برای خرید و فروش امتیاز وام‌های قابل انتقال است.', true),
  ('terms', 'قوانین و مقررات', 'استفاده از این سکو به منزلهٔ پذیرش قوانین معاملات و حریم خصوصی است.', true)
) AS v(slug, title, body, published)
WHERE NOT EXISTS (SELECT 1 FROM cms_pages);

-- ---- Config keys --------------------------------------------------------
INSERT INTO config(key, value) VALUES
  ('tickets.sla_first_reply_hours', '24'),
  ('cms.site_name', '"بازار امتیاز وام"')
ON CONFLICT (key) DO NOTHING;
