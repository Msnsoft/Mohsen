"use client";
import { useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";

/**
 * Subscribes to the server-sent event stream (req. S9 realtime) and refreshes
 * server components when a notification for this user arrives — so the header
 * unread badge, deal states and wallet update live without a manual reload.
 * Also shows a brief toast.
 */
export function LiveUpdates() {
  const router = useRouter();
  const [toast, setToast] = useState<string | null>(null);
  const timer = useRef<ReturnType<typeof setTimeout> | undefined>(undefined);

  useEffect(() => {
    const es = new EventSource("/api/events");
    es.addEventListener("notification", (e) => {
      try {
        const data = JSON.parse((e as MessageEvent).data) as { title?: string };
        if (data.title) {
          setToast(data.title);
          clearTimeout(timer.current);
          timer.current = setTimeout(() => setToast(null), 5000);
        }
      } catch { /* ignore */ }
      router.refresh();
    });
    es.onerror = () => { /* browser auto-reconnects per `retry` */ };
    return () => { es.close(); clearTimeout(timer.current); };
  }, [router]);

  if (!toast) return null;
  return (
    <div className="fixed bottom-4 left-4 z-50 max-w-xs rounded-xl border border-[var(--color-border)] bg-[var(--color-surface)] px-4 py-3 text-sm shadow-lg">
      <span className="font-medium">🔔 {toast}</span>
    </div>
  );
}
