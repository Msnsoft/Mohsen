"use client";
import { useActionState, useState } from "react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { formatToman, formatPercent, toFaDigits } from "@/lib/persian";
import { CustomFieldInput, type CustomField } from "@/components/custom-field-input";
import { createLoanAction, type NewLoanState } from "../../actions";

export interface LoanTypeOption {
  id: string;
  name: string;
  bank_name: string | null;
  rate_editable: boolean;
  fixed_rate: string | null;
  default_duration_months: number | null;
  min_price_per_million: string | null;
  max_price_per_million: string | null;
}

const inputCls =
  "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]";

export function NewLoanForm({
  loanTypes,
  marketAvg,
  sellerFields = {},
}: {
  loanTypes: LoanTypeOption[];
  /** avg active-market price-per-million by loan type id; null = not entitled (upsell) */
  marketAvg: Record<string, number> | null;
  /** admin-defined seller custom fields per loan type id (req. B) */
  sellerFields?: Record<string, CustomField[]>;
}) {
  const [state, action, pending] = useActionState<NewLoanState, FormData>(createLoanAction, {});
  const [typeId, setTypeId] = useState(loanTypes[0]?.id ?? "");
  const lt = loanTypes.find((t) => t.id === typeId);
  const extraFields = sellerFields[typeId] ?? [];

  // two-way price calculator (req. T): value ⇄ total price ⇄ price-per-million
  const [loanValue, setLoanValue] = useState("");
  const [loanPrice, setLoanPrice] = useState("");
  const [ppm, setPpm] = useState("");
  const num = (s: string) => Number(s.replace(/[^\d.]/g, "")) || 0;
  const grp = (n: number) => (n ? Math.round(n).toLocaleString("en-US") : "");

  function onValue(v: string) {
    setLoanValue(v);
    const val = num(v);
    if (val && num(ppm)) setLoanPrice(grp((val / 1_000_000) * num(ppm)));
    else if (val && num(loanPrice)) setPpm(grp(num(loanPrice) / (val / 1_000_000)));
  }
  function onPrice(v: string) {
    setLoanPrice(v);
    const val = num(loanValue);
    if (val) setPpm(grp(num(v) / (val / 1_000_000)));
  }
  function onPpm(v: string) {
    setPpm(v);
    const val = num(loanValue);
    if (val) setLoanPrice(grp((val / 1_000_000) * num(v)));
  }

  if (state.ok) {
    return (
      <div className="space-y-3 py-4 text-center">
        <p className="text-lg font-bold text-[var(--color-accent)]">آگهی شما ثبت شد ✓</p>
        <p className="text-sm text-[var(--color-muted)]">
          {state.status === "active"
            ? "آگهی هم‌اکنون در بازار فعال است."
            : "آگهی پس از بررسی و تأیید مدیر در بازار منتشر می‌شود."}
        </p>
        <div className="flex justify-center gap-2">
          <Link href="/panel/loans"><Button variant="outline" size="sm">وام‌های من</Button></Link>
          {state.status === "active" && state.id && (
            <Link href={`/marketplace/${state.id}`}><Button size="sm">مشاهدهٔ آگهی</Button></Link>
          )}
        </div>
      </div>
    );
  }

  return (
    <form action={action} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">نوع آگهی</span>
          <select name="type" className={inputCls} defaultValue="sell">
            <option value="sell">درخواست فروش وام</option>
            <option value="buy">درخواست خرید وام</option>
          </select>
        </label>
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">نوع وام</span>
          <select name="loan_type_id" className={inputCls} value={typeId} onChange={(e) => setTypeId(e.target.value)}>
            {loanTypes.map((t) => (
              <option key={t.id} value={t.id}>
                {t.name}{t.bank_name ? ` — ${t.bank_name}` : ""}
              </option>
            ))}
          </select>
        </label>
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">مبلغ وام (تومان)</span>
          <input name="loan_value" value={loanValue} onChange={(e) => onValue(e.target.value)}
                 inputMode="numeric" dir="ltr" placeholder="150,000,000" className={inputCls} required />
        </label>
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">قیمت هر میلیون (تومان)</span>
          <input value={ppm} onChange={(e) => onPpm(e.target.value)}
                 inputMode="numeric" dir="ltr" placeholder="120,000" className={inputCls} />
          {lt && (lt.min_price_per_million || lt.max_price_per_million) && (
            <span className="block text-xs text-[var(--color-muted)]">
              بازهٔ مجاز هر میلیون: {lt.min_price_per_million ? formatToman(Number(lt.min_price_per_million)) : "—"} تا{" "}
              {lt.max_price_per_million ? formatToman(Number(lt.max_price_per_million)) : "—"}
            </span>
          )}
        </label>
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">قیمت کل پیشنهادی امتیاز (تومان)</span>
          <input name="loan_price" value={loanPrice} onChange={(e) => onPrice(e.target.value)}
                 inputMode="numeric" dir="ltr" placeholder="18,000,000" className={inputCls} required />
          <span className="block text-xs text-[var(--color-muted)]">با وارد کردن «قیمت هر میلیون» یا «قیمت کل»، دیگری خودکار محاسبه می‌شود.</span>
        </label>
        {lt?.rate_editable ? (
          <label className="space-y-1.5 text-sm">
            <span className="text-[var(--color-muted)]">نرخ سود (٪)</span>
            <input name="rate" inputMode="decimal" dir="ltr" placeholder="18" className={inputCls} />
          </label>
        ) : (
          lt?.fixed_rate && (
            <div className="space-y-1.5 text-sm">
              <span className="text-[var(--color-muted)]">نرخ سود</span>
              <p className="rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 text-[var(--color-muted)]">
                {formatPercent(lt.fixed_rate)} (ثابت برای این نوع وام)
              </p>
            </div>
          )
        )}
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">مدت بازپرداخت (ماه)</span>
          <input
            name="duration_months" inputMode="numeric" dir="ltr" className={inputCls}
            key={typeId}
            defaultValue={lt?.default_duration_months ?? ""}
          />
          {lt?.default_duration_months && (
            <span className="block text-xs text-[var(--color-muted)]">
              پیش‌فرض این نوع وام: {toFaDigits(lt.default_duration_months)} ماه
            </span>
          )}
        </label>
        <label className="space-y-1.5 text-sm">
          <span className="text-[var(--color-muted)]">استان</span>
          <input name="province" placeholder="تهران" className={inputCls} />
        </label>
      </div>

      {extraFields.length > 0 && (
        <div className="space-y-3 rounded-xl border border-[var(--color-border)] p-4">
          <p className="text-sm font-semibold">اطلاعات تکمیلی این نوع وام</p>
          <div className="grid gap-4 sm:grid-cols-2">
            {extraFields.map((f) => (
              <CustomFieldInput key={f.key} field={f} prefix="custom" />
            ))}
          </div>
        </div>
      )}

      {marketAvg ? (
        lt && marketAvg[lt.id] ? (
          <div className="rounded-xl border border-[var(--color-accent)] bg-[color-mix(in_oklab,var(--color-accent)_8%,transparent)] p-3 text-sm">
            <p className="font-semibold text-[var(--color-accent)]">مشاورهٔ قیمت‌گذاری</p>
            <p className="mt-1 text-[var(--color-muted)]">
              میانگین قیمت هر میلیون در آگهی‌های فعال این نوع وام: <strong>{formatToman(marketAvg[lt.id])}</strong>.
              قیمت نزدیک به میانگین، سرعت فروش را بالا می‌برد.
            </p>
          </div>
        ) : null
      ) : (
        <div className="rounded-xl border border-dashed border-[var(--color-border)] p-3 text-sm text-[var(--color-muted)]">
          💡 با اشتراک «پایه» یا بالاتر، <Link href="/membership" className="text-[var(--color-primary)]">مشاورهٔ هوشمند قیمت‌گذاری</Link> بر اساس میانگین بازار را همین‌جا ببینید.
        </div>
      )}

      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}

      <Button type="submit" disabled={pending} className="w-full sm:w-auto">
        {pending ? "در حال ثبت…" : "ثبت آگهی"}
      </Button>
      <p className="text-xs text-[var(--color-muted)]">
        بسته به تنظیمات پلتفرم، آگهی ممکن است بلافاصله منتشر شود یا ابتدا توسط مدیر بررسی شود.
      </p>
    </form>
  );
}
