import { and, desc, eq, gte, lte, ilike, type SQL } from "drizzle-orm";
import { db } from "@/db";
import { loanPosts, loanTypes } from "@/db/schema";

export interface ListingFilters {
  type?: "sell" | "buy";
  loanTypeId?: string;
  bank?: string;
  minPrice?: number;   // IRR
  maxPrice?: number;
  minValue?: number;
  maxValue?: number;
  province?: string;
  limit?: number;
}

const listingSelect = {
  id: loanPosts.id,
  userId: loanPosts.userId,
  type: loanPosts.type,
  loanValue: loanPosts.loanValue,
  loanPrice: loanPosts.loanPrice,
  pricePerMillion: loanPosts.pricePerMillion,
  rate: loanPosts.rate,
  durationMonths: loanPosts.durationMonths,
  province: loanPosts.province,
  status: loanPosts.status,
  splittable: loanPosts.splittable,
  minChunk: loanPosts.minChunk,
  maxSplits: loanPosts.maxSplits,
  featured: loanPosts.featured,
  createdAt: loanPosts.createdAt,
  loanTypeId: loanTypes.id,
  loanTypeName: loanTypes.name,
  bankName: loanTypes.bankName,
  fixedRate: loanTypes.fixedRate,
};

export type Listing = Awaited<ReturnType<typeof getActiveListings>>[number];

export async function getActiveListings(opts: ListingFilters = {}) {
  const conds: SQL[] = [eq(loanPosts.status, "active")];
  if (opts.type) conds.push(eq(loanPosts.type, opts.type));
  if (opts.loanTypeId) conds.push(eq(loanPosts.loanTypeId, opts.loanTypeId));
  if (opts.bank) conds.push(ilike(loanTypes.bankName, `%${opts.bank}%`));
  if (opts.province) conds.push(ilike(loanPosts.province, `%${opts.province}%`));
  if (opts.minPrice) conds.push(gte(loanPosts.loanPrice, opts.minPrice));
  if (opts.maxPrice) conds.push(lte(loanPosts.loanPrice, opts.maxPrice));
  if (opts.minValue) conds.push(gte(loanPosts.loanValue, opts.minValue));
  if (opts.maxValue) conds.push(lte(loanPosts.loanValue, opts.maxValue));

  const q = db.select(listingSelect).from(loanPosts)
    .innerJoin(loanTypes, eq(loanPosts.loanTypeId, loanTypes.id))
    .where(and(...conds))
    .orderBy(desc(loanPosts.featured), desc(loanPosts.createdAt));
  return opts.limit ? q.limit(opts.limit) : q;
}

/**
 * Market-average price-per-million (IRR) for sell vs buy listings over
 * the last week / month / all time (req. N). Null when no data in a window.
 */
export type MarketAverages = {
  sell: { week: number | null; month: number | null; all: number | null };
  buy: { week: number | null; month: number | null; all: number | null };
};

export async function getMarketAverages(): Promise<MarketAverages> {
  const { sql } = await import("@/db");
  const rows = (await db.execute<{ type: string; week: string | null; month: string | null; all: string | null }>(sql`
    select type,
           round(avg(price_per_million) filter (where created_at >= now() - interval '7 days'))::text  as week,
           round(avg(price_per_million) filter (where created_at >= now() - interval '30 days'))::text as month,
           round(avg(price_per_million))::text as all
    from loan_posts
    where price_per_million is not null and status in ('active','sold','reserved')
    group by type
  `)) as { type: string; week: string | null; month: string | null; all: string | null }[];
  const pick = (t: string) => {
    const r = rows.find((x) => x.type === t);
    const n = (v: string | null) => (v != null ? Number(v) : null);
    return { week: n(r?.week ?? null), month: n(r?.month ?? null), all: n(r?.all ?? null) };
  };
  return { sell: pick("sell"), buy: pick("buy") };
}

/** Loan types for filter dropdowns. */
export async function getLoanTypeOptions() {
  return db.select({ id: loanTypes.id, name: loanTypes.name, bankName: loanTypes.bankName })
    .from(loanTypes).where(eq(loanTypes.active, true)).orderBy(loanTypes.name);
}

export async function getListingById(id: string) {
  const rows = await db.select(listingSelect).from(loanPosts)
    .innerJoin(loanTypes, eq(loanPosts.loanTypeId, loanTypes.id))
    .where(eq(loanPosts.id, id))
    .limit(1);
  return rows[0] ?? null;
}
