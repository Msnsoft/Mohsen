"use client";
import Link from "next/link";
import { useMemo, useState } from "react";
import { calculateAPR, fairValueAtRate } from "@/lib/finance/apr";
import { generateAmortizationSchedule } from "@/lib/finance/amortization";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { formatToman, formatPercent, toFaDigits } from "@/lib/persian";
import type { MarketAverages } from "@/services/marketplace";

const field = "w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-2.5 outline-none focus:border-[var(--color-primary)]";

export function CalculatorClient({ advanced, marketAvg = null }: { advanced: boolean; marketAvg?: MarketAverages | null }) {
  const [loanValueT, setLoanValueT] = useState(500_000_000); // toman
  const [askingT, setAskingT] = useState(60_000_000);
  const [rate, setRate] = useState(18);
  const [months, setMonths] = useState(60);

  const { apr, fair, schedule, fullSchedule } = useMemo(() => {
    const loanAmount = loanValueT * 10, askingPrice = askingT * 10; // → IRR
    const apr = calculateAPR({ loanAmount, askingPrice, bankRatePct: rate, months });
    const fair = fairValueAtRate(loanAmount, askingPrice, rate, rate, months);
    const fullSchedule = generateAmortizationSchedule(loanAmount, rate, months);
    return { apr, fair, schedule: fullSchedule.slice(0, 6), fullSchedule };
  }, [loanValueT, askingT, rate, months]);

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">محاسبه‌گر وام</h1>
      <div className="grid gap-6 lg:grid-cols-3">
        <Card className="space-y-3">
          <CardTitle>ورودی‌ها</CardTitle>
          <Num label="ارزش وام (تومان)" value={loanValueT} onChange={setLoanValueT} />
          <Num label="قیمت امتیاز (تومان)" value={askingT} onChange={setAskingT} />
          <Num label="نرخ سود بانک (٪)" value={rate} onChange={setRate} />
          <Num label="مدت (ماه)" value={months} onChange={setMonths} />
        </Card>

        <Card className="space-y-4 lg:col-span-2">
          <CardTitle>نتایج</CardTitle>
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
            <Metric label="قسط ماهانه" value={formatToman(apr.monthlyInstallment)} />
            <Metric label="APR" value={formatPercent((apr.realAPR * 100).toFixed(1))} />
            <Metric label="EAR" value={formatPercent((apr.effectiveAPR * 100).toFixed(1))} />
            <Metric label="هزینهٔ کل" value={formatToman(apr.totalCostToBuyer)} />
          </div>
          {advanced && <CardMuted>قیمت منصفانه برآوردی: {formatToman(fair.fairPrice)}</CardMuted>}

          {/* installment payment chart — visible to everyone (req. W) */}
          <div>
            <h4 className="mb-2 text-sm font-semibold">نمودار پرداخت اقساط</h4>
            <InstallmentChart schedule={fullSchedule} />
            <p className="mt-1 text-xs text-[var(--color-muted)]">هر ستون یک قسط؛ بخش روشن = اصل، بخش پررنگ = سود.</p>
          </div>

          {!advanced ? (
            <div className="space-y-3 rounded-xl border border-dashed border-[var(--color-border)] p-4 text-center">
              <p className="text-sm font-semibold">ماشین‌حساب پیشرفته (قیمت منصفانه + جدول اقساط)</p>
              <p className="text-xs text-[var(--color-muted)]">
                با اشتراک «پایه» یا بالاتر، برآورد قیمت منصفانه و جدول کامل اقساط را ببینید.
              </p>
              <Link href="/membership"><Button size="sm">فعال‌سازی با اشتراک</Button></Link>
            </div>
          ) : (
          <div>
            <h4 className="mb-2 text-sm font-semibold">جدول اقساط (۶ ماه نخست)</h4>
            <table className="w-full text-sm">
              <thead className="text-[var(--color-muted)]">
                <tr className="border-b border-[var(--color-border)]">
                  <th className="py-1 text-start">ماه</th><th className="py-1 text-start">قسط</th>
                  <th className="py-1 text-start">اصل</th><th className="py-1 text-start">سود</th><th className="py-1 text-start">مانده</th>
                </tr>
              </thead>
              <tbody>
                {schedule.map((r) => (
                  <tr key={r.month} className="border-b border-[var(--color-border)]/40">
                    <td className="py-1">{toFaDigits(r.month)}</td>
                    <td className="py-1">{formatToman(r.installment, { suffix: false })}</td>
                    <td className="py-1">{formatToman(r.principal, { suffix: false })}</td>
                    <td className="py-1">{formatToman(r.interest, { suffix: false })}</td>
                    <td className="py-1">{formatToman(r.balance, { suffix: false })}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          )}
        </Card>
      </div>

      {/* req. N: market-average analysis (admin-toggled) */}
      {marketAvg && (
        <Card className="space-y-3">
          <CardTitle>تحلیل بازار — میانگین قیمت هر میلیون</CardTitle>
          <CardMuted>میانگین «قیمت هر میلیون» آگهی‌ها به تومان، بر اساس بازهٔ زمانی.</CardMuted>
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead className="text-[var(--color-muted)]">
                <tr className="border-b border-[var(--color-border)]">
                  <th className="py-2 text-start">نوع</th>
                  <th className="py-2 text-start">هفتهٔ اخیر</th>
                  <th className="py-2 text-start">ماه اخیر</th>
                  <th className="py-2 text-start">کل</th>
                </tr>
              </thead>
              <tbody>
                <AvgRow label="درخواست فروش وام" row={marketAvg.sell} />
                <AvgRow label="درخواست خرید وام" row={marketAvg.buy} />
              </tbody>
            </table>
          </div>
        </Card>
      )}
    </div>
  );
}

function AvgRow({ label, row }: { label: string; row: { week: number | null; month: number | null; all: number | null } }) {
  const cell = (v: number | null) => (v != null ? formatToman(v) : "—");
  return (
    <tr className="border-b border-[var(--color-border)]/40">
      <td className="py-2 font-medium">{label}</td>
      <td className="py-2">{cell(row.week)}</td>
      <td className="py-2">{cell(row.month)}</td>
      <td className="py-2">{cell(row.all)}</td>
    </tr>
  );
}

interface ScheduleRow { month: number; installment: number; principal: number; interest: number; balance: number }

function InstallmentChart({ schedule }: { schedule: ScheduleRow[] }) {
  if (schedule.length === 0) return null;
  const W = 640, H = 160, pad = 8;
  const max = Math.max(...schedule.map((r) => r.installment), 1);
  const n = schedule.length;
  const bw = Math.max(1, (W - pad * 2) / n - 1);
  return (
    <svg viewBox={`0 0 ${W} ${H}`} className="w-full" role="img" aria-label="نمودار اقساط">
      {schedule.map((r, i) => {
        const x = pad + i * ((W - pad * 2) / n);
        const total = (r.installment / max) * (H - pad * 2);
        const interestH = (r.interest / max) * (H - pad * 2);
        const yTop = H - pad - total;
        return (
          <g key={r.month}>
            <rect x={x} y={yTop} width={bw} height={total - interestH} fill="var(--color-accent)" opacity={0.55} />
            <rect x={x} y={H - pad - interestH} width={bw} height={interestH} fill="var(--color-primary)" />
          </g>
        );
      })}
    </svg>
  );
}

function Num({ label, value, onChange }: { label: string; value: number; onChange: (n: number) => void }) {
  return (
    <div>
      <label className="mb-1 block text-sm text-[var(--color-muted)]">{label}</label>
      <input className={field} dir="ltr" inputMode="numeric" value={value}
        onChange={(e) => onChange(Number(e.target.value.replace(/[^\d.]/g, "")) || 0)} />
    </div>
  );
}
function Metric({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-xl bg-[var(--color-surface-2)] p-3">
      <p className="text-xs text-[var(--color-muted)]">{label}</p>
      <p className="mt-1 font-bold">{value}</p>
    </div>
  );
}
