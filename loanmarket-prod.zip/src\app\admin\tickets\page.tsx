import Link from "next/link";
import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { toFaDigits } from "@/lib/persian";
import { TICKET_STATUS_FA, TICKET_PRIORITY_FA, ticketStatusTone } from "@/lib/ticket-status";
import { requireSectionPage } from "../guard";

export const dynamic = "force-dynamic";

export default async function AdminTicketsPage({
  searchParams,
}: {
  searchParams: Promise<{ status?: string }>;
}) {
  const admin = await requireSectionPage("tickets");
  const { status = "open_all" } = await searchParams;

  const tickets = await withUser(admin.id, (tx) =>
    tx.execute<{
      id: string; subject: string; status: string; priority: string; created_at: string;
      owner_name: string | null; owner_mobile: string; assignee_name: string | null; msg_count: string;
    }>(sql`
      select t.id, t.subject, t.status, t.priority, t.created_at::text,
             u.display_name as owner_name, u.mobile as owner_mobile,
             a.display_name as assignee_name,
             (select count(*) from ticket_messages m where m.ticket_id = t.id)::text as msg_count
      from tickets t
      join users u on u.id = t.user_id
      left join users a on a.id = t.assignee_id
      where (${status} = 'open_all' and t.status in ('new','open','pending','on_hold'))
         or t.status = ${status}
      order by case t.priority when 'urgent' then 0 when 'high' then 1 when 'normal' then 2 else 3 end,
               t.created_at asc
      limit 100`),
  );

  const tabs: [string, string][] = [
    ["open_all", "در جریان"], ["new", "جدید"], ["pending", "در انتظار کاربر"],
    ["solved", "حل‌شده"], ["closed", "بسته"],
  ];

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">تیکت‌ها و پشتیبانی</h1>

      <div className="flex flex-wrap gap-2">
        {tabs.map(([k, label]) => (
          <Link
            key={k}
            href={`/admin/tickets?status=${k}`}
            className={`rounded-full border px-3 py-1 text-xs ${
              status === k
                ? "border-[var(--color-primary)] text-[var(--color-primary)]"
                : "border-[var(--color-border)] text-[var(--color-muted)]"
            }`}
          >
            {label}
          </Link>
        ))}
      </div>

      {tickets.length === 0 ? (
        <Card><CardMuted>تیکتی در این وضعیت نیست.</CardMuted></Card>
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => (
            <Link key={t.id} href={`/admin/tickets/${t.id}`} className="block">
              <Card className="flex flex-wrap items-center justify-between gap-3 transition-colors hover:border-[var(--color-primary)]">
                <div className="space-y-1">
                  <p className="flex items-center gap-2 font-semibold">
                    {t.subject}
                    {(t.priority === "urgent" || t.priority === "high") && (
                      <Badge tone="danger">{TICKET_PRIORITY_FA[t.priority]}</Badge>
                    )}
                  </p>
                  <p className="text-xs text-[var(--color-muted)]">
                    {t.owner_name ?? "—"} <span dir="ltr">{toFaDigits(t.owner_mobile)}</span> ·{" "}
                    {toFaDigits(t.msg_count)} پیام · مسئول: {t.assignee_name ?? "—"}
                  </p>
                </div>
                <Badge tone={ticketStatusTone(t.status)}>{TICKET_STATUS_FA[t.status] ?? t.status}</Badge>
              </Card>
            </Link>
          ))}
        </div>
      )}
    </div>
  );
}
