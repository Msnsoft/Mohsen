-- =====================================================================
-- Increment 5a: editable landing page — live site statistics + CTA links.
-- Stats are public aggregates only (no PII), exposed past RLS via a
-- SECURITY DEFINER function granted to the app role.  Idempotent.
-- =====================================================================
SET check_function_bodies = off;

-- ---- Public site statistics (aggregates only) -------------------------
CREATE OR REPLACE FUNCTION public_site_stats()
RETURNS TABLE (
  users           bigint,
  active_listings bigint,
  completed_deals bigint,
  volume          bigint,
  loan_types      bigint
) LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT
    (SELECT count(*) FROM users WHERE status = 'active'),
    (SELECT count(*) FROM loan_posts WHERE status = 'active'),
    (SELECT count(*) FROM deals WHERE state = 'completed'),
    (SELECT COALESCE(SUM(loan_price), 0) FROM deals WHERE state = 'completed'),
    (SELECT count(*) FROM loan_types WHERE active)
$$;

GRANT EXECUTE ON FUNCTION public_site_stats() TO app;

-- ---- Seed: stats widget on the landing page ---------------------------
INSERT INTO cms_widgets(key, enabled, payload, sort) VALUES
  ('stats', true,
   '{"title":"بازار امتیاز وام در یک نگاه","metrics":["users","active_listings","completed_deals","volume"]}',
   2)
ON CONFLICT (key) DO NOTHING;

-- ---- Seed: editable landing CTA links (hero buttons) ------------------
INSERT INTO cms_menu_items(location, label, url, sort, visible)
SELECT * FROM (VALUES
  ('landing', 'ورود به بازار', '/marketplace', 0, true),
  ('landing', 'ماشین‌حساب وام', '/calculator', 1, true)
) AS v(location, label, url, sort, visible)
WHERE NOT EXISTS (SELECT 1 FROM cms_menu_items WHERE location = 'landing');
