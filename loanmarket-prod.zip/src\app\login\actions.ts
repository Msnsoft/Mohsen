"use server";
import { redirect } from "next/navigation";
import { cookies } from "next/headers";
import { requestOtp, verifyOtp } from "@/lib/otp";
import { createSession } from "@/lib/session";
import { withUser, sql } from "@/db";
import { isThemeKey, THEME_COOKIE } from "@/lib/themes";

export interface SendState { ok: boolean; mobile?: string; devCode?: string; error?: string }
export interface VerifyState { ok: boolean; error?: string }

export async function sendOtpAction(_prev: SendState, formData: FormData): Promise<SendState> {
  const mobile = String(formData.get("mobile") ?? "");
  const res = await requestOtp(mobile);
  if (res.throttled) return { ok: false, error: "تعداد درخواست کد بیش از حد مجاز است. چند دقیقه بعد دوباره تلاش کنید." };
  if (!res.ok) return { ok: false, error: "شمارهٔ موبایل نامعتبر است" };
  return { ok: true, mobile: res.mobile, devCode: res.devCode };
}

export async function verifyOtpAction(_prev: VerifyState, formData: FormData): Promise<VerifyState> {
  const mobile = String(formData.get("mobile") ?? "");
  const code = String(formData.get("code") ?? "");
  const res = await verifyOtp(mobile, code);
  if (!res.ok || !res.userId) return { ok: false, error: "کد واردشده صحیح یا معتبر نیست" };
  await createSession(res.userId);
  // carry a guest's cookie theme onto the account (AC-M02-04)
  const cookieTheme = (await cookies()).get(THEME_COOKIE)?.value;
  if (isThemeKey(cookieTheme)) {
    await withUser(res.userId, (tx) =>
      tx.execute(sql`update users set theme = ${cookieTheme} where id = ${res.userId}`),
    );
  }
  // Not-yet-activated accounts must finish onboarding first (req. A).
  const statusRows = await withUser(res.userId, (tx) =>
    tx.execute<{ status: string }>(sql`select status from users where id = ${res.userId}`),
  );
  const active = (statusRows[0] as { status: string } | undefined)?.status === "active";
  redirect(active ? "/panel" : "/onboarding");
}
