"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";

export interface TicketFormState { ok?: boolean; error?: string; id?: string }

export async function createTicketAction(_prev: TicketFormState, formData: FormData): Promise<TicketFormState> {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const subject = String(formData.get("subject") ?? "").trim();
  const body = String(formData.get("body") ?? "").trim();
  const priority = String(formData.get("priority") ?? "normal");
  if (!subject || subject.length > 150) return { error: "موضوع تیکت نامعتبر است" };
  if (!body) return { error: "متن پیام را وارد کنید" };
  if (!["low", "normal", "high", "urgent"].includes(priority)) return { error: "اولویت نامعتبر است" };

  const id = await withUser(user.id, async (tx) => {
    const rows = await tx.execute<{ id: string }>(sql`
      insert into tickets(user_id, subject, priority) values (${user.id}, ${subject}, ${priority})
      returning id`);
    const tid = rows[0]!.id;
    await tx.execute(sql`
      insert into ticket_messages(ticket_id, author_id, body) values (${tid}, ${user.id}, ${body})`);
    return tid;
  });
  revalidatePath("/panel/tickets");
  return { ok: true, id };
}

export async function userReplyTicketAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const ticketId = String(formData.get("ticket_id") ?? "");
  const body = String(formData.get("body") ?? "").trim();
  if (!body) return;
  await withUser(user.id, async (tx) => {
    await tx.execute(sql`
      insert into ticket_messages(ticket_id, author_id, body) values (${ticketId}, ${user.id}, ${body})`);
    // user replied → conversation returns to the agent's court (Zendesk: open)
    await tx.execute(sql`
      update tickets set status = 'open'
      where id = ${ticketId} and user_id = ${user.id} and status in ('pending','solved','on_hold')`);
  });
  revalidatePath(`/panel/tickets/${ticketId}`);
  revalidatePath("/panel/tickets");
}

export async function userCloseTicketAction(formData: FormData) {
  const user = await getCurrentUser();
  if (!user) redirect("/login");
  const ticketId = String(formData.get("ticket_id") ?? "");
  await withUser(user.id, (tx) =>
    tx.execute(sql`
      update tickets set status = 'closed'
      where id = ${ticketId} and user_id = ${user.id} and status <> 'closed'`),
  );
  revalidatePath(`/panel/tickets/${ticketId}`);
  revalidatePath("/panel/tickets");
}
