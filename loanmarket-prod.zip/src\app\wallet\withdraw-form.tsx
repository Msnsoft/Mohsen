"use client";
import { useActionState, useState } from "react";
import { withdrawAction, type WithdrawState } from "./actions";
import { Button } from "@/components/ui/button";

export function WithdrawForm({ sheba, prefersMillion = false }: { sheba: string | null; prefersMillion?: boolean }) {
  const [state, action, pending] = useActionState<WithdrawState, FormData>(withdrawAction, {});
  const [amount, setAmount] = useState("");
  const unitLabel = prefersMillion ? "میلیون تومان" : "تومان";

  return (
    <form action={action} className="space-y-3">
      <input type="hidden" name="unit" value={prefersMillion ? "million" : "toman"} />
      <label className="block text-sm text-[var(--color-muted)]">مبلغ برداشت ({unitLabel})</label>
      <input
        name="amount" inputMode="numeric" placeholder={prefersMillion ? "۵" : "۵٬۰۰۰٬۰۰۰"} dir="ltr"
        value={amount}
        onChange={(e) => setAmount(e.target.value.replace(/[^\d]/g, ""))}
        className="w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-4 py-3 outline-none focus:border-[var(--color-primary)]"
        required
      />
      <p className="text-xs text-[var(--color-muted)]">
        واریز به شبا{sheba ? <> <span dir="ltr">{sheba.replace(/^/, "IR")}</span></> : " ثبت‌شده در پروفایل"}.
        پس از تأیید مدیر مالی پرداخت می‌شود.
      </p>
      {state.error && <p className="text-sm text-[var(--color-danger)]">{state.error}</p>}
      {state.ok && <p className="text-sm text-[var(--color-accent)]">درخواست برداشت ثبت شد و در انتظار تأیید است.</p>}
      <Button className="w-full" type="submit" variant="outline" disabled={pending}>
        {pending ? "در حال ثبت…" : "ثبت درخواست برداشت"}
      </Button>
    </form>
  );
}
