import { withUser, sql } from "@/db";
import { Card, CardMuted } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { toFaDigits, formatToman } from "@/lib/persian";
import { GRANTABLE_ROLES, ROLE_FA } from "@/lib/rbac";
import { requireSectionPage } from "../guard";
import { setUserStatusAction, grantRoleAction, revokeRoleAction, toggleSpecialUserAction } from "../actions";

export const dynamic = "force-dynamic";

export default async function AdminUsersPage() {
  const admin = await requireSectionPage("users");
  const isSuper = admin.roles.includes("super_admin");

  const users = await withUser(admin.id, (tx) =>
    tx.execute<{
      id: string; mobile: string; display_name: string | null; status: string;
      verification_level: number; created_at: string; roles: string[] | null; balance: string; is_special: boolean;
    }>(sql`
      select u.id, u.mobile, u.display_name, u.status, u.verification_level, u.created_at::text, u.is_special,
             array_remove(array_remove(array_agg(r.role), 'user'), 'customer') as roles,
             wallet_balance(u.id, 'available')::text as balance
      from users u left join user_roles r on r.user_id = u.id
      group by u.id order by u.created_at desc limit 200`),
  );

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">کاربران و نقش‌ها</h1>
      <div className="space-y-3">
        {users.map((u) => (
          <Card key={u.id} className="space-y-2">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="space-y-1">
                <p className="flex items-center gap-2 font-semibold">
                  {u.display_name ?? "—"}
                  <span className="text-xs text-[var(--color-muted)]" dir="ltr">{toFaDigits(u.mobile)}</span>
                  <Badge tone={u.status === "active" ? "accent" : "danger"}>
                    {u.status === "active" ? "فعال" : u.status === "suspended" ? "معلق" : u.status}
                  </Badge>
                  {u.is_special && <Badge tone="warning">کاربر ویژه</Badge>}
                </p>
                <p className="text-xs text-[var(--color-muted)]">
                  سطح {toFaDigits(u.verification_level)} · موجودی {formatToman(Number(u.balance))}
                </p>
              </div>
              <div className="flex items-center gap-2">
                <form action={toggleSpecialUserAction}>
                  <input type="hidden" name="user_id" value={u.id} />
                  <Button variant="ghost" size="sm" type="submit" title="کاربر ویژه می‌تواند به نمایندگی دیگران انتقال دهد">
                    {u.is_special ? "حذف وضعیت ویژه" : "تعیین به‌عنوان ویژه"}
                  </Button>
                </form>
                <form action={setUserStatusAction}>
                  <input type="hidden" name="user_id" value={u.id} />
                  <input type="hidden" name="status" value={u.status === "active" ? "suspended" : "active"} />
                  {u.id !== admin.id && (
                    <Button variant="outline" size="sm" type="submit"
                      className={u.status === "active" ? "text-[var(--color-danger)]" : ""}>
                      {u.status === "active" ? "تعلیق" : "رفع تعلیق"}
                    </Button>
                  )}
                </form>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2 border-t border-[var(--color-border)] pt-2">
              {(u.roles ?? []).filter(Boolean).map((r) => (
                <form key={r} action={revokeRoleAction} className="inline-flex">
                  <input type="hidden" name="user_id" value={u.id} />
                  <input type="hidden" name="role" value={r} />
                  <Badge tone="warning" className="gap-1">
                    {ROLE_FA[r] ?? r}
                    {isSuper && <button type="submit" title="حذف نقش" className="opacity-70 hover:opacity-100">×</button>}
                  </Badge>
                </form>
              ))}
              {isSuper && (
                <form action={grantRoleAction} className="flex items-center gap-1">
                  <input type="hidden" name="user_id" value={u.id} />
                  <select name="role" className="rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-2 py-1 text-xs">
                    {GRANTABLE_ROLES.map((r) => <option key={r} value={r}>{ROLE_FA[r] ?? r}</option>)}
                  </select>
                  <Button variant="ghost" size="sm" type="submit">+ نقش</Button>
                </form>
              )}
            </div>
          </Card>
        ))}
        {users.length === 0 && <Card><CardMuted>کاربری یافت نشد.</CardMuted></Card>}
      </div>
    </div>
  );
}
