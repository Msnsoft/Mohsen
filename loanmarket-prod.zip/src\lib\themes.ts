// The 6 selectable UI color sets (M02 FR-M02-10). Keys must match the
// users_theme_ck DB constraint and the [data-theme] blocks in globals.css.
export const THEMES = [
  { key: "ocean", label: "اقیانوس", primary: "#4f8cff", accent: "#2bd4a7", bg: "#0b1020" },
  { key: "emerald", label: "زمرد", primary: "#10b981", accent: "#fbbf24", bg: "#08160f" },
  { key: "violet", label: "بنفش", primary: "#a78bfa", accent: "#f472b6", bg: "#130f23" },
  { key: "sunset", label: "غروب", primary: "#fb923c", accent: "#facc15", bg: "#1b1109" },
  { key: "rose", label: "رز", primary: "#fb7185", accent: "#38bdf8", bg: "#1c0d13" },
  { key: "light", label: "روشن", primary: "#2563eb", accent: "#059669", bg: "#f4f6fb" },
] as const;

export type ThemeKey = (typeof THEMES)[number]["key"];
export const DEFAULT_THEME: ThemeKey = "ocean";
export const THEME_COOKIE = "lm_theme";

export function isThemeKey(v: unknown): v is ThemeKey {
  return typeof v === "string" && THEMES.some((t) => t.key === v);
}
