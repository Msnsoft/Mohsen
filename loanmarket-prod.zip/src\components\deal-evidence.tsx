import { FileText } from "lucide-react";
import type { DealEvidenceRow } from "@/services/deals";
import { Button } from "@/components/ui/button";
import { uploadEvidence } from "@/app/deals/actions";
import { formatDateTimeFa } from "@/lib/persian";

export const EVIDENCE_KIND_FA: Record<string, string> = {
  payment_receipt: "رسید پرداخت (خریدار)",
  transfer_proof: "مدرک انتقال (فروشنده)",
};

const fileCls =
  "block w-full rounded-xl border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm file:me-3 file:rounded-md file:border-0 file:bg-[var(--color-primary)] file:px-3 file:py-1.5 file:text-white";

/** Read-only list of uploaded evidence (links open through the gated route). */
export function EvidenceList({ evidence }: { evidence: DealEvidenceRow[] }) {
  if (evidence.length === 0) return null;
  return (
    <ul className="space-y-2">
      {evidence.map((e) => (
        <li key={e.id} className="flex items-center gap-2 text-sm">
          <FileText size={15} className="text-[var(--color-muted)]" />
          <span>{EVIDENCE_KIND_FA[e.kind] ?? e.kind}</span>
          <a href={e.file_url} target="_blank" rel="noopener noreferrer" className="text-[var(--color-primary)]">مشاهده</a>
          <span className="ms-auto text-xs text-[var(--color-muted)]">{formatDateTimeFa(e.created_at)}</span>
        </li>
      ))}
    </ul>
  );
}

/** Upload form for one evidence kind (escrow-off manual settlement, req. F). */
export function EvidenceUpload({ dealId, kind, label }: { dealId: string; kind: string; label: string }) {
  return (
    <form action={uploadEvidence} className="space-y-2">
      <input type="hidden" name="deal_id" value={dealId} />
      <input type="hidden" name="kind" value={kind} />
      <p className="text-sm text-[var(--color-muted)]">{label}</p>
      <input type="file" name="file" accept="image/*,application/pdf" required className={fileCls} />
      <Button type="submit" size="sm" variant="outline">بارگذاری</Button>
    </form>
  );
}
