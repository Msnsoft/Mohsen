"use client";
import { useEffect, useState } from "react";
import { toFaDigits } from "@/lib/persian";

/** Live countdown to an ISO deadline (req. Q). Shows «منقضی» once passed. */
export function Countdown({ to }: { to: string }) {
  const target = new Date(to).getTime();
  const [now, setNow] = useState<number | null>(null); // null until mounted → avoids hydration mismatch

  useEffect(() => {
    setNow(Date.now());
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  if (now === null) return null;
  const ms = target - now;
  if (ms <= 0) {
    return <span className="text-xs font-medium text-[var(--color-danger)]">مهلت به پایان رسید</span>;
  }
  const s = Math.floor(ms / 1000);
  const d = Math.floor(s / 86400);
  const h = Math.floor((s % 86400) / 3600);
  const m = Math.floor((s % 3600) / 60);
  const sec = s % 60;
  const parts = d > 0 ? [`${d} روز`, `${h} ساعت`, `${m} دقیقه`] : [`${h}:${String(m).padStart(2, "0")}:${String(sec).padStart(2, "0")}`];
  const tone = ms < 6 * 3600_000 ? "text-[var(--color-warning)]" : "text-[var(--color-muted)]";
  return <span className={`text-xs font-medium ${tone}`}>⏳ {toFaDigits(parts.join(" و "))} باقی‌مانده</span>;
}
