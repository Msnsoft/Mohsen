// Amortization helpers. Carried from the prototype.
export function monthlyInstallment(principal: number, annualRatePct: number, months: number): number {
  const r = annualRatePct / 100 / 12;
  if (months <= 0) return 0;
  if (r === 0) return principal / months;
  return (principal * r) / (1 - Math.pow(1 + r, -months));
}

export interface AmortRow {
  month: number;
  installment: number;
  principal: number;
  interest: number;
  balance: number;
}

export function generateAmortizationSchedule(
  principal: number, annualRatePct: number, months: number,
): AmortRow[] {
  const r = annualRatePct / 100 / 12;
  const pmt = monthlyInstallment(principal, annualRatePct, months);
  const rows: AmortRow[] = [];
  let balance = principal;
  for (let m = 1; m <= months; m++) {
    const interest = balance * r;
    const principalPart = pmt - interest;
    balance = Math.max(0, balance - principalPart);
    rows.push({
      month: m,
      installment: Math.round(pmt),
      principal: Math.round(principalPart),
      interest: Math.round(interest),
      balance: Math.round(balance),
    });
  }
  return rows;
}
