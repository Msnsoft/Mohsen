import { withUser, sql } from "@/db";
import { Card, CardTitle, CardMuted } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { THEMES } from "@/lib/themes";
import { requireSectionPage } from "../guard";
import { saveConfigAction, runDueJobsAction } from "../actions";

export const dynamic = "force-dynamic";

const inputCls =
  "w-full rounded-lg border border-[var(--color-border)] bg-[var(--color-surface-2)] px-3 py-2 text-sm outline-none focus:border-[var(--color-primary)]";

export default async function AdminConfigPage() {
  const admin = await requireSectionPage("config");

  const rows = await withUser(admin.id, (tx) =>
    tx.execute<{ key: string; value: string; updated_at: string }>(
      sql`select key, value::text as value, updated_at::text from config order by key`,
    ),
  );
  const cfg = Object.fromEntries(rows.map((r) => [r.key, r.value.replaceAll('"', "")]));
  // req. Q: which workflow stages are admin-hidden
  let hiddenStages: string[] = [];
  try { hiddenStages = JSON.parse(rows.find((r) => r.key === "deal.hidden_stages")?.value ?? "[]"); } catch { hiddenStages = []; }
  const STAGE_LABELS: [string, string][] = [
    ["post", "ثبت آگهی"], ["fee", "پرداخت کارمزد"], ["approve", "تأیید آگهی"],
    ["accept", "پذیرش"], ["buyer_info", "اطلاعات خریدار"], ["escrow_fund", "واریز امانی"],
    ["seller_transfer", "انتقال فروشنده"], ["buyer_confirm", "تأیید خریدار"], ["release", "آزادسازی"],
  ];
  const plans = await withUser(admin.id, (tx) =>
    tx.execute<{ key: string; name: string }>(sql`select key, name from subscription_plans where active order by sort`),
  );

  return (
    <div className="space-y-4">
      <h1 className="text-2xl font-bold">پیکربندی</h1>
      <CardMuted>تغییرات بلافاصله و بدون استقرار مجدد اعمال می‌شوند (M16).</CardMuted>

      <Card>
        <form action={saveConfigAction} className="space-y-5">
          <section className="space-y-3">
            <CardTitle>بازار</CardTitle>
            <label className="block space-y-1 text-sm">
              <span className="text-[var(--color-muted)]">نحوهٔ تأیید آگهی‌ها</span>
              <select name="cfg:marketplace.listing_approval_mode" className={inputCls}
                defaultValue={cfg["marketplace.listing_approval_mode"] ?? "manual"}>
                <option value="manual">دستی — هر آگهی پیش از انتشار توسط مدیر بررسی می‌شود</option>
                <option value="auto">خودکار — آگهی بلافاصله منتشر می‌شود</option>
              </select>
            </label>
          </section>

          <section className="space-y-3">
            <CardTitle>ظاهر</CardTitle>
            <label className="block space-y-1 text-sm">
              <span className="text-[var(--color-muted)]">تم پیش‌فرض (برای مهمان‌ها و کاربران جدید)</span>
              <select name="cfg:ui.default_theme" className={inputCls} defaultValue={cfg["ui.default_theme"] ?? "ocean"}>
                {THEMES.map((t) => <option key={t.key} value={t.key}>{t.label}</option>)}
              </select>
            </label>
          </section>

          <section className="space-y-3">
            <CardTitle>امانی و معامله</CardTitle>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">حالت امانت (Escrow)</span>
                <select name="cfg:escrow.mode" className={inputCls} defaultValue={cfg["escrow.mode"] ?? "internal"}>
                  <option value="internal">داخلی — نگهداری وجه روی دفترکل پلتفرم</option>
                  <option value="external">خارجی — اتصال به سرویس امانی بیرونی (API)</option>
                  <option value="disabled">غیرفعال — فقط تأیید خریدار و فروشنده کافی است</option>
                </select>
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">آدرس API سرویس امانی خارجی</span>
                <input name="cfg:escrow.api_url" defaultValue={cfg["escrow.api_url"] ?? ""} dir="ltr" placeholder="https://escrow.example.ir/api" className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">مهلت بازرسی خریدار (ساعت)</span>
                <input name="cfg:escrow.inspection_hours" defaultValue={cfg["escrow.inspection_hours"] ?? "72"} dir="ltr" className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">مهلت انتقال فروشنده (ساعت)</span>
                <input name="cfg:escrow.seller_timeout_hours" defaultValue={cfg["escrow.seller_timeout_hours"] ?? "12"} dir="ltr" className={inputCls} />
              </label>
            </div>
            <div className="space-y-2">
              <span className="text-sm text-[var(--color-muted)]">نمایش مراحل روند معامله — مراحل تیک‌خورده از تایم‌لاین کاربر پنهان می‌شوند (req. Q)</span>
              <input type="hidden" name="cfg:deal.hidden_stages.present" value="1" />
              <div className="flex flex-wrap gap-x-4 gap-y-2">
                {STAGE_LABELS.map(([key, label]) => (
                  <label key={key} className="flex items-center gap-1.5 text-sm">
                    <input type="checkbox" name="cfg:deal.hidden_stages" value={key} defaultChecked={hiddenStages.includes(key)} />
                    {label}
                  </label>
                ))}
              </div>
            </div>
          </section>

          <section className="space-y-3">
            <CardTitle>کارمزد و اشتراک</CardTitle>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">تسهیم پلهٔ ناقص کارمزد پلکانی</span>
                <select name="cfg:commission.prorate_partial_band" className={inputCls}
                  defaultValue={cfg["commission.prorate_partial_band"] ?? "true"}>
                  <option value="true">بله — پلهٔ ناقص به نسبت محاسبه شود</option>
                  <option value="false">خیر — مبلغ کامل پله اعمال شود</option>
                </select>
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">مهلت ارفاق اشتراک (روز)</span>
                <input name="cfg:membership.grace_days" defaultValue={cfg["membership.grace_days"] ?? "3"} dir="ltr" className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">پلن پیش‌فرض کاربران جدید</span>
                <select name="cfg:membership.default_plan_key" className={inputCls} defaultValue={cfg["membership.default_plan_key"] ?? "free"}>
                  <option value="free">رایگان (بدون اشتراک اولیه)</option>
                  {plans.filter((p) => p.key !== "free").map((p) => (
                    <option key={p.key} value={p.key}>{p.name}</option>
                  ))}
                </select>
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">مدت پلن پیش‌فرض (روز) — پس از انقضا به رایگان بازمی‌گردد</span>
                <input name="cfg:membership.default_duration_days" defaultValue={cfg["membership.default_duration_days"] ?? "30"} dir="ltr" className={inputCls} />
              </label>
            </div>
          </section>

          <section className="space-y-3">
            <CardTitle>احراز هویت</CardTitle>
            <label className="block space-y-1 text-sm sm:w-1/2">
              <span className="text-[var(--color-muted)]">اعتبار کد یکبارمصرف (دقیقه)</span>
              <input name="cfg:otp.ttl_minutes" defaultValue={cfg["otp.ttl_minutes"] ?? "3"} dir="ltr" className={inputCls} />
            </label>
          </section>

          <section className="space-y-3">
            <CardTitle>برند و نمایش</CardTitle>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">نام سایت</span>
                <input name="cfg:cms.site_name" defaultValue={cfg["cms.site_name"] ?? ""} className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">آدرس لوگو (URL)</span>
                <input name="cfg:cms.logo_url" defaultValue={cfg["cms.logo_url"] ?? ""} dir="ltr" placeholder="https://…/logo.svg" className={inputCls} />
              </label>
              <label className="flex items-center gap-2 text-sm sm:col-span-2">
                <input type="checkbox" name="cfg:analysis.show_market_average" defaultChecked={cfg["analysis.show_market_average"] === "true"} />
                <span>نمایش میانگین قیمت بازار به کاربران (بخش تحلیل مالی)</span>
              </label>
              <label className="flex items-center gap-2 text-sm sm:col-span-2">
                <input type="checkbox" name="cfg:notifications.sms_enabled" defaultChecked={cfg["notifications.sms_enabled"] === "true"} />
                <span>ارسال پیامک برای اعلان‌ها (علاوه بر اعلان درون‌برنامه‌ای) — توسط worker انجام می‌شود</span>
              </label>
            </div>
          </section>

          <section className="space-y-3">
            <CardTitle>اطلاعات تماس</CardTitle>
            <div className="grid gap-3 sm:grid-cols-3">
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">تلفن</span>
                <input name="cfg:contact.phone" defaultValue={cfg["contact.phone"] ?? ""} dir="ltr" className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">ایمیل</span>
                <input name="cfg:contact.email" defaultValue={cfg["contact.email"] ?? ""} dir="ltr" className={inputCls} />
              </label>
              <label className="space-y-1 text-sm">
                <span className="text-[var(--color-muted)]">نشانی</span>
                <input name="cfg:contact.address" defaultValue={cfg["contact.address"] ?? ""} className={inputCls} />
              </label>
            </div>
          </section>

          <Button type="submit">ذخیرهٔ پیکربندی</Button>
        </form>
      </Card>

      <Card className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <CardTitle>کارهای زمان‌بندی‌شده</CardTitle>
          <CardMuted>آزادسازی خودکار امانت پس از مهلت بازرسی، یادآوری انتقال فروشنده، و انقضای اشتراک‌ها. در محصول واقعی این کارها توسط worker (pg-boss) به‌صورت دوره‌ای اجرا می‌شوند؛ اینجا برای آزمایش به‌صورت دستی اجرا می‌شوند.</CardMuted>
        </div>
        <form action={runDueJobsAction}>
          <Button type="submit" variant="outline">اجرای کارهای موعدرسیده</Button>
        </form>
      </Card>

      <Card className="space-y-2">
        <CardTitle>همهٔ کلیدها</CardTitle>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <tbody>
              {rows.map((r) => (
                <tr key={r.key} className="border-t border-[var(--color-border)]">
                  <td className="px-2 py-1.5 text-xs" dir="ltr">{r.key}</td>
                  <td className="px-2 py-1.5 text-xs text-[var(--color-muted)]" dir="ltr">{r.value}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
    </div>
  );
}
