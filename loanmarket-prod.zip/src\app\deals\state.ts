export const DEAL_STATE_FA: Record<string, string> = {
  draft: "پیش‌نویس",
  waiting_seller_transfer: "در انتظار انتقال فروشنده",
  waiting_buyer_confirmation: "در انتظار تأیید خریدار",
  completed: "تکمیل‌شده",
  cancelled: "لغو‌شده",
  disputed: "اختلاف",
  expired: "منقضی",
};

type Tone = "default" | "accent" | "warning" | "danger" | "muted";
export function dealStateTone(state: string): Tone {
  switch (state) {
    case "completed": return "accent";
    case "cancelled":
    case "expired": return "muted";
    case "disputed": return "danger";
    case "waiting_seller_transfer":
    case "waiting_buyer_confirmation": return "warning";
    default: return "default";
  }
}
