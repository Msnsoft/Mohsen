# Deployment Runbook — بازار امتیاز وام

Two ready-to-run packages are produced from this repo (see `deploy/build-packages.ps1`):

| Package | File | Use |
|---------|------|-----|
| **Development** | `loanmarket-dev.zip` | Local testing of the whole stack on your machine. |
| **Production**  | `loanmarket-prod.zip` | Deploy on your self-hosted server. |

Both need only **Docker + Docker Compose** on the target machine. Nothing else.

---

## 1. Development package (local testing)

```bash
unzip loanmarket-dev.zip && cd loanmarket-dev
docker compose up --build
```

That brings up Postgres (auto-seeded), MinIO, the web app, and the worker.

- App: <http://localhost:3000>
- Adminer (DB browser): <http://localhost:8080>  (server `postgres`, user `postgres`, pass `postgres`, db `loanmarket`)
- MinIO console: <http://localhost:9001>  (`minioadmin` / `minioadmin`)

**Login:** OTP runs in dev mode — the 6-digit code is printed in the `web` container logs (`docker compose logs -f web`). The account matching `SUPER_ADMIN_EMAIL` becomes super-admin on first login.

Stop & wipe: `docker compose down -v` (the `-v` also deletes the DB/MinIO volumes so the next `up` re-seeds).

---

## 2. Production package (self-host)

```bash
unzip loanmarket-prod.zip && cd loanmarket-prod
cp .env.production.example .env
#  → edit .env: set SESSION_SECRET, POSTGRES_PASSWORD, S3 keys, SMS provider,
#    SUPER_ADMIN_EMAIL, and OTP_DEV_MODE=false
docker compose -f docker-compose.prod.yml up -d --build
```

What it runs: `web` (published on `WEB_PORT`, default 3000), `worker`, `postgres`,
`minio` — Postgres and MinIO are **internal-only** (not published to the host).
The DB schema + seed (`db/init/01..14`) is applied automatically on first boot.

### Put TLS in front
`web` speaks plain HTTP on `WEB_PORT`. Terminate TLS with your own reverse proxy
(nginx / Caddy). Minimal nginx:

```nginx
server {
  listen 443 ssl;
  server_name yourdomain.ir;
  ssl_certificate     /etc/ssl/yourdomain.crt;
  ssl_certificate_key /etc/ssl/yourdomain.key;
  location / {
    proxy_pass http://127.0.0.1:3000;
    proxy_set_header Host $host;
    proxy_set_header X-Forwarded-For $remote_addr;
    proxy_set_header X-Forwarded-Proto $scheme;
    # Server-Sent Events (live updates) need buffering off:
    proxy_buffering off;
    proxy_read_timeout 1h;
  }
}
```

### Going live checklist
- [ ] `SESSION_SECRET` is a fresh 32+ char random value (`openssl rand -base64 48`).
- [ ] `OTP_DEV_MODE=false` and a real `SMS_PROVIDER=http` + `SMS_API_URL`/`SMS_API_KEY`.
- [ ] `notifications.sms_enabled` turned on in `/admin/config` if you want SMS notifications.
- [ ] Identity seam: set `SHAHKAR_*` / `FINNOTECH_*` (blank = dev auto-pass).
- [ ] Reverse proxy with TLS in front of `WEB_PORT`; SSE buffering disabled.
- [ ] Backups: `docker compose -f docker-compose.prod.yml exec postgres pg_dump -U postgres loanmarket > backup.sql`.

### Updating to a new build
```bash
docker compose -f docker-compose.prod.yml up -d --build
```
DB init scripts only run on the **first** boot (empty volume). New SQL migrations
(`db/init/NN_*.sql`) on an existing database must be applied manually:
```bash
cat db/init/15_whatever.sql | docker compose -f docker-compose.prod.yml exec -T postgres psql -U postgres -d loanmarket
```

---

## 3. Operations

- **Logs:** `docker compose [-f docker-compose.prod.yml] logs -f web worker`
- **Run due-jobs now** (instead of waiting for the worker): admin → کنسول امانی → «اجرای کارهای زمان‌بندی‌شده».
- **Audit trail:** admin → گزارش حسابرسی (`/admin/audit`) — every money movement + admin action, read-only.
- **Health:** `web` serves on `:3000`; `postgres` has a `pg_isready` healthcheck.
