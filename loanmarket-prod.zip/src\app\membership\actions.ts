"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { withUser, sql } from "@/db";
import { getCurrentUser } from "@/lib/auth";

/** Buy/renew a plan from the wallet (M19) via the subscription_purchase SQL fn. */
export async function purchasePlanAction(formData: FormData) {
  const planKey = String(formData.get("plan_key") ?? "");
  const user = await getCurrentUser();
  if (!user) redirect("/login");

  try {
    await withUser(user.id, (tx) =>
      tx.execute(sql`select subscription_purchase(${user.id}::uuid, ${planKey}, ${"sub_" + crypto.randomUUID()})`),
    );
  } catch (e) {
    const msg = e instanceof Error ? e.message : "";
    if (msg.includes("insufficient balance")) redirect("/wallet?need=1");
    if (msg.includes("already prepaid")) redirect("/membership?error=queue");
    redirect("/membership?error=1");
  }
  revalidatePath("/membership");
  revalidatePath("/panel");
  redirect("/membership?ok=1");
}
