import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./src/db/schema.ts",
  out: "./db/migrations",
  dialect: "postgresql",
  dbCredentials: {
    url: process.env.DATABASE_URL ?? "postgres://app:app_password@localhost:5432/loanmarket",
  },
  // The authoritative DB objects (RLS, money functions, triggers, seed) live in
  // db/init/*.sql and are applied by the Postgres container on first boot.
  // drizzle-kit is used for typed table sync during development only.
});
